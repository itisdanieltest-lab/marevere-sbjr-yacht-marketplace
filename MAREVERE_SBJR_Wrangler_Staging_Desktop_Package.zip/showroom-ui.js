(() => {
  'use strict';
  const $ = id => document.getElementById(id);
  const reducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  const header = $('header');
  const menu = $('mobileMenu');
  const menuBtn = $('menuButton');
  function setMenu(open) {
    menu.hidden = !open;
    menuBtn.setAttribute('aria-expanded', String(open));
    menuBtn.setAttribute('aria-label', open ? 'Close navigation' : 'Open navigation');
    document.body.style.overflow = open ? 'hidden' : '';
  }
  menuBtn.addEventListener('click', () => setMenu(menu.hidden));
  menu.querySelectorAll('a').forEach(a => a.addEventListener('click', () => setMenu(false)));
  window.addEventListener('keydown', e => { if (e.key === 'Escape') setMenu(false); });
  window.addEventListener('resize', () => { if (window.innerWidth > 740 && !menu.hidden) setMenu(false); });
  const progress = $('scrollLine');
  let queued = false;
  function scrollUpdate() { const max = document.documentElement.scrollHeight - innerHeight; progress.style.width = max ? Math.round(scrollY/max*100)+'%' : '0%';queued=false; }
  window.addEventListener('scroll', () => { if (!queued) {queued=true;requestAnimationFrame(scrollUpdate);} }, { passive:true });scrollUpdate();
  const film = $('filmVideo');
  const filmControl = $('filmControl');
  const filmControlText = $('filmControlText');
  const filmControlIcon = $('filmControlIcon');
  function refreshFilm() {
    const playing = !film.paused && !film.ended;
    filmControl.setAttribute('aria-pressed', String(playing));
    filmControl.setAttribute('aria-label', playing ? 'Pause cinematic study' : 'Play cinematic study');
    filmControlText.textContent = playing ? 'PAUSE FILM' : 'PLAY FILM';
    filmControlIcon.textContent = playing ? 'Ⅱ' : '▶';
  }
  filmControl.addEventListener('click', () => {
    if(film.paused){ film.play().catch(() => { filmControlText.textContent='VIDEO UNAVAILABLE'; }); }
    else film.pause();
  });
  film.addEventListener('play',refreshFilm);film.addEventListener('pause',refreshFilm);
  document.addEventListener('visibilitychange', () => {if(document.hidden && !film.paused) film.pause();});
  if (reducedMotion) film.pause();
  // Accessible hotspots also work when interactive WebGL cannot be loaded.
  const descriptions = {
    hull: 'The sculpted hull is an illustrative engineering study, not a verified hull form, survey, or vessel specification.',
    deck: 'An imagined open aft-deck area with room for lounging. Final dimensions and outfitting can only be confirmed from an actual listed yacht.',
    bridge: 'The raised pilothouse and glazing are architectural placeholders. No navigation equipment or safety specification has been verified.',
    bow: 'A conceptual forward lounging area and rail geometry. Manufacturer documentation must confirm arrangements on a real vessel.'
  };
  const hotspotButtons = Array.from(document.querySelectorAll('[data-hotspot]'));
  hotspotButtons.forEach(btn => btn.addEventListener('click', () => {
    hotspotButtons.forEach(el => { const active = el === btn;el.classList.toggle('active',active);el.setAttribute('aria-pressed',String(active));});
    $('hotspotDescription').textContent = descriptions[btn.dataset.hotspot];
    window.dispatchEvent(new CustomEvent('marevere-hotspot',{detail:{target:btn.dataset.hotspot}}));
  }));
  const viewer = $('viewerShell');
  let engineReady = false;
  const cameraButtons = Array.from(document.querySelectorAll('[data-camera]'));
  const utilityButtons = ['toggleRotate','toggleLight','resetView'].map($);
  window.addEventListener('marevere-3d-ready', () => {
    engineReady = true;
    viewer.classList.add('model-loaded');
    $('modelStatus').textContent='INTERACTIVE 3D / READY';
    $('viewerHelp').textContent='Original concept model · drag to orbit and pinch or scroll to zoom.';
  });
  window.addEventListener('marevere-3d-error', e => {
    if(engineReady) return;
    $('modelStatus').textContent='STILL PREVIEW / 3D UNAVAILABLE';
    $('viewerHelp').textContent='3D requires WebGL and an internet connection for the Three.js library. View the still while offline.';
    cameraButtons.concat(utilityButtons).forEach(btn=> btn.disabled = true);
    if(e.detail && e.detail.message) console.info('MAREVERE 3D unavailable:',e.detail.message);
  });
  // If the module cannot load at all (offline/CDN), keep the page useful.
  setTimeout(() => { if (!engineReady) window.dispatchEvent(new CustomEvent('marevere-3d-error',{detail:{message:'3D script timed out (possibly offline).'}})); },10000);
  cameraButtons.forEach(btn => btn.addEventListener('click', () => {
    if(!engineReady)return;
    cameraButtons.forEach(el=>{const on=el===btn;el.classList.toggle('active',on);el.setAttribute('aria-pressed',String(on));});
    window.dispatchEvent(new CustomEvent('marevere-camera',{detail:{view:btn.dataset.camera}}));
  }));
  $('resetView').addEventListener('click',()=>{if(!engineReady)return;cameraButtons[0].click();});
  $('toggleRotate').addEventListener('click',()=>{ if(!engineReady)return; const on=$('toggleRotate').getAttribute('aria-pressed')!=='true';$('toggleRotate').setAttribute('aria-pressed',String(on));window.dispatchEvent(new CustomEvent('marevere-rotate',{detail:{active:on}})); });
  $('toggleLight').addEventListener('click',()=>{if(!engineReady)return;const on=$('toggleLight').getAttribute('aria-pressed')!=='true';$('toggleLight').setAttribute('aria-pressed',String(on));window.dispatchEvent(new CustomEvent('marevere-light',{detail:{dusk:on}}));});
})();
