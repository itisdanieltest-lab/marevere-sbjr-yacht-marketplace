# MAREVERE · SBJR — Phase 6.14 Integration

**LOCAL FICTIONAL ENGINEERING DEMO ONLY / NOT PRODUCTION READY**

## What's implemented

- Previous public cinematic pages and yacht dossier preserved.
- Connected account entry pages: `/account.html` (buyer), `/seller.html` (broker), `/admin.html` (operations), `/sign-in.html` (shared access). Backed by authenticated local APIs and SQLite.
- Public yacht collection and dossier: account-synced saved vessels for signed-in fictional buyers. Visitor-only saves continue in local browser storage. No silent merging between visitor and account data.
- Marine shop: account-synced fictional bag for signed-in buyers; visitor bag stays on-device. Server is authoritative for product ID, EUR illustrative price and quantity. **No checkout, payment, order, or shipping.**
- Broker listing review: a separate public, clearly labeled read-only sample of admin-approved fictional broker concepts; no sale offers.
- Public help page links to the connected buyer support desk. Support tickets stored in local DB; no human receives them.
- Fictional buyer self-registration accepts only reserved addresses ending `@marevere.invalid`. No real email, verification, recovery, or real-world personal data.
- Existing seller and administrator flows continue to be server-role checked, with CSRF token and a local audit trail.
- MAREVERE prominent and SBJR signature retained throughout.

## Running and testing

```
python backend/app.py
# http://127.0.0.1:8765/
# role-based sign-in at http://127.0.0.1:8765/sign-in.html
python tests/integration_smoke.py  # defaults to port 18765; use MAREVERE_TEST_URL as needed
python tests/phase614_smoke.py
```

Demo credentials auto-generated on first run to `.runtime/demo_credentials.txt` (excluded from downloadable ZIP). Use only fictional data. Do not copy or publish demo secrets.

## Explicit limitations

- The generated `register.html` flow is **not** an actual production identity service. Signup is restricted to `.invalid` to prevent collection of real emails; no email verification/recovery yet.
- The server refuses non-loopback exposure. No public hosting or deployment.
- Authentication tests are limited to local demonstration behavior. Staff MFA, identity provider, security review, audit retention and incident response remain unimplemented.
- Yacht 3D model is illustrative, not manufacturer-accurate. Film is an animated concept, not verified yacht footage.
- Acquisition Tier 2 and Tier 3 terms lack legal/business approval. No customer deposits, real contracts, custody, valuation returns, fund transfer, delivery guarantees or transactions.
- UI preservation means public cinematic design is kept, but old static buyer/seller/admin UI mockups are retained in design_archive for design reference; new accounts use a single connected design system.
- Real site-wide auth, anti-abuse, accessibility, QA and full browser-to-backend E2E still required.
