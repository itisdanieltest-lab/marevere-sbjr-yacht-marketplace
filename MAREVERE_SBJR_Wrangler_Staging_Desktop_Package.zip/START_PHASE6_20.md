# MAREVERE · SBJR — Phase 6.20: Public Vessel Photographs and Videos

## What changed

- All **three** inventory vessels display their correct set of **10 vessel-specific photographs**, plus **one original listing video** per yacht in the public-facing `fleet.html` catalogue. Total: **30 photographs and three videos**.
- The header and footer retain the **exact previously approved MAREVERE · SBJR logo/wordmark**; no logo assets or paths were altered.
- Cards now show the actual matching vessel hero photograph, not generic concept artwork. Opening a vessel dossier offers a mobile-accessible thumbnail gallery, previous/next controls and an HTML5 video player with full-length streaming and byte-range support.
- Public media endpoint: `GET /api/public/inventory/media/<MEDIA-ID>` requires no account. It only permits listed **Image** and **Video** objects attached to currently **visible** yachts. Hidden yacht media return 404. The original private files are not copied into an openly browsable folder; a validated allowlisted route streams them.
- Public inventory and dossier APIs provide sanitized photo/video IDs, captions and URLs, but no owner details, licensing/evidence text, private workbook or 3D models.
- Admin status changes (**Available / Pending / Sold / Out of Stock / Hide**) remain role-protected and audited. Sale/price verification requirements are unchanged. Existing manual payment-case notes remain fictional and do not process any money.

## To run locally

```sh
python backend/app.py
```

Visit `http://127.0.0.1:8765/fleet.html`. The server binds localhost only. You can open the public photo/video gallery without logging in. Admin: `http://127.0.0.1:8765/admin-inventory.html` (requires an admin session for data or edits). On first launch demonstration credentials are created inside `.runtime` (excluded from the archive).

## Design preview

`MAREVERE_SBJR_Phase6_20_Public_Media_Interactive_Preview.html` (separate file linked from the assistant response) embeds the yacht photographs and **eight-second video excerpts** to be convenient on an Android phone. The full site media endpoint serves the original videos, not shortened preview clips.

## Media provenance / outstanding risk

The research workbook marks all photos and original listing videos as **pending written permission**, citing third-party broker or media sources. Their visibility in the local public-facing site follows the user’s express direction, **not** independent confirmation of a publication license. Document permission from the copyright holders before external, indexed deployment. The publisher assumes responsibility for obtaining required rights. ARISTARCHOS I remains **Sold** based on the research record. The remaining two default to **Pending**, not verified active offers. The 3D reconstructions remain privately held because they are approximate and not survey-/builder-certified.

## Publication scope and security

**This package has not been uploaded to an internet-accessible domain.** It is a local-only application, with incomplete production authentication and no real payment processing. Do not expose the demonstration server directly to the internet. To publish externally, use an approved, secure hosting deployment with HTTPS, real staff authentication, rights clearance and production QA. No real customer transactions are enabled.

## Verification

Run:

```
python tests/phase619_public_catalog.py
python tests/phase620_public_media.py
python tests/phase618_inventory.py
```

The new public media tests check anonymous photo delivery, MP4 byte-range streaming, video MIME, gallery counts and IDs, denial of GLB/private workbook/3D, and 404 responses for hidden yachts. Responsive checks and screenshots cover 320, 390, 768, 1024 and 1440 px with original MAREVERE styling and no observed horizontal overflow.
