PRAGMA foreign_keys=ON;
CREATE TABLE IF NOT EXISTS users (
 id INTEGER PRIMARY KEY, email TEXT NOT NULL UNIQUE, password_hash TEXT NOT NULL,
 role TEXT NOT NULL CHECK(role IN ('buyer','seller','admin')), display_name TEXT NOT NULL,
 created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS sessions (
 token_hash TEXT PRIMARY KEY, user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
 csrf TEXT NOT NULL, expires_at INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS vessels (
 id INTEGER PRIMARY KEY, slug TEXT NOT NULL UNIQUE, name TEXT NOT NULL,
 type TEXT NOT NULL, length_m INTEGER NOT NULL, summary TEXT NOT NULL,
 is_concept INTEGER NOT NULL DEFAULT 1
);
CREATE TABLE IF NOT EXISTS saved (
 user_id INTEGER NOT NULL REFERENCES users(id), vessel_id INTEGER NOT NULL REFERENCES vessels(id),
 created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP, PRIMARY KEY(user_id,vessel_id)
);
CREATE TABLE IF NOT EXISTS listings (
 id INTEGER PRIMARY KEY, seller_id INTEGER NOT NULL REFERENCES users(id), name TEXT NOT NULL,
 description TEXT NOT NULL, length_m INTEGER NOT NULL,
 status TEXT NOT NULL CHECK(status IN ('draft','submitted','approved','rejected')),
 created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
 reviewed_by INTEGER REFERENCES users(id), reviewed_at TEXT
);
CREATE TABLE IF NOT EXISTS support_tickets (
 id INTEGER PRIMARY KEY, buyer_id INTEGER NOT NULL REFERENCES users(id), subject TEXT NOT NULL,
 message TEXT NOT NULL, status TEXT NOT NULL DEFAULT 'open' CHECK(status IN ('open','resolved')),
 created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS audit_events (
 id INTEGER PRIMARY KEY, actor_id INTEGER REFERENCES users(id), event TEXT NOT NULL,
 resource TEXT NOT NULL, created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX IF NOT EXISTS idx_sessions_user ON sessions(user_id);
CREATE INDEX IF NOT EXISTS idx_listings_status ON listings(status);
CREATE INDEX IF NOT EXISTS idx_tickets_status ON support_tickets(status);
