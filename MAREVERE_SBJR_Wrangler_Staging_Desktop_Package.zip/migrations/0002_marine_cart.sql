CREATE TABLE IF NOT EXISTS marine_products (
 id TEXT PRIMARY KEY, name TEXT NOT NULL, category TEXT NOT NULL, price_eur INTEGER NOT NULL CHECK(price_eur >= 0),
 is_concept INTEGER NOT NULL DEFAULT 1 CHECK(is_concept=1)
);
CREATE TABLE IF NOT EXISTS marine_cart (
 buyer_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
 product_id TEXT NOT NULL REFERENCES marine_products(id),
 quantity INTEGER NOT NULL CHECK(quantity >= 1 AND quantity <= 20),
 updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
 PRIMARY KEY(buyer_id,product_id)
);
CREATE INDEX IF NOT EXISTS idx_cart_user ON marine_cart(buyer_id);
