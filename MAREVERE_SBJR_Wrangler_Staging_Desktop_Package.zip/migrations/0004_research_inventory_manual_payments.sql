-- Internal research inventory, NOT a public yacht catalogue or transaction ledger.
CREATE TABLE IF NOT EXISTS research_vessels (
 vessel_id TEXT PRIMARY KEY,
 name TEXT NOT NULL,
 category TEXT NOT NULL,
 status_text TEXT NOT NULL,
 data_json TEXT NOT NULL,
 workbook_sha256 TEXT NOT NULL,
 public_approved INTEGER NOT NULL DEFAULT 0 CHECK(public_approved = 0),
 imported_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS research_media (
 media_id TEXT PRIMARY KEY,
 vessel_id TEXT NOT NULL REFERENCES research_vessels(vessel_id) ON DELETE CASCADE,
 media_type TEXT NOT NULL,
 relative_path TEXT NOT NULL,
 rights_status TEXT,
 sort_order INTEGER NOT NULL DEFAULT 0
);
CREATE INDEX IF NOT EXISTS idx_research_media_vessel ON research_media(vessel_id,sort_order);
CREATE TABLE IF NOT EXISTS manual_payment_cases (
 id INTEGER PRIMARY KEY,
 vessel_id TEXT NOT NULL REFERENCES research_vessels(vessel_id),
 buyer_reference TEXT NOT NULL,
 amount_cents INTEGER NOT NULL CHECK(amount_cents>0),
 currency TEXT NOT NULL DEFAULT 'EUR' CHECK(currency='EUR'),
 status TEXT NOT NULL DEFAULT 'awaiting_external_review'
   CHECK(status IN ('awaiting_external_review','buyer_reported','evidence_reviewed','marked_paid_offline','disputed','cancelled')),
 evidence_reference TEXT NOT NULL DEFAULT '',
 private_note TEXT NOT NULL DEFAULT '',
 updated_by INTEGER NOT NULL REFERENCES users(id),
 created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
 updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS manual_payment_events (
 id INTEGER PRIMARY KEY,
 case_id INTEGER NOT NULL REFERENCES manual_payment_cases(id),
 actor_id INTEGER NOT NULL REFERENCES users(id),
 previous_status TEXT,
 new_status TEXT NOT NULL,
 evidence_reference TEXT NOT NULL DEFAULT '',
 private_note TEXT NOT NULL DEFAULT '',
 created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX IF NOT EXISTS idx_manual_payment_cases_status ON manual_payment_cases(status);
