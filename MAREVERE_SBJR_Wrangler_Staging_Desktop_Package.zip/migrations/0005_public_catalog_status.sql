-- Public research-catalog visibility and operational status. Separate from raw workbook data.
-- These statuses do NOT verify seller authority, title, asking price, media rights, or customer deposits.
CREATE TABLE IF NOT EXISTS public_vessel_states (
 vessel_id TEXT PRIMARY KEY REFERENCES research_vessels(vessel_id) ON DELETE CASCADE,
 status TEXT NOT NULL DEFAULT 'pending' CHECK(status IN ('available','pending','sold','out_of_stock')),
 is_visible INTEGER NOT NULL DEFAULT 1 CHECK(is_visible IN (0,1)),
 availability_verified INTEGER NOT NULL DEFAULT 0 CHECK(availability_verified IN (0,1)),
 seller_authority_confirmed INTEGER NOT NULL DEFAULT 0 CHECK(seller_authority_confirmed IN (0,1)),
 evidence_reference TEXT NOT NULL DEFAULT '',
 public_note TEXT NOT NULL DEFAULT '',
 updated_by INTEGER REFERENCES users(id),
 updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX IF NOT EXISTS ix_public_vessel_status_visible ON public_vessel_states(is_visible,status);
CREATE TABLE IF NOT EXISTS public_vessel_status_events (
 id INTEGER PRIMARY KEY,
 vessel_id TEXT NOT NULL REFERENCES research_vessels(vessel_id) ON DELETE CASCADE,
 actor_id INTEGER REFERENCES users(id),
 old_status TEXT,
 new_status TEXT NOT NULL,
 old_visible INTEGER,
 new_visible INTEGER NOT NULL,
 evidence_reference TEXT NOT NULL DEFAULT '',
 private_reason TEXT NOT NULL DEFAULT '',
 created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX IF NOT EXISTS ix_public_vessel_audit ON public_vessel_status_events(vessel_id,id DESC);
