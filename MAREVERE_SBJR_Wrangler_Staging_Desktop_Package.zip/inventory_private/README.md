# Private inventory data — intentionally not in this public repository

The source application expects research inventory, a private workbook, broker-listing media, a rights/source manifest, and approximate yacht-specific 3D files under this path. They are retained in the owner's original handover archive and are not committed here because the handover marks them private and publication rights are unresolved.

For local-only engineering, the owner may restore these files from the original archive into this ignored directory after verifying checksums. Do not copy them into public assets, publish them to a public Worker route, or upload them to R2 for a shared staging audience until written rights and the intended audience are confirmed. Use fictitious/cleared sample media for shared staging meanwhile.
