(()=>{'use strict';
const overlay=document.getElementById('serviceOverlay');if(!overlay)return;
let origin=null;const by=id=>document.getElementById(id);
function open(service){origin=document.activeElement;overlay.hidden=false;document.body.classList.add('modal-open');by('serviceStatus').textContent='';const option=[...by('serviceType').options].find(o=>o.value===service||o.textContent===service);if(option)by('serviceType').value=option.value;by('closeServiceDialog').focus()}
function close(){overlay.hidden=true;document.body.classList.remove('modal-open');origin?.focus()}
document.querySelectorAll('.service-request').forEach(x=>x.addEventListener('click',()=>open(x.dataset.service)));
by('closeServiceDialog').addEventListener('click',close);overlay.addEventListener('mousedown',e=>{if(e.target===overlay)close()});
document.addEventListener('keydown',e=>{if(overlay.hidden)return;if(e.key==='Escape'){e.preventDefault();close()}if(e.key==='Tab'){const els=[...overlay.querySelectorAll('button:not([disabled]),input,select,textarea')].filter(x=>x.getClientRects().length);if(e.shiftKey&&document.activeElement===els[0]){e.preventDefault();els.at(-1).focus()}else if(!e.shiftKey&&document.activeElement===els.at(-1)){e.preventDefault();els[0].focus()}}});
function load(){try{const v=JSON.parse(localStorage.getItem('marevere-fictional-service-draft')||'null');if(!v)return;by('serviceType').value=v.type||'Survey & inspection';by('serviceVessel').value=v.vessel||'';by('serviceWhen').value=v.when||'Exploring options';by('serviceNotes').value=v.notes||''}catch(e){}}
by('serviceDraftForm').addEventListener('submit',e=>{e.preventDefault();const state={type:by('serviceType').value,vessel:by('serviceVessel').value,when:by('serviceWhen').value,notes:by('serviceNotes').value};try{localStorage.setItem('marevere-fictional-service-draft',JSON.stringify(state));by('serviceStatus').textContent='Concept draft saved in this browser. Nothing has been sent.'}catch(e){by('serviceStatus').textContent='Storage unavailable; draft remains on this page and has not been sent.'}});
by('clearServiceDraft').addEventListener('click',()=>{try{localStorage.removeItem('marevere-fictional-service-draft')}catch(e){}by('serviceDraftForm').reset();by('serviceStatus').textContent='Local draft cleared.'});load();
})();
