# MAREVERE · SBJR — Phase 6.13 Local Integration

**Staging / fictitious-data engineering demonstration. Do not deploy publicly.** The brand name MAREVERE and SBJR identity are provisional; commercial acquisition arrangements and compliance requirements are unapproved.

## What this phase actually adds

The preserved Phase 6.12 marketing pages now link to `integrated.html`, a new role-aware interface backed by a Python standard-library HTTP service and an on-disk SQLite database.

Functional integration workflows:

1. **Buyer** signs in, retrieves six fictional vessels, saves/unsaves yachts, and submits a demo support case.
2. **Broker** signs in, submits an illustrative yacht listing, and sees its pending/approved/rejected status.
3. **Administrator** signs in, sees the broker submission, approves/rejects it, reviews demo support cases, marks them resolved, and inspects a local audit trail.
4. All records survive page refresh and process restart *on the same local machine*, unlike earlier browser-only mockups. Accounts are restricted by role at the API, not merely hidden by the UI.

**Nothing on this prototype records actual deposits, yacht ownership, investment yield, payments, fund custody, delivery, seller verification, live chat, or binding contracts.**

## Run the actual backend on a laptop or cloud development machine

Requirements: Python 3.10+; no pip install needed.

```sh
cd MAREVERE_Phase6_13_Integrated_Demo
python backend/app.py
```

If port 8765 is occupied, use:

```sh
MAREVERE_PORT=18765 python backend/app.py
```

Open **http://127.0.0.1:8765/integrated.html** (or port 18765). No internet access is required for the core application; remote fonts and the earlier concept Three.js import may require access.

On the **first run**, three randomly generated fictional demo accounts are created (buyer, broker and admin). Their temporary passwords are written to `.runtime/demo_credentials.txt` **on your own computer only**. This file is intentionally excluded from the downloadable ZIP. It must never be committed to GitHub or shared. The local demo server will print its location on startup.

The browser-only visual preview HTML provided alongside the ZIP lets you switch between example roles and inspect the UI on an Android phone, but it is explicitly **not** connected to this backend.

## Local test

With the server running:

```sh
python tests/integration_smoke.py
```

The test uses the generated local demo credentials, makes localhost HTTP requests and checks role permissions, sessions, CSRF and persistence. Tests add only fictional records to the local database. The tests are not a substitute for penetration testing or production review.

## Design preservation

All prior public design source from Phase 6.12 is included, including homepage, collection, vessel dossier, acquisition concept, showroom concept, marine shop, services, community and support. The SBJR mark stays in the public site's masthead and footer. A discreet footer link on public pages directs to the new connected portal.

**Security note:** Earlier static `account.html`, `seller.html`, and `admin.html` files are retained in the source archive for design history. When served through the **integration server**, navigating to those legacy mockup paths redirects to the central role-based portal. This does **not** secure the old static pages if someone separately hosts them with another generic server.

## Current blockers to a safe production launch

- Licensing/jurisdiction/business model and legal review of Tier 2 and Tier 3 (especially valuation-based financial benefits), including seller verification and consumer protections.
- Real account registration, recovery, email validation, MFA for privileged roles, production-grade identity provider and security controls.
- Financial settlement design using qualified partners, transaction ledger and independent reconciliation; never allow frontend assertions to constitute payment confirmations.
- Production database migrations, secrets management, encrypted storage, backups, monitoring, alerting, anti-abuse, audit retention and disaster recovery.
- Yacht inventory verification, actual vessel rights/media provenance, media delivery pipeline, secure uploads, compatibility/product catalog and real brokerage integration.
- Customer support delivery, spam handling, moderation, GDPR/privacy and retention requirements, notification system.
- Real integration browser E2E and independent security review. Browser navigation is restricted in this particular execution environment; the API was exercised through HTTP and the UI was rendered separately through a browser with mocked data.

**Status: local integration prototype / NOT production-ready.**
