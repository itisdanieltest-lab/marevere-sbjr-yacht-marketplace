'use strict';
// Display a protected static model preview even if the external Three.js module
// cannot load. The Three.js module replaces this preview when available.
(async()=>{
 const stage=document.getElementById('stage'), status=document.getElementById('modelStatus');
 try{
  const id=new URLSearchParams(location.search).get('vessel')||'';
  if(!/^MAREVERE-SBJR-[A-Z0-9-]+$/.test(id))throw Error('Unknown vessel ID');
  const ses=await fetch('/api/session').then(x=>x.json());
  if(ses.user?.role!=='admin')throw Error('Sign in as administrator through the operations portal.');
  const resp=await fetch('/api/admin/inventory/vessels/'+id);
  if(!resp.ok)throw Error('Research record is not available.');
  const {record:r}=await resp.json();
  const glb=r.media.find(x=>x.Media_Type==='3D'),preview=r.media.find(x=>x.Media_Type==='3D Preview');
  if(!glb)throw Error('No approximate model linked to this vessel');
  const title=document.getElementById('modelTitle');
  title.textContent=`${r.master.Display_Title} / ${glb.Media_ID} / APPROXIMATE STUDY`;
  const link=document.getElementById('rawLink');link.href=glb.private_media_url;link.hidden=false;link.download=glb.File_Name_or_URL.split('/').pop();
  if(preview&&stage.contains(status)){
   const img=document.createElement('img');img.src=preview.private_media_url;
   img.alt='Authenticated static preview of approximate, non-CAD vessel model';
   stage.replaceChildren(img);
  }
 }catch(e){if(stage.contains(status))status.textContent='Private 3D preview unavailable: '+e.message}
})();
