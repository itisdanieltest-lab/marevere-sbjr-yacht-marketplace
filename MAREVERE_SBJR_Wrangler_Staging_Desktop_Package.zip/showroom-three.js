/** Genuine Three.js model integration for MAREVERE · SBJR.
 * This demo loads an original, non-verified concept GLB, not a manufacturer model.
 * The module imports a pinned Three.js version from jsDelivr. Serve via HTTP.
 */
import * as THREE from 'three';
import { OrbitControls } from 'three/addons/controls/OrbitControls.js';
import { GLTFLoader } from 'three/addons/loaders/GLTFLoader.js';
const stage = document.getElementById('modelStage');
const shell = document.getElementById('viewerShell');
const statusEl = document.getElementById('modelStatus');
const reducedMotion = window.matchMedia('(prefers-reduced-motion:reduce)').matches;
let renderer,scene,camera,controls,model,water,sun,keyLight,fillLight;
let active = true, loaded = false, dusk = false, rafId = 0;
let waveTime = 0,lastTime = 0, cameraAnimating = false;
const targetPos = new THREE.Vector3(11,5.4,13);
const cameraViews = {
 'three-quarter': [11,5.4,13],port:[16,3.7,0.05],bow:[1.2,3.9,16],overhead:[2.6,17,2.5]
};
try {
 if (!window.WebGLRenderingContext) throw Error('This browser does not support WebGL.');
 const probe = document.createElement('canvas');
 const gl = probe.getContext('webgl2') || probe.getContext('webgl');
 if (!gl) throw Error('No hardware-accelerated WebGL context.');
 scene = new THREE.Scene();
 scene.fog = new THREE.Fog('#153645',21,64);
 camera = new THREE.PerspectiveCamera(35,1,.1,120);
 camera.position.set(...cameraViews['three-quarter']);
 renderer = new THREE.WebGLRenderer({antialias:true,alpha:true,powerPreference:'high-performance'});
 renderer.setPixelRatio(Math.min(window.devicePixelRatio||1,window.innerWidth<800?1.4:1.9));
 renderer.setClearColor('#071c28',0);
 renderer.outputColorSpace = THREE.SRGBColorSpace;
 renderer.toneMapping = THREE.ACESFilmicToneMapping;
 renderer.toneMappingExposure = 1.95;
 stage.appendChild(renderer.domElement);
 scene.add(new THREE.HemisphereLight('#dceff3','#254558',2.3));
 keyLight = new THREE.DirectionalLight('#fff6db',5.2);keyLight.position.set(8,13,5);scene.add(keyLight);
 fillLight = new THREE.DirectionalLight('#bce6ee',2.6);fillLight.position.set(-8,5,-8);scene.add(fillLight);
 const backLight = new THREE.DirectionalLight('#f7d1a1',2.6);backLight.position.set(2,3,-12);scene.add(backLight);
 water = new THREE.Mesh(new THREE.PlaneGeometry(120,120,40,40),new THREE.MeshStandardMaterial({color:'#234d5e',metalness:.35,roughness:.38,transparent:true,opacity:.80,side:THREE.DoubleSide}));
 water.rotation.x = -Math.PI/2;water.position.y=-.43;scene.add(water);
 const grid = new THREE.GridHelper(120,90,'#3a7282','#2d6272');grid.position.y=-.41;
 grid.material.opacity=.19;grid.material.transparent=true;scene.add(grid);
 controls = new OrbitControls(camera,renderer.domElement);
 controls.target.set(0,.70,0);controls.enableDamping=true;controls.dampingFactor=.075;
 controls.enablePan=false;controls.minDistance=8.7;controls.maxDistance=27;
 controls.maxPolarAngle=Math.PI*.49;controls.minPolarAngle=.20;
 controls.autoRotate = false;controls.autoRotateSpeed=.52;
 renderer.domElement.addEventListener('pointerdown',()=>{cameraAnimating=false;});
 const loadedGLB = await new GLTFLoader().loadAsync('assets/marevere_concept_yacht.glb');
 model = loadedGLB.scene;
 model.position.y=.14;
 model.rotation.y=-.18;
 scene.add(model);
 loaded=true;stage.classList.add('ready');
 document.getElementById('viewerPoster').style.opacity = '0';
 window.dispatchEvent(new Event('marevere-3d-ready'));
 const size=()=>{
  const w=stage.clientWidth, h=stage.clientHeight;
  if(w<1||h<1)return;
  camera.aspect=w/h;camera.updateProjectionMatrix();renderer.setSize(w,h,false);
 };
 new ResizeObserver(size).observe(stage);size();
 new IntersectionObserver((entries)=>{
   active=entries.some(e=>e.isIntersecting)&&!document.hidden;
   if(active&&!rafId){lastTime=0;rafId=requestAnimationFrame(render);}
 },{threshold:.05}).observe(shell);
 document.addEventListener('visibilitychange',()=>{active=!document.hidden && shell.getBoundingClientRect().bottom>0 && shell.getBoundingClientRect().top<innerHeight;if(active&&!rafId){lastTime=0;rafId=requestAnimationFrame(render);}});
 rafId=requestAnimationFrame(render);
 window.addEventListener('marevere-camera',e=>{
  const v=cameraViews[e.detail.view];if(!v)return;
  targetPos.set(...v);cameraAnimating=true;
  controls.autoRotate=false;
  const t=document.getElementById('toggleRotate');t.setAttribute('aria-pressed','false');
 });
 window.addEventListener('marevere-rotate',e=>{controls.autoRotate=e.detail.active&&!reducedMotion;});
 window.addEventListener('marevere-light',e=>{
  dusk=e.detail.dusk;
  keyLight.color.set(dusk?'#f4ae83':'#fff6db');
  keyLight.intensity=dusk?3.7:5.2;
  fillLight.intensity=dusk?1.4:2.6;
  renderer.toneMappingExposure=dusk?1.35:1.95;
  water.material.color.set(dusk?'#19384b':'#234d5e');
 });
 window.addEventListener('marevere-hotspot',e=>{
  const views={hull:'port',deck:'three-quarter',bridge:'overhead',bow:'bow'};
  targetPos.set(...cameraViews[views[e.detail.target]||'three-quarter']);cameraAnimating=true;
 });
 function render(now){
  rafId=0;if(!active||!loaded)return;
  const dt=lastTime?Math.min((now-lastTime)/1000,.08):.016;lastTime=now;
  if(!reducedMotion){
    waveTime+=dt; const positions=water.geometry.attributes.position;
    for(let i=0;i<positions.count;i++){
      const x=positions.getX(i), y=positions.getY(i);
      positions.setZ(i,Math.sin(x*.58+waveTime*.62)*.04+Math.cos(y*.42-waveTime*.47)*.045);
    }
    positions.needsUpdate=true;water.geometry.computeVertexNormals();
  }
  if(cameraAnimating && !controls.autoRotate){camera.position.lerp(targetPos,.065);if(camera.position.distanceTo(targetPos)<.06)cameraAnimating=false;}
  controls.update();renderer.render(scene,camera);
  rafId=requestAnimationFrame(render);
 }
} catch(err){
 console.warn('MAREVERE showroom 3D fallback:',err);
 if(renderer){renderer.dispose();renderer.domElement.remove();}
 statusEl.textContent='STILL PREVIEW / 3D UNAVAILABLE';
 window.dispatchEvent(new CustomEvent('marevere-3d-error',{detail:{message:String(err)}}));
}
