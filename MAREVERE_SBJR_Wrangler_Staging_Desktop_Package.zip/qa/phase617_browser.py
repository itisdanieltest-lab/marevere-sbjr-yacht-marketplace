"""Actual Playwright E2E QA for loopback MAREVERE. Not a simulated HTML preview.
When the environment blocks navigation, write an explicit BLOCKED result, never a pass.
"""
from pathlib import Path
from urllib.parse import urlparse
import json, os, re, sys
from playwright.sync_api import sync_playwright
ROOT=Path(__file__).resolve().parents[1]
BASE=os.getenv('MAREVERE_TEST_URL','http://127.0.0.1:8765')
u=urlparse(BASE)
if u.scheme!='http' or u.hostname not in ('127.0.0.1','localhost'):
    raise SystemExit('Browser QA is restricted to localhost. Do not run on real customers.')
OUT=ROOT/'docs/phase617';OUT.mkdir(exist_ok=True,parents=True)
PAGES=['index','collection','vessel','showroom','acquisition','shop','services','community','support','sign-in','register','recovery','security','account','seller','admin']
WIDTHS=[320,390,768,1024,1440]
checks=[]
errors=[]
def ck(label,good):
    checks.append({'test':label,'passed':bool(good)})
    print(('PASS ' if good else 'FAIL ')+label,flush=True)
    if not good:raise AssertionError(label)
def save(status,reason=''):
    p={'status':status,'reason':reason,'checks':checks,'total':len(checks),'passed':sum(x['passed'] for x in checks),'screenshots_created':list(x.name for x in OUT.glob('browser_*.png'))}
    (OUT/'browser_results.json').write_text(json.dumps(p,indent=2))
    return p
try:
 with sync_playwright() as pw:
    browser=pw.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox','--disable-dev-shm-usage'])
    ctx=browser.new_context(viewport={'width':390,'height':850},reduced_motion='reduce')
    page=ctx.new_page()
    try:
        page.goto(BASE+'/index.html',wait_until='domcontentloaded',timeout=11000)
    except Exception as e:
        if 'ERR_BLOCKED_BY_ADMINISTRATOR' in str(e):
            save('BLOCKED','Chromium policy denied navigation to both loopback and local files. No real browser E2E was performed.')
            print('BROWSER_BLOCKED_BY_ADMINISTRATOR',flush=True)
            browser.close();sys.exit(2)
        raise
    ctx.close()
    for width in WIDTHS:
        ctx=browser.new_context(viewport={'width':width,'height':860},reduced_motion='reduce',device_scale_factor=1)
        page=ctx.new_page();page.on('pageerror',lambda e:errors.append(str(e)))
        for route in PAGES:
            page.goto(BASE+'/'+route+'.html',wait_until='domcontentloaded',timeout=18000)
            ck(f'{route} main visible at {width}',page.locator('main').count()>0)
            ck(f'{route} H1 and brand identity at {width}',page.locator('h1').count()==1 and 'SBJR' in page.locator('header').first.inner_text())
            ck(f'{route} no horizontal overflow at {width}',page.evaluate('document.documentElement.scrollWidth <= window.innerWidth+2'))
            if width in (390,1440) and route in ('index','collection','vessel','showroom','acquisition','shop','support','account','seller','admin'):
                page.screenshot(path=str(OUT/f'browser_{route}_{width}.png'),full_page=False)
        ctx.close()
    # Genuine role-bound buyer journey: only executes after successful browser navigation.
    def login(role, route, width):
        import re
        credentials=(ROOT/'.runtime/demo_credentials.txt').read_text()
        row=next(line for line in credentials.splitlines() if line.startswith(role.upper()))
        email=re.search(r'[\w.+-]+@marevere\.invalid',row).group()
        password=row.split('PASSWORD: ')[1]
        c=browser.new_context(viewport={'width':width,'height':860},reduced_motion='reduce')
        p=c.new_page();p.on('pageerror',lambda e:errors.append(str(e)))
        p.goto(BASE+'/'+route,wait_until='domcontentloaded')
        p.locator('#loginPanel').wait_for(state='visible',timeout=12000)
        p.locator('[name=email]').fill(email)
        p.locator('[name=password]').fill(password)
        p.locator('#loginForm button[type=submit]').click()
        p.locator('#portal').wait_for(state='visible',timeout=15000)
        ck(role+' signs in via real browser at '+str(width),p.locator('#portal').is_visible())
        return c,p
    c,p=login('buyer','account.html',390)
    p.goto(BASE+'/collection.html',wait_until='domcontentloaded')
    p.locator('[data-save="tide"]').wait_for(timeout=9000)
    before=p.locator('[data-save="tide"]').get_attribute('aria-pressed')
    p.locator('[data-save="tide"]').click()
    p.wait_for_timeout(550)
    after=p.locator('[data-save="tide"]').get_attribute('aria-pressed')
    ck('buyer can change and persist fictional yacht bookmark',before!=after)
    p.goto(BASE+'/vessel.html?id=tide',wait_until='domcontentloaded')
    p.locator('#saveVessel').wait_for()
    p.wait_for_timeout(600)
    ck('buyer yacht dossier reads the same saved state',p.locator('#saveVessel').get_attribute('aria-pressed')==after)
    p.goto(BASE+'/shop.html',wait_until='domcontentloaded')
    p.locator('[data-add="kit"]').wait_for(timeout=10000)
    p.wait_for_timeout(400)
    old=int(p.locator('#bagCount').inner_text())
    p.locator('[data-add="kit"]').click()
    p.wait_for_timeout(700)
    ck('buyer marine bag synchronizes with backend',int(p.locator('#bagCount').inner_text())==old+1)
    c.close()
    c,p=login('seller','seller.html',390)
    p.goto(BASE+'/admin.html',wait_until='domcontentloaded')
    p.locator('#offline').wait_for(state='visible',timeout=9000)
    ck('seller cannot open administrator workspace', 'another role' in p.locator('#offline').inner_text())
    c.close()
    c,p=login('admin','admin.html',1440)
    ck('administrator workspace opens for correct role',p.locator('#roleBadge').inner_text()=='ADMIN')
    c.close()
    ck('no unhandled JavaScript exceptions in inspected pages',not errors)
    browser.close()
    save('PASS')
except SystemExit: raise
except Exception as e:
    save('FAIL',str(e)[:500]);print('BROWSER_FAILED',str(e)[:500],file=sys.stderr);sys.exit(1)
