"""One-command isolated LOCAL test harness, using fictional data. No cloud deployment.
Run: python qa/phase617_run.py
Creates local-only .runtime temporary credentials, and runs source/API/browser QA.
"""
import os,sys,subprocess,time,signal,json,socket
from pathlib import Path
import requests
ROOT=Path(__file__).resolve().parents[1]
PORT=int(os.environ.get('MAREVERE_QA_PORT','18767'))
BASE=f'http://127.0.0.1:{PORT}'
STEPS=[('static semantics', ['tests/phase616_audit.py']),
       ('HTTP and asset preflight',['qa/phase617_http_preflight.py']),
       ('buyer/seller/admin API',['tests/phase614_smoke.py']),
       ('security regression',['tests/phase615_security.py']),
       ('route checks',['tests/phase615_routes.py']),
       ('real Chromium E2E',['qa/phase617_browser.py'])]
report={'mode':'FICTIONAL_LOCAL_ONLY','base':'http://127.0.0.1:<loopback-port>','payments_enabled':False,'cloud_deployed':False,'tests':[]}
outdir=ROOT/'docs/phase617';outdir.mkdir(parents=True,exist_ok=True)
server=None
try:
    env={**os.environ,'MAREVERE_PORT':str(PORT),'MAREVERE_HOST':'127.0.0.1','MAREVERE_TEST_URL':BASE}
    with open(outdir/'local_server.log','w') as log:
        server=subprocess.Popen([sys.executable,'backend/app.py'],cwd=ROOT,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
        for _ in range(70):
            if server.poll() is not None:raise RuntimeError('Local server exited unexpectedly')
            try:
                if requests.get(BASE+'/api/health',timeout=1).status_code==200:break
            except requests.RequestException:pass
            time.sleep(.15)
        else:raise RuntimeError('Local server did not become healthy')
        for title,cmd in STEPS:
            print('\n### '+title,flush=True)
            start=time.monotonic()
            try:
                p=subprocess.run([sys.executable,*cmd],cwd=ROOT,env=env,text=True,capture_output=True,timeout=150)
                status='PASS' if p.returncode==0 else ('BLOCKED' if title=='real Chromium E2E' and p.returncode==2 else 'FAIL')
                # Only general logs, no credentials or tokens echoed by tests.
                (outdir/(title.replace('/','_').replace(' ','_')+'.log')).write_text(p.stdout + '\nSTDERR:\n' +p.stderr)
                report['tests'].append({'name':title,'status':status,'exit_code':p.returncode,'duration_seconds':round(time.monotonic()-start,1)})
                print(title,status,flush=True)
            except subprocess.TimeoutExpired:
                report['tests'].append({'name':title,'status':'FAIL','reason':'Timed out'})
                print(title,'FAIL (timeout)',flush=True)
finally:
    if server is not None and server.poll() is None:
        try:os.killpg(server.pid,signal.SIGTERM)
        except Exception:server.terminate()
        try:server.wait(timeout=4)
        except subprocess.TimeoutExpired:server.kill()
    report['overall']='PASS (LOCAL ONLY)' if all(x['status']=='PASS' for x in report['tests']) else 'INCOMPLETE — NO-GO'
    report['browser_real_e2e']=next((x['status'] for x in report['tests'] if x['name']=='real Chromium E2E'),'NOT RUN')
    report['production_release']='NO-GO'
    (outdir/'run_summary.json').write_text(json.dumps(report,indent=2))
    print('\nPHASE617_RESULT',report['overall'],'browser:',report['browser_real_e2e'],flush=True)
