"""Phase 6.17: actual HTTP response contract & static security checks on loopback only.
Does not certify the site's browser behavior, authorization in production or compliance.
"""
from pathlib import Path
import os, json, struct, subprocess
from urllib.parse import urlparse
import requests
ROOT=Path(__file__).resolve().parents[1]
BASE=os.getenv('MAREVERE_TEST_URL','http://127.0.0.1:8765')
u=urlparse(BASE)
if u.scheme!='http' or u.hostname not in ('127.0.0.1','localhost') or not u.port:
    raise SystemExit('Preflight is restricted to an explicitly ported loopback fictional demo.')
results=[]
def ck(label,success,detail=''):
    results.append({'check':label,'passed':bool(success),'detail':detail})
    print(('PASS ' if success else 'FAIL ')+label,flush=True)
    if not success: raise AssertionError(label + ' '+detail)
def get(path):return requests.get(BASE+path,timeout=8)
health=get('/api/health')
ck('Health endpoint is fictional / payments off',health.status_code==200 and health.json().get('mode')=='LOCAL_DEMO' and health.json().get('payments_enabled') is False)
ck('Browser security response headers',all(health.headers.get(h) for h in ['Content-Security-Policy','X-Frame-Options','X-Content-Type-Options','Referrer-Policy']))
ck('No real checkout API',get('/api/payment/checkout').status_code==404)
ck('Unauthenticated privileged roles denied',all(get(x).status_code==401 for x in ('/api/admin/audit','/api/seller/listings','/api/cart','/api/saved')))
ck('Illegal Host header is rejected',requests.get(BASE+'/api/health',headers={'Host':'unsupported.example'},timeout=8).status_code==400)
for forbidden in ['/.runtime/demo_credentials.txt','/backend/app.py','/migrations/0001_init.sql','/tests/phase615_security.py','/design_archive/admin.html']:
    ck('GET restricted '+forbidden,get(forbidden).status_code==404)
    r=requests.head(BASE+forbidden,timeout=8)
    ck('HEAD cannot bypass restricted route '+forbidden,r.status_code in (404,405))
for route in ['index','collection','vessel','showroom','acquisition','shop','services','community','support','sign-in','register','recovery','security','account','seller','admin','integrated']:
    r=get('/'+route+'.html'); body=r.text
    ck('Page served with MAREVERE/SBJR and HTML: '+route,r.status_code==200 and 'text/html' in r.headers.get('Content-Type','') and '<html' in body.lower() and 'SBJR' in body and 'MAREVERE' in body)
for file in ['assets/marevere_concept_yacht.glb','assets/marevere_cinematic_motion_study.mp4','assets/hero.webp','assets/fallback-still.webp']:
    r=get('/'+file)
    ck('Media delivered with supported content type '+file,r.status_code==200 and len(r.content)>1000 and r.headers.get('Content-Type','').split(';')[0] in ('model/gltf-binary','application/octet-stream','video/mp4','image/webp'),r.headers.get('Content-Type',''))
model=(ROOT/'assets/marevere_concept_yacht.glb').read_bytes()
ck('3D concept is a structurally identified GLB file',model[:4]==b'glTF' and struct.unpack('<I',model[8:12])[0]==len(model))
movie=ROOT/'assets/marevere_cinematic_motion_study.mp4'
probe=subprocess.run(['ffprobe','-v','error','-show_entries','format=duration:stream=codec_name,width,height','-of','json',str(movie)],text=True,capture_output=True,timeout=12)
if probe.returncode==0:
    md=json.loads(probe.stdout)
    ck('Cinematic MP4 decodes in media probe',float(md['format']['duration'])>0 and any(s.get('codec_name') in ('h264','hevc','av1','mpeg4') for s in md['streams']))
else:
    results.append({'check':'Cinematic MP4 media probe','passed':None,'detail':'ffprobe unavailable or failed; requires review'})
report={'phase':'6.17','scope':'Local localhost-only HTTP/asset/negative-route checks. Not a live cloud staging deployment.', 'passed':sum(c['passed'] is True for c in results),'total':len(results),'failed':[c for c in results if c['passed'] is False], 'cases':results,'payments':'OFF','production_release':'NO-GO'}
(ROOT/'docs/phase617/http_preflight.json').write_text(json.dumps(report,indent=2))
print('HTTP_PREFLIGHT',report['passed'],'/',report['total'])
