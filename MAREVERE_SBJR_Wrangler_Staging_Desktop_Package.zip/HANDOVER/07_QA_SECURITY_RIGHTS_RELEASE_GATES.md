# 07 — QA, Security, Rights and Release Gates

## Verified historical results vs unverified claims

- Phase 6.16 source/static semantics: 671/671; local API 35/35; security 43/43; routes 20/20. These checklists overlap and do NOT prove overall feature completeness.
- Phase 6.17 local HTTP+media: 38/38; browser-to-local-server navigation was BLOCKED (`ERR_BLOCKED_BY_ADMINISTRATOR`); *zero* genuine live E2E browser tests in that phase.
- Phase 6.19 public status control tests: 38/38; inventory regression: 45/45; offline visual previews at 320/390/768/1024/1440.
- Phase 6.20 public media tests: 42/42; status regression 38/38, inventory regression 45/45; five width responsive checks and gallery screenshots. These verify a **local** source app, not a launched domain.
- Current disposition: **PRODUCTION NO-GO**. Avoid claiming all pages operate perfectly on Android/desktop under real backend.

## Required test matrix (Work should produce actual evidence)

**Public:** homepage/nav and brand; fleet loaded from correct DB data; three stable IDs; missing fields not guessed; status indicator; search/filter; photo thumbnail click and previous/next; full MP4 seeking and `Range` 206; HD/SD quality note; sold and out-of-stock enquiry route; hidden yacht and media return 404.

**Role:** visitor cannot use admin controls; buyer cannot see others' saved data, manual payments or admin-only evidence; seller only own submissions; admin can status/visibility with evidence and audit; directors not provisioned until roles signed off. Verify CSRF, cookie SameSite/HttpOnly, session expiry/logout/revoke/password recovery, rate limiting and request-size limits.

**Admin:** Pending → Available only with verified authority and dated evidence; Available → Out of Stock; Sold with evidence; hide/show; status persistence across restart/reimport; audit log attribution; manual payment register lacks real money execution.

**Site:** 320/390/768/1024/1440, portrait and desktop, Android and Chrome, keyboard/screen reader semantics, reduced motion, loading states, alt text, contrast, no overflow, media fallback, no long blocking video downloads, Three.js WebGL fallbacks, font failure, broken links, client JS runtime logs.

**Security:** secrets exclusion, no access to `.runtime/`, `inventory_private/` workbook/private GLB/raw source via URL, no leaked photo/video source rights metadata, denied hidden media IDs, host/origin/HEAD restrictions, secured imports, no production demo credentials, test instrumentation disabled, validated uploads, backups and monitoring.

**Performance:** media optimization, responsive variants, image dimensions, lazy loading, cache/CDN, Web Vitals/LCP, load test with catalogue growth, pagination/server-side search, video streaming and GLB size, privacy-safe telemetry. No throughput claim without measurement.

**Business/legal:** documented seller mandate, title/current availability verification, current price/terms and taxes, licensed use of all photo/video/brand assets, rights for commercial territory and duration, approval of each tier's legally precise contract, regulatory/consumer/KYC checks if required, cancellation/refund/disputes and privacy/GDPR-like region-specific policies. User requested public display; this is not proof of source copyrights.

## Staging/production separation

1. **Protected staging first:** HTTPS, access controls, fictional data, separate configuration, no search indexing, no real payment gateway, no live client data.
2. **Real browser E2E** against deployed staging; investigate any failures; independent security/accessibility and contract review.
3. **Public informational launch only after owner approval and rights/claims checks**, appropriate production identity/infra, monitoring and privacy policies. Public browsing is distinct from turning on payments or contractual “buy now.”
4. **Financial transaction launch as a separate explicit gate** only with director/legal approval and independently confirmed settlement infrastructure. Do not implement manual admin “paid” statuses as bank transfer proof.

## Release report format

For every release: source commit/checksum; exact environment and tested URLs; original approved logo screenshots; 5-viewport shots for homepage/fleet/details/admin; real gallery video test; API and security test counts with scope; limitations/open risks; business approval identifiers; final GO/NO-GO with signatory.
