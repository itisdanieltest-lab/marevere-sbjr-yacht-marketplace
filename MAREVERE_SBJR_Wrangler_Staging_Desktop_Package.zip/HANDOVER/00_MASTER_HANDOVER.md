# MAREVERE · SBJR — MASTER HANDOVER TO CHATGPT WORK

**Handover snapshot:** 18 November 2026  
**Latest complete engineering baseline:** Phase 6.20 — public-facing vessel photography and video, local-only Python/SQLite prototype.  
**Owner's instruction:** Transfer the *entire* established project and plan to ChatGPT Work without design, scope, identity, or data loss. Continue toward an internet-accessible premium yacht marketplace, using three researched vessels while obtaining more verified inventory. The administrator maintains vessel statuses and manually records payment-related information for now. Three directors review and authorize commercial/contract decisions.

## ABSOLUTE PRIORITIES — read before editing

1. **Never replace, regenerate, simplify, or redesign the approved logo.** Source of truth is the exact SVG/wordmark markup and visual identity in `SITE_SOURCE/index.html` and `SITE_SOURCE/docs/APPROVED_LOGO_PRESERVATION.md`. MAREVERE dominates; SBJR remains subtly visible in the header/masthead AND bottom/footer identity. Existing logo paths/gradients and approved presentation are locked. References in `DESIGN_AND_HISTORY_REFERENCES` are *historical*; they do NOT supersede the most recently approved live-source logo. Any modification requires express user approval.
2. **Preserve the entire approved mobile-first premium luxury experience**, not merely its homepage or a visual-only portal. `SITE_SOURCE/` is canonical. Earlier designs and previews are reference material; do not overwrite the latest working code with an old ZIP. Preserve public site, yacht collection, 3D showroom, all acquisition configurations, marine shop/services, community/support, buyer, seller/broker, and administrator operations.
3. **Preserve the exact workbook-based IDs and full evidence/source fields.** Three research yacht records are imported. Do not mistake research leads for MAREVERE-owned/authorized inventory. See `04_INVENTORY_AND_MEDIA.md`.
4. **Four public catalogue statuses:** `Available`, `Pending`, `Sold`, `Out of Stock`; separate `Visible/Hidden` control. Only an authorized administrator may change status; every change must record who, when, the reason, and evidence. Buyer should see status and an appropriate inquiry route; a research price is *not* a binding offer.
5. **Manual payment status — no auto-payment.** Administrator may enter or update internal payment-case evidence/status after independent external reconciliation. The current local tool only supports demo notes. No deposits, bank transfers, escrow, settlement, ownership transfer or paid confirmations are actually verified by the prototype. Do not turn an admin click into proof of funds or entitlements.
6. **Three directors are commercial sign-off stakeholders** for real acquisition/fee terms, supplier authorization and approved publication/release decisions. Their personal names, permissions, quorum, and legal authority have NOT been supplied; do not invent names/credentials, claim sign-off, or confuse directors with the current single demo admin. Build a proposed review/approval matrix and ask the user to confirm it before enforcing real director workflows.
7. **Three-tier acquisition identity must survive**, with *four selectable configurations*: Tier 1 Full/Outright; Tier 2 Premium I; Tier 2 Premium II; Tier 3 Deferred. Hypothetical 50% contributions, a possible 5% completion fee, and valuation-based adjustments are **proposals only**, NOT director-approved terms, guaranteed gains, investment promises or contractual offers. Do not launch real payment collection or sign contracts until terms and jurisdictional rules receive proper approval.
8. **Keep original vessel images/video tied to their parent IDs.** Phase 6.20 publicly exposes 10 photographs and 1 video for each of 3 yachts *in the localhost application*. Owner requested public display; written third-party media rights remain undocumented. Before distributing on the open internet, verify license/authorization and publish only cleared material. Three vessel GLB reconstructions are approximate, not maker-/survey-validated, and must never be presented as verified representations.
9. **Do not call the project deployed or production-ready.** It currently binds `127.0.0.1` by design. Cloud hosting, HTTPS, actual production staff identity and public domain deployment have not been demonstrated. Browser-to-backend end-to-end testing was previously restricted. No real transactions are enabled. The agreed final goal is a secured, functioning, premium, internet-accessible platform with director-approved business rules—not a set of isolated previews.
10. **Do not rush or silently invent missing facts.** Inspect the source, test sequentially, record gaps and evidence, and preserve all previous approvals. Work from mobile 320/390 upward to tablet 768 and desktop 1024/1440.

## The source of truth hierarchy

1. Latest explicit user instructions and director-provided signed agreements/authorized evidence (when obtained).
2. Approved logo and visual foundation in **latest** `SITE_SOURCE/` plus `docs/APPROVED_LOGO_PRESERVATION.md`.
3. Source workbook `SITE_SOURCE/inventory_private/MAREVERE_SBJR_Inventory_Research_Catalog_v2.xlsx`, its `FINAL_RECONCILIATION.md`, media manifest and normalized mapping, *as evidence for research claims only*.
4. Working source and tests in `SITE_SOURCE/` (most recent engineering baseline).
5. This handover for requirements, unresolved decisions and sequential plan.
6. Older reference ZIPs are archival design history, not instructions to revert code.

## Directory orientation

```
START_HERE_FOR_CHATGPT_WORK.md    <- Start here (copy of this master entry)
SITE_SOURCE/                      <- The complete unmodified latest Phase 6.20 site/backend/data/media/tests
HANDOVER/                         <- Detailed scope, business terms, roles, inventory, architecture, release plan
DESIGN_AND_HISTORY_REFERENCES/    <- Historical logo/design/wireframe/storyboard sources (DO NOT overwrite latest site)
PREVIEWS/                         <- Offline visual references; previews are not a live backend
CHECKSUMS_AND_CONTENTS.json       <- File hashes/sizes and baseline provenance
```

## First actions for ChatGPT Work

**A.** Extract archive and read *all* `HANDOVER/*.md`, then inspect `SITE_SOURCE/START_PHASE6_20.md`, `START_PHASE6_19.md`, `docs/APPROVED_LOGO_PRESERVATION.md`, `inventory_private/FINAL_RECONCILIATION.md`, `docs/phase617/PHASE6_17_STAGING_QA_REPORT.md` and source code, including server route restrictions and role controls.

**B.** Inventory every page, executable script, dependency, migration, test, image, MP4, workbook, media mapping and 3D model. Run CRC/checksum checks, inspect approved logo untouched and record any inconsistencies in a factual audit. Preserve original data and backups.

**C.** Run the local-only prototype on a suitable authorized machine (`cd SITE_SOURCE && python backend/app.py`), using locally generated fictional accounts. Run local tests; then use Work's authorized browser to complete actual browser-to-backend journeys and device screenshots. Existing source QA counts do **not** establish a passing live browser E2E or production readiness.

**D.** Address one coherent backend+UI flow at a time; do not abandon the existing cinematic site. Implement/verify public vessel galleries and inquiries, admin 4-state status handling + visibility, manual payment-case review, buyer/seller/admin role boundaries, audit trail, and director approval recording *only after confirming real director identities/rules*.

**E.** Produce a clear release readiness matrix. For limited public informational browsing, establish appropriate secure hosting, verify image/video publication rights, seller representation and fact labels, and user authorization of exact domain/deployment target. Keep purchases and Tier 2/Tier 3 legal/financial actions disabled until approved. Do not expose the localhost Python demonstration server to the internet.

**F.** On every phase deliver a source ZIP, changed-file list, QA logs, actual mobile and desktop screenshots, tested staging/production URLs *only when real*, and open blockers. Request explicit authorization before executing irreversible deployment/account/payment actions.

## Known status (not claims of completion)

- Three **research** yachts: ANYA, CLASSIC 40M BENETTI, ARISTARCHOS I. Initial admin statuses: Pending, Pending, Sold, respectively. Zero vessels independently verified as MAREVERE-controlled current active inventory.
- Thirty public-to-local-gallery yacht photos; three full videos with range streaming; three private approximate 3D GLB + editable Blender versions. Source workbook retained with all 16 research sheets, and manifest for provenance.
- Browser-only public preview contains short video **excerpts**. `SITE_SOURCE` includes original full videos. Do not substitute preview clips as the originals.
- Admin can change status and visibility in a local database (with server role+CSRF+audit), and update fictional manual payment notes; there is **no real payment processing**.
- All primary website sections remain source prototypes. Public internet publishing is *NOT DONE*; hosting and production readiness are pending.

## Human instruction you can paste into ChatGPT Work

> Extract `MAREVERE_SBJR_GPT_WORK_COMPLETE_HANDOVER_2026-11-18.zip`. Read `START_HERE_FOR_CHATGPT_WORK.md` and **every file in `HANDOVER/`** before changing anything. Use `SITE_SOURCE/` as the canonical latest source. Preserve my exact approved MAREVERE · SBJR logo and mobile-first luxury design, the complete three-tier/four-configuration acquisition model, and the three research yacht IDs plus all workbook specifications, photographs, full videos and separate approximate 3D models. Audit and test the actual integrated site. Prepare the public catalogue, inquiry and admin status + manual-payment workflows; maintain director approval gates and privacy/media/licensing safeguards. Do not invent inventory rights, prices, legal terms, completed tests or live deployment. Produce reviewed source, QA evidence, screenshots and a release plan; ask me for the real public domain/deployment approval and director decisions at their decision gates. Never overwrite the latest source with earlier prototype archives.

**Read next:** `HANDOVER/01_FULL_PRODUCT_VISION_AND_SCOPE.md` through `HANDOVER/12_DEFINITION_OF_DONE_AND_DELIVERABLES.md`.
