# 08 — Sequential Plan for ChatGPT Work

**Do not substitute planning documents for actual implemented/tested deliverables.** Work in this order, respecting the user's “no rushing / cross-check sequentially” direction.

## Step 0 — Provenance and baseline snapshot

- Read `00_MASTER_HANDOVER.md`, all handover docs, and latest phase docs.
- Verify ZIP CRC + `CHECKSUMS_AND_CONTENTS.json` against unpacked files, inventory workbook sheets and 30/3/3 media counts.
- Identify source version and compare approved logo SVG/header/footer exactly; create read-only baseline/checksum and working Git branch/backup (do not claim Git repo exists unless connected).
- Audit current source vs handover status; write a discrepancy ledger, preserve all files and report factual mismatches.

## Step 1 — Genuine connected user journeys in Work's browser

- Run loopback Python/SQLite prototype on an authorized Work computer; collect login sessions and browser screenshots in a controlled fictional-data environment.
- Test homepage → fleet → actual photo/video dossier → inquiry, buyer saves, seller proposal → admin review, admin Pending/Sold/Out of Stock + show/hide → public refresh, manual payment notes with no financial side effects.
- Fix issues without wholesale rewriting approved visual components; regression-test.

## Step 2 — Complete coherent catalogue/inquiry & admin UX

- Ensure correct vessel labels, actual workbook technical specs, correct parent media IDs, 10-photo carousel/video for each. Status CTA correctly displays **Enquire** or inactive, NEVER a deposit button for unapproved inventory; use sold/out-of-stock visibility per owner's latest request.
- Improve public filter/search/pagination to support 30–60 later; make admin upload/import review workflow robust, with content QA, evidence refs, dated price and status updates, media licensing review.
- Connect pre-signup support and membership inquiry to real queued backend ticket with anti-spam only after secure auth and privacy requirements.

## Step 3 — Directors, commercial terms and manual payment policy

- Prepare clear director decision packet covering all four acquisition configurations and legal implications, without pretending terms are approved.
- Ask owner to confirm the three directors' names/roles, scope, approval quorum, legal entity, regions and authorization. Do not create fictitious accounts or sign decisions for them.
- Design versioned sign-off, per-yacht tier eligibility, admin-only operational status, reconciliation evidence and audit trails; keep real money, ownership and contracts blocked until explicit approved policy.

## Step 4 — Production-grade architecture and security plan

- Replace localhost demo identity with verified user accounts, genuine staff security/MFA, hardened auth, proper secrets, database service, migrations/backups, storage/CDN/media processing, logging, abuse limits, privacy/deletion and support operations. Validate all before opening to public visitors.
- Keep original workbook and complete asset media with unique IDs, access flags and version history. Never ship private evidence as publicly downloadable files.
- Select deployment/cloud/database/domain only with owner's decision and connected authorization; avoid guessing a domain or saying an account is already connected.

## Step 5 — Mobile-first visual/functional QA and protected staging

- Use actual browser/device matrix at 320/390/768/1024/1440, Android, desktop, touch, reduced motion, screen readers, WebGL, MP4 seeking, roles, content and rate tests.
- Produce photographic/video dossier screenshot set. Confirm exact logo and all critical flows; document any non-passing tests.
- Protected staging with fictitious/cleared sample assets, private access, no paid functionality and a review URL. Ask owner/three directors for release decisions at exact points.

## Step 6 — Rights-cleared public informational publication

- Once seller and media licenses, current availability/claim warnings and owner authorization are documented, publish accessible no-checkout fleet/website on secure HTTPS and known approved domain. Admin can set Pending/Available/Sold/Out of Stock and visibility; ensure true API updates and audit.
- Retain honest prices/status, original HD galleries and non-misleading media credit. Do not publish private source/legal files or real financial records. Complete rollback/monitoring plan.

## Step 7 — Next content and ecosystem roadmap

- Expand verified yacht inventory in batches (10–15 first, target 30–60), varied categories, 10–20 rights-cleared media per vessel where available, real 3D on verified assets only. Include correctly tagged photos/videos/CDN.
- Populate genuine marine products, SKU/compatibility/supplier/stock and vetted repair/survey/furniture/delivery services.
- Implement live support, member community, moderation, delivery/ownership documentation, then approved contract/payment integrations as independent release gates.
- Load/scale tests before making catalogue/traffic capacity claims.

## Output at each step

Versioned complete source, exact changes and preserved brand hash, test evidence, actual screenshots, blockers vs approvals, safely reproducible run/deploy instructions, and explicit GO/NO-GO. No promises of background execution or invisible deployment.
