# 05 — Roles, Operating Boundaries and Manual Payment Records

## Roles and separation of responsibility

**Visitor:** May browse authorized public catalogue, technical details, photos/videos, proposed tier explanations, products/services info, community resources and visitor-support FAQs. Inquire without being forced to register where appropriate. No privileged data.

**Buyer/member:** Registration, secure sign-in, favorites, saved vessel, price/status tracking, personal enquiries, support cases, future agreed documents and legitimate manually reconciled payment milestones. Must not access other members' records or seller/admin controls.

**Seller/broker:** Submit authorized listings, edits, media and evidence; track listing review, enquiries and client communications. Must not publish/hide the global catalogue unilaterally, or claim MAREVERE verification without admin.

**Administrator (current one local demo admin):** Review content/evidence, manage `Available/Pending/Sold/Out of Stock`, show/hide, record reasons and audit history, moderate/route enquiries, review broker applications, and maintain the **manual payment-case register**. The admin is operational staff, not the three directors. Admin changes must be authenticated, role-authorized, logged and reversible where possible.

**Three directors (new governance requirement):** Commercially review/authorize actual Tier 1/2/3 terms, offering eligibility, legal contracts and final release decisions according to a **to-be-confirmed approval policy**. Do not manufacture names, signatures or recorded approval, and do not give demo admin director powers by default. Before building live director accounts, collect identity/role/signer permissions, approval thresholds/quorum, business entity and jurisdictions from owner.

## Admin listing state machine

- `Pending`: verification, authority, seller review or prospective reservation in process; differentiate internal verification from actual buyer hold/reservation. Avoid misleading “sold soon” claims.
- `Available`: confirmed current stock/agency, with evidence and recorded authority; public enquiry enabled, sale process subject to contract.
- `Sold`: evidenced completed disposal/sale. Public record may remain with “Sold” badge and historical price warning; no buy action.
- `Out of Stock`: temporarily no authorized/active availability. Public status and inquire/notify option can remain; do not claim source is permanently sold.
- `Visible/Hidden`: independent visibility control. Hidden listing and its public media must be inaccessible; do not leave exposed direct media URLs. Audit every transition with reason/evidence/time/actor.

Current research starting states are Pending, Pending, Sold; **not** Out of Stock for all three. If the owner/directors instruct a different default, document their decision and evidence, update through admin controls, and preserve audit history.

## Manual payment register: exact current scope

Current `SITE_SOURCE/admin-inventory.html` and `inventory-admin.js` have a protected demo register. Its statuses include:

`awaiting_external_review`, `buyer_reported`, `evidence_reviewed`, `marked_paid_offline`, `disputed`, `cancelled`.

These are **case-note labels**; not proofs that money moved. The current local backend can log manually entered fictional cases with amount and buyer reference; it **does not** verify external bank transfers, process gateway payments, capture/hold funds, issue legal title, or autonomously deliver a yacht. Do not expose these fields to unrelated users. For any real use, create independent verification by authorized finance staff, double-check of funds receipt, supporting document ID, timestamp, reconciled account, dispute process, least privilege and irreversible-entry policy; require legal/organizational approvals first.

## Future commercial lifecycle (not currently implemented end-to-end)

Enquiry → seller authority and yacht QA → director-approved price/tier/contract → ID checks as lawful → inspection/survey → buyer approval → contract signing → external funds reconciliation → ownership title & delivery documentation → handover → service/support. Each stage has documents, actor and audit timestamp. The website must not automatically equate any stage to actual ownership or paid funds.
