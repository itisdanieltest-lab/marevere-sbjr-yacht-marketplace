# 02 — Approved Brand, Logo and Design Lock

**Critical user direction:** “Don't replace my logo, use our approved logo.” The mark is not open to reinterpretation.

## Canonical identity

- Name: **MAREVERE** (dominant), with **SBJR** visibly but subtly integrated in header/masthead and footer/bottom identity. Do not rename to another yacht brand, remove SBJR, or assert registration of a domain.
- **Approved source reference:** `SITE_SOURCE/index.html` inline header SVG `brand-mark` + accompanying wordmark and footer identity. See `SITE_SOURCE/docs/APPROVED_LOGO_PRESERVATION.md`.
- The approved logo must also appear in inventory-admin, buyer, broker, admin, gallery and any new view. **Reuse exact markup/path/gradient**, do not introduce a newly generated graphic or generic “M” placeholder.
- Older `DESIGN_AND_HISTORY_REFERENCES` are useful to understand rationale, not to override the latest approved branding. Previous MAREVERE V3 was approved as a **visual foundation, not the final complete website**.

## Visual and interaction invariants

- Editorial, asymmetric precision; elegant composed boxes/columns; marine blue/graphite, warm ivory and quiet brass highlights; excellent typography and whitespace; cinematic appropriate photographs/videos where licensed.
- Mobile-first 320/390 followed by 768/1024/1440. Preserve responsive nav behavior, full content, clear member/admin access and smooth loading transitions with `prefers-reduced-motion` alternatives.
- Preserve the real product and business model. A gorgeous hero that loses the collection, buying tiers, services or support is a regression.
- Ensure header/footer brand visible across all pages and zoom levels; don't swap logos for admin-only “utility” layouts. Any new logo/wordmark change must receive explicit user approval.

## Verification before any handoff iteration

1. Capture original checksum of `SITE_SOURCE/index.html` and approved markup before editing; compare new homepage SVG path/gradient and footer identity after changes.
2. Navigate every major page and inspect logo and lower brand on phone+desktop; test accessibility label and color contrast.
3. Compare against original screenshots inside `SITE_SOURCE/docs` and design-history references; spot-check home, collection, dossier, admin inventory, acquisition, shop, seller and member.
4. Preserve or update only with explicit authorization when something is truly a brand change; don't claim a redesign is merely “polish.”
