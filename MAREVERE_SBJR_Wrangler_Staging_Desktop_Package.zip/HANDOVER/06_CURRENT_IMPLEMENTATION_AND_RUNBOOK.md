# 06 — Existing Architecture / Actual Local Runbook

## Canonical code

`SITE_SOURCE/` is the latest **Phase 6.20** website + server + migrations + tests + workbook + all original photos/videos and private 3D resources. Previous phases are incorporated into this source; review historical files ONLY when checking design rationale. This is an implementation snapshot, **not** production-ready cloud service.

### Runtime stack

- HTML/CSS/JavaScript frontends (native), responsive and accessible-design attempts.
- Python standard-library `http.server` application: `SITE_SOURCE/backend/app.py`. Intentionally binds loopback `127.0.0.1`, default port `8765`.
- SQLite local database, created under excluded `.runtime/` with migrations `migrations/0001_init.sql` through `0005_public_catalog_status.sql`.
- Locally generated fictional demo credentials under `.runtime/demo_credentials.txt`. Never transfer, email, commit or publish these generated secrets; the ZIP excludes runtime state.
- Password hashing and token-based sessions/CSRF/role controls within demo. Not production identity, distributed security or finance-grade audit.
- Source media in `inventory_private/` (private raw source path), public image/video access via vetted API. 3D GLB/Blender source private; original workbook private.

### Local execution

```bash
cd SITE_SOURCE
python3 backend/app.py
```

Open **on the same computer** (not Android unless a secure preview server is specifically provisioned):

- `/` or `/index.html`: approved cinematic homepage.
- `/fleet.html`: public yacht collection with correct photos and full MP4 video.
- `/vessel.html`: earlier cinematic concept dossier (don't confuse with live research dossier).
- `/showroom.html`: Three.js concept viewer.
- `/acquisition.html`: four configuration/three tier concept calculator.
- `/shop.html`: marine products concept/cart.
- `/services.html`: specialist services.
- `/community.html`, `/support.html`: member/editorial and scripted support UI.
- `/integrated.html`: connected role-based buyer/broker/admin demo.
- `/admin-inventory.html`: authenticated admin research, statuses, visibility, evidence, manual payment notes.
- `/account.html`, `/seller.html`, `/admin.html`, `/sign-in.html`, `/register.html`, `/recovery.html`, `/security.html`: role/account interfaces and legacy redirects; verify behavior in running server.

For a free port: `MAREVERE_PORT=18765 python3 backend/app.py` (when supported by code). Do not set external bind address or port forward the demo.

### API and capability inventory

- Public vessel catalogue/dossier and allowlisted photograph/MP4 routes.
- Buyer registration/login in local demo, saved yacht, marine bag and support ticket local DB flows.
- Seller demo submission; admin approvals/rejections/audit + support ticket closure.
- Research inventory read for admin, status change/show/hide with CSRF/role checking/audit, internal manual payment note creation/change.
- Local recovery tokens and account-security demonstration only; production email, verification, MFA and external identity providers absent.
- Real purchase, payment/settlement/escrow, binding contracts, fully actual real-time support, marine checkout, and verified public ownership all **NOT implemented**.

### Critical source files

`index.html` and `styles.css` for approved visual base; `fleet.html`, `fleet.js`, `fleet.css` for 3 research public listings; `inventory-admin.js`, `admin-inventory.html`, `inventory-admin.css` for admin controls; `backend/app.py` and `migrations/`; `acquisition.html`/`acquisition.js` for tier concepts; `inventory_private/` workbook/source/media; `docs/phase620/` media QA and screenshots; `tests/` for regressions.

### Existing tests (run and log)

```bash
python3 tests/phase619_public_catalog.py
python3 tests/phase620_public_media.py
python3 tests/phase618_inventory.py
python3 tests/phase615_security.py
python3 tests/phase614_smoke.py
```

Some tests start local servers or need a base URL; inspect each header before running. `SITE_SOURCE/RUN_GUIDE.md` and individual phase docs list particular commands. Run in isolated fictional-data environment and re-run after every substantial change. Use a full authorized GUI browser for E2E because previous environment blocked localhost navigation.

## What to build, not fake

The earlier `VISUAL_ONLY_PREVIEW.html` and `PREVIEWS/*.html` render samples with illustrative state and can be opened on a phone. They are NOT the same as an authenticated server. No real site URLs or server-connected tests should be claimed from them. Cloud host is currently unset; the employer owns the eventual publication/credentials/domain decisions.
