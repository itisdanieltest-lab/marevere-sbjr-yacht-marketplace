# 04 — Vessel Inventory, Media ID Mapping and Publishing Evidence

## Canonical inventory

`SITE_SOURCE/inventory_private/MAREVERE_SBJR_Inventory_Research_Catalog_v2.xlsx` is the most complete imported workbook. Keep every sheet, internal source/evidence field, missing-value status, and parent/child identifier. The spreadsheet currently has **16 worksheets** per prior archive inspection; verify sheet list again at intake. `inventory_private/inventory_normalized_private.json` supports API import; do not replace the original workbook with derived fields.

Three entries:

| Stable ID (do not change) | Vessel | Research price* | Default app status | Publication caveat |
|---|---|---:|---|---|
| `MAREVERE-SBJR-MOTOR-YACHT-001` | ANYA, Sunseeker 40 m | €9,495,000 | `pending` | Seller authority/current availability, some technical claims disputed. |
| `MAREVERE-SBJR-MOTOR-YACHT-002` | CLASSIC 40M BENETTI, ~39.5 m | €4,500,000 | `pending` | Conflicting available vs archived/unavailable sources; technical material/range/speed disputes. |
| `MAREVERE-SBJR-SAILING-YACHT-001` | ARISTARCHOS I / ARISTARCHOS, Nautor's Swan 40 m | €7,500,000 historical | `sold` | Fraser reported a sale dated July 15, 2025; historical asking amount is **not an active offer**. |

*Prices are dated research figures, not guaranteed current prices, live sale offers, verified deposits or proof of broker authority.

**Current active verified stock:** 0. Do not fabricate 3 “available to purchase” yachts. Other statuses `available`, `out_of_stock` and `pending` are configurable, but availability has a seller-authority and evidence gate; `sold` should be evidence-backed.

## Media inventory and naming

Each of the three parent IDs has:

- **10** photos `MAREVERE-SBJR-[PARENT-ID]-IMG-001` through `IMG-010` (30 total).
- **1** original video `...-VID-001` (3 total). ANYA ~161.2 s at 1920×1080; Benetti ~82.7 s at 1920×1080; sailing ~219.0 s at 1092×576 (below HD).
- **1** approximate GLB reconstruction (`...-3D-001`) with editable `.blend`, JSON notes, and render/preview (3 total). No manufacturer-confirmed CAD, survey or full interior fidelity.

**Do not rename parent or child IDs or cross-assign assets.** `inventory_private/source notes/ASSET_MANIFEST.csv` maps raw files, source and hashes. The `SITE_SOURCE/docs/phase620` QA report and public routes are engineering evidence.

## Public gallery state as of Phase 6.20

- `SITE_SOURCE/fleet.html` and `fleet.js` publicly list the three research records **within the local application**. Dossier/gallery photos show correct corresponding images; a video element streams each original MP4 via public media API (range support). Public 3D is *not* enabled.
- Public route `GET /api/public/inventory/media/<MEDIA-ID>` serves allowlisted Image/Video only for a **visible** yacht. Admin hide results in public media denial. Private workbook/3D paths must remain protected.
- Public research prices/specs have warnings and should not imply current offer; unconfirmed and sold vessels stay discoverable with appropriate state/enquiry rather than a “buy now” CTA.
- Research media rights are marked **pending**. User expressly instructed public exposure, which has been implemented in localhost routes, but not independently cleared for worldwide commercial web publication. Work must obtain/record permission or substitute cleared content before deploying publicly.

## Required specs for each new yacht

Stable listing ID, builder, model, year, vessel type, length/beam/draft, hull/superstructure materials, condition, location/region/country, actual authorized price and currency, VAT/tax status, seller/broker and authority evidence, engine model and hours, range/cruise/max speed (source-specific), guest capacity, cabins/crew, refits, fuel/water capacity and available broker documents. Record units, source URL, observed date, disputes, unknowns and public vs private classification. Never fill disputed numeric fields with guesses. Buyer should be able to see real verified details for each vessel.

## Workflow for every future intake

1. Broker/owner authorization → verify listing identity/title/condition/status and media license. Archive source and dated evidence.
2. Allocate next stable MAREVERE parent ID by type; match album, video, 360, 3D media IDs to parent (do not duplicate parent on category tags).
3. Normalize complete workbook and verify source to seller documents; note missing/conflicts, do not invent.
4. Upload optimized media and originals to appropriate protected/original vs public-derivative storage. Maintain source-to-derivative mapping, alt text, checksum, captions and rights metadata.
5. Admin reviews, records status, visibility, reasons and evidence. Publish only confirmed, rights-cleared and accurate public fields; keep research candidates accessible with explicit research/pending/sold framing as approved.
6. Test gallery and video on mobile and desktop; verify no cross-yacht mixing; test hidden media denied; check actual MP4 seek/range and 3D fallback.
7. Ingest in batches; build pagination/server-side filters, search indexing, cache, CDN and bulk import before scaling.

## Immediate inventory expansion

Research target 30–60 fully documented vessels across motor, sail, power/sail catamaran, explorer, cruiser and RIB/tender categories; then scale after performance verification. Marine goods target 150–300 verified SKUs and vetted providers later. These are **plans**, not current assets.
