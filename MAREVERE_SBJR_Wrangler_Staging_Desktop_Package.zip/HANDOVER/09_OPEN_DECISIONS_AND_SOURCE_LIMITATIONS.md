# 09 — Open Decisions and Integrity Caveats

**Evidence conflicts must remain conflicts until resolved; no silent correction via guessing.**

| Topic | Current evidence | Who must decide/verify |
|---|---|---|
| Domain and cloud hosting | No confirmed published yacht domain or configured production infrastructure in latest source | Owner and authorized account admin. |
| Logo / site name | MAREVERE · SBJR approved, must not be altered | Owner for any future change. |
| Company/selling legal entity | Not provided as verified legal/contractual details | Directors + counsel. |
| Three directors | Count stated; identities, duties, quorum and credentials not provided | Owner/directors. |
| Tier 1/2/3 legal terms | Proposal in acquisition calculator, 50% initial / possible 5% fee / valuation scenarios only | Directors + counsel by jurisdiction. |
| Buyer payments | Admin demo notes only; no external verification or settlement integrated | Directors + finance/bank reconciliation team. |
| Yacht ANYA | Research price €9.495m; speed/guest/refit conflicts; current seller mandate unverified | Broker/owner + inventory admin. |
| CLASSIC BENETTI | Research price €4.5m; sale status, range/material/speed conflicts | Broker/owner + inventory admin. |
| ARISTARCHOS I | Reported sold July 15, 2025; €7.5m historical only | Preserve sold/historical state; new selling evidence needed to change. |
| Media rights | Third-party original listing photos/videos, written redistribution license not documented | Copyright holders/brokers + directors. |
| Vessel 3D accuracy | Three approximate GLB reconstruction sources, not exact survey/CAD models | Manufacturer/spec validation before factual use. |
| Service providers and marine products | Demo items only, no verified inventory/quotes/compatibility | Procurement and verified suppliers. |
| Website E2E | Some successful offline mock render and API tests; real browser→backend blocked in previous sandbox | Work browser QA team. |
| Performance scaling | No tested concurrent traffic capacity / 10k listing support | Host operations and load tests. |
| Regulatory, customer data, region | International aspirations, exact jurisdictions not settled | Directors + legal/privacy review. |

## Communication discipline

Work should present each item as **Verified/Approved**, **Research/Disputed**, **Demo/Illustrative**, **Not Implemented**, or **Requires Director Decision**. Do not replace labels with ambiguous green “complete.” If directors change direction, retain prior version history, explicit approval and effective date.

## Prepublication warnings that must remain

- “Research reference / not a currently confirmed sale offer” on unverifiable price/availability.
- “Sold” for the sailing yacht until credible evidence to the contrary.
- Pending/out-of-stock vessels should show nonbinding **Enquire**, not Buy or Pay.
- No manufacturer-certified 3D or guaranteed gains.
- Actual visitor-facing public photos/videos must have lawful republication rights before indexed global launch.
