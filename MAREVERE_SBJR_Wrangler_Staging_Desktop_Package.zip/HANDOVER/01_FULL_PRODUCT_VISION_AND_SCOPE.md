# 01 — Full Product Vision / “End Goal”

## Market position and business intent

Build a differentiated, polished, ultra-premium, **mobile-first international yacht-and-marine marketplace and ownership ecosystem** branded **MAREVERE · SBJR**. It is a real commerce and acquisition platform under the employer's direction, not just a brochure, portfolio, or static template. Visitors should discover yachts/boats, research authentic specifications and media, explore buying routes, inquire, and engage with a coordinated concierge, seller, admin and eventually director-approval process. Owners/buyers gain post-login account and ownership workflows. Sellers/brokers can propose and manage listings subject to approval. Marine equipment, tools, furniture, parts, services and owner community are integral parts of the plan.

## Principal site experiences (preserve all)

1. **Public cinematic homepage:** elegant but actionable editorial hero, premium typography, approved wordmark/wake symbol, clear site navigation, featured verified vessels, honest ownership tiers, prominent pathways to collection/concierge/marketplace. Smooth high-resolution imagery, fast mobile rendering, reduced-motion fallback, interactive but legible sections. No generic card dump or amateur icon logo.
2. **Discover / yacht marketplace:** scalable public listing grid with search, category, length/year/price/location/manufacturer/cabins/status filters, sorting, favorites/compare where signed in, graceful empty/pending/sold/out-of-stock states. Every vessel has exactly one stable parent listing ID and one canonical detail page; multiple tags don't create duplicate listings.
3. **Individual vessel dossiers:** real corresponding media, technical specs, provenance/availability caveats, seller/broker association, configurable acquisition eligibility if approved, enquiry and saved vessel. Existing historic standalone dossier (e.g. Solenne) is conceptual; don't confuse fictional prototypes with the three research vessels.
4. **Cinematic showroom/Three.js:** yacht-specific HD video, photo/360 tour, accurate vessel-specific GLB where obtainable, orbit/spin, hotspots, decks/interiors when authenticated and accurate, static/mobile/reduced-motion fallback, WebGL compatibility tests. Never misrepresent an approximate Blender reconstruction as manufacturer CAD or actual photographed interior.
5. **Tiered acquisition studio:** Tier 1 outright, Tier 2 Premium I, Tier 2 Premium II, Tier 3 deferred. Explanations, illustrative calculator/scenarios and due diligence. Await director/legal decisions before any final offer or financial action.
6. **Buyer/member dashboard:** home, saved/compared yachts, enquiries, communications, acquisition process/document milestones, account/security, manual payment-status visibility where legitimately verified, prospective delivery/ownership stages, recommendations, eventually owner support/community.
7. **Seller/broker portal:** seller access, listing proposal, ownership and authorization evidence, media/technical upload, submission/revision status, enquiries, inventory management with audit and admin approval. Multiple independent sellers/brokers after launch; initial system supports demonstration roles.
8. **Admin operations:** catalogue ingestion, QA, approved listing statuses and publish/hide, source/media review, buyer enquiries, broker approvals, support cases, manual payment notes with reconciliation evidence, audit log, searches, reports. Initial admin is separate from **three directors**, whose legally consequential decisions need approval workflow designed with their confirmed requirements.
9. **Marine shop:** genuine marine accessories, electronics, engines/propulsion and spare parts, deck/docking items, tools, furnishings, maintenance/cleaning, safety, yacht tenders and optional watersports. Product SKU, inventory, images, suppliers and verified yacht compatibility; eventually secure checkout, shipping, taxes, returns. Current eight products are fictional demonstration examples, not stock.
10. **Specialist services:** yacht maintenance, repairs, surveys/inspections, delivery, marine equipment/furniture, other vetted providers; quote and enquiry workflows. Current provider/service screens are conceptual; no independent real-provider verification.
11. **Owner circles/community:** member resources, discussions, experiences, guides, events, staff moderation, abuse reporting and role/consent rules. Existing discussion examples are fictional / local-only. No actual public posting service yet.
12. **Support/concierge:** visitor assistance without sign-up, searchable FAQs, guided concierge, post-login support tickets, status updates and eventually actual two-way staff assistance. Current chat demonstration is scripted; do not call it live support.
13. **Account security:** registration, login, recovery, member vs broker vs admin permissions, audited admin changes, future director access only after role rules are confirmed. No shared credentials, secure passwords, rate-limiting, secure sessions, privacy protection, staff MFA for privileged access in production.
14. **Operations and lifecycle:** status, reservation/inquiry, due diligence, contract issuance and director review, externally reconciled payment evidence, ownership/title transfer, delivery, aftercare, disputes, and ongoing inventory/media maintenance. Implement sequentially after verified business/legal requirements.

## Editorial and UX quality objectives

- Product feels like a global luxury marine brand with cinematic art direction, not an off-the-shelf classifieds website.
- Responsive sizes: 320, 390, 768, 1024, 1440 pixels; Android-first; high-quality desktop as well. No horizontal overflow, confusing nav, dead ends, inconsistent logo, intrusive popups, unreadable copy, fabricated availability, unlabelled CTAs or misleading payment prompts.
- Brand colors: deep maritime navy/graphite, ivory and champagne/brass; nuanced contrast and rich but accessible typography. Existing approved site uses Cormorant Garamond + Manrope as reference. Don't force remote fonts if unavailable; include fallbacks.
- Premium detailed icons and typography; navigation such as Discover/Collection, Acquisition, Shop, Services, Community, Support, Member, seller and admin as appropriate; keyboard/reduced motion support.
- Performance: optimized responsive thumbnails, lazy loaded media, poster images, proper full-length video streaming, CDN planning, Three.js fallback, accessible gallery controls.

## Scale and initial content goals (planning, NOT benchmarked capacity)

- Current research: **3** vessels; one owner-requested local public catalogue, not three verified live listings.
- Curated introduction: **30–60** thoroughly verified vessels; first expansion can be 10–15 varied vessels; later 100–300, 500–1,000 and beyond after pagination/database/hosting benchmarking.
- First marine shop target **150–300 real products** (expand in batches of 20–30), plus verified services; these are goals not included stock.
- Categories: motor yachts, sailing yachts, power catamarans, sailing catamarans, explorer/expedition yachts, motorboats/cruisers, RIBs/tenders. Superyacht/megayacht classifications overlay types, not duplicate inventory. Provide manufacturer/model/year/length/location/condition/price filters.
- No supported claim yet about maximum simultaneous visitors, cloud throughput or validated 10,000+ vessel capacity.

## End state

A stable, secure, well-designed, authentic **publicly reachable** yacht marketplace with the approved MAREVERE/SBJR identity; properly licensed and identified vessel media; verified listings and enquiry management; staff and owner dashboards; director-approved sale/acquisition terms; transparent admin/manual evidence review while appropriate; shops/services/community/support as real services; measurable quality, monitoring and structured operations. Financial collection and legal ownership processes may only activate when approved and implemented safely.
