# 10 — Project Provenance / Phases and Sources

## Design and product foundation

- Early research and art direction: yacht luxury visual direction, Figma-compatible wireframes/storyboard. Reference archive under `DESIGN_AND_HISTORY_REFERENCES/`. These historical files are not the active source.
- Phase 6.1: mobile-first premium homepage and initial design source.
- Phase 6.2: V3 reconstructed design approved as a **visual foundation only**; not a final website or permission to remove business features.
- Branding: MAREVERE dominant / SBJR in header and footer. Approved logo became a strict preservation constraint; prior source included under brand history, current reference remains latest `SITE_SOURCE/index.html`.
- Phase 6.4: collection browsing/filtering/compare/favorites prototypes.
- Phase 6.5: yacht-specific concept dossier with technical detail.
- Phase 6.6: cinematic studio / concept Three.js viewer and media/fallback design.
- Phase 6.7: acquisition explanations/illustrative four-path calculator.
- Phase 6.8: buyer account/owner/member portal.
- Phase 6.9: seller and broker dashboard.
- Phase 6.10: admin operations dashboard.
- Phase 6.11: marine shop and specialist services with conceptual cart and proposals.
- Phase 6.12: member community and customer support with scripted/non-live concierge demonstrations.
- Phase 6.13: local Python/SQLite role-aware API, buyer/seller/admin pathways.
- Phase 6.14: incremental connection of saved yachts and marine bag, demo buyer registration.
- Phase 6.15: local account-security controls, password change, session revocation, local developer-assisted recovery.
- Phase 6.16: static/integration/security QA and documented production NO-GO.
- Phase 6.17: loopback HTTP QA and extra route security; browser-to-backend E2E blocked; cloud staging not deployed.
- Phase 6.18: imported three-vessel research workbook with protected photos/video/approximate models and manual payment-case demo notes.
- Phase 6.19: visitor-accessible three-vessel catalogue + four admin status choices and hide/show, audit, proof gates.
- **Phase 6.20: current latest working source.** Correct per-vessel 30 photographs and 3 full original videos served via local public media API; 3 approximate models still private; tests documented; no internet deployment.

## Do not confuse artifacts

- `SITE_SOURCE/`: **work on this** as most recent integrated code (including previous features).
- `PREVIEWS/`: supplementary static sample files with simulated data/excerpts; NOT real server integrations.
- `DESIGN_AND_HISTORY_REFERENCES/`: archival vision/brand/wireframe sources. Helpful to audit lost requirements, not to overwrite Phase 6.20.
- `SITE_SOURCE/inventory_private/`: normalized workbook and raw media with source provenance, private research fields. Never publicly serve full folder.
- `SITE_SOURCE/docs/`: test reports, route matrix, screenshots and evidence. Historic assertions must not be marketed as current production certification.

## Packaging note

The original Phase 6.20 site was packaged as `MAREVERE_Phase6_20_Public_Vessel_Media_Full_Source.zip`. This handover archives the **extracted exact contents** beneath `SITE_SOURCE/`, plus scope/design/operational instructions. SHA-256 checksums are included for audit. Do not use superseded original Phase 6.19 or older source zips as an implementation starting point.
