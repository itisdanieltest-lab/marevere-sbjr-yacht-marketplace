# 12 — Definition of Done / Release Deliverables

## Hand-over receipt (immediately)

- [ ] ZIP extracts with no corrupt entries; 6.20 site code completely present. `CHECKSUMS_AND_CONTENTS.json` checksums verified.
- [ ] All original logo SVG, SBJR header/footer signature, typography and mobile visual treatment retained unchanged.
- [ ] Research workbook readable with all sheets/evidence and correct three stable yacht IDs.
- [ ] Correct parent tags for 30 images, 3 original MP4 videos (with resolution/duration noted) and 3 approximate private 3D models.
- [ ] No runtime credentials or DB files accidentally packed; back-end remains local-only until reengineered.

## Integrated functional acceptance

- [ ] Live (within authorized staging environment) homepage, fleet, dossier, media, navigation and inquiry work with current data and correct status/price caveats.
- [ ] Mobile/tablet/desktop screenshots and responsive/keyboard/reduced-motion tests at 320/390/768/1024/1440, plus actual phone where possible.
- [ ] Buyer login/registration, saves, enquiries and own data tested; seller create/update verified; administrator moderation/status/audit and protected media/reporting tested.
- [ ] Admin can select Available/Pending/Sold/Out of Stock, show/hide, add evidence and reason; all changes persist and are auditable; hidden media not accessible.
- [ ] Admin can record case notes/manual payment status with proper authorization and evidence; no claim of actual bank confirmation solely via UI.
- [ ] Three directors' roles/signoff policy presented for approval and implemented only after confirmed; contract/fee business rules versioned and not publicly offered as final prematurely.
- [ ] Full original yacht photos and videos matched by parent ID and playable; 3D privately labeled “approximate” until approved.
- [ ] Search, filters, caching, pagination design prepared for 30–60 yachts and future larger load, with real measured throughput before claims.
- [ ] Shop/services/community/support either integrated as real functions or explicitly labeled demonstration with a clear completion backlog.

## Production release gates (all must be met for user-facing commercial launch)

- [ ] Correct approved domain/hosting authorization, real HTTPS/production identity/staff permissions and monitoring/backups.
- [ ] Confirmed seller mandates/current availability/accurate current prices or honest research labels; documented rights to every published asset.
- [ ] Director and legal review of all Tier 2/3 payment/valuation claims and contracts; applicable compliance, privacy, tax and consumer disclosures.
- [ ] Independent production-oriented security and accessibility assessment and actual full E2E tests.
- [ ] Payment providers/reconciliation/escrow/receipts/refunds/ownership transfer only if explicitly approved and implemented correctly (otherwise disabled).
- [ ] Go/no-go decision and rollback plan signed by appropriate authorized person(s).

## Required files at each release

`README`, source ZIP, diff/change log, test logs with failed/skipped cases, responsive screenshots, API security findings, inventory and license state, director decision register, release checklist, staging link and credential handover through authorized secure channel (no passwords in ZIP), current known issues and next milestones.

**Final project goal:** A cohesive, beautiful, functional, secure public MAREVERE · SBJR international yacht ownership and marine commerce platform with reliable real content, correct role segregation, approved acquisition contracts and measured operational readiness, not merely completion of a demo phase.
