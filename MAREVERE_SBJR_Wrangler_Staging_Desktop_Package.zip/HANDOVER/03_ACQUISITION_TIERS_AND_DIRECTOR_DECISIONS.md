# 03 — Acquisition Paths / Director Commercial Review

**These are plans, NOT finalized contracts, current purchase offers, investment products, or guaranteed returns.** The current `SITE_SOURCE/acquisition.html` / `acquisition.js` calculator deliberately describes illustrative scenarios.

## Exactly three tiers and four configurations

| Path | User-established concept | Unresolved issues to be approved |
|---|---|---|
| **Tier 1 — Outright** | Buyer acquires full vessel via documented whole-price settlement and ownership/title-transfer process. | Title evidence, taxes/VAT, surveys, escrow or funds verification, contracting entity, transfer jurisdiction, delivery, refund/remedies. |
| **Tier 2 — Premium I** | Proposed partial/staged acquisition with **50% initial payment**. Earlier planning discussed possible value/rights management or alternative ownership structures. | Does initial contribution grant only a reservation, a security/beneficial interest, ownership, purchase option, or something else? What happens on default/refund? Balance timing/transfer? Any valuation changes? |
| **Tier 2 — Premium II** | Proposed **50% initial payment** and separate **5% completion fee** subject to contract. | 5% base (full price or remaining balance), fee timing/beneficiary, disclosure, possession, balance and transfer terms, tax, termination. |
| **Tier 3 — Deferred** | Proposed **50% initial contribution**, later completion and **contract-defined valuation adjustment**. Illustrations explicitly allow both upside and downside changes. | Valuation methodology and independent source; whether adjustment affects due amount or entitlement; maturity dates; caps/floors; legal characterization in every market; consumer protections. No guaranteed appreciation/yield. |

Do **not** collapse Premium I and II into one tab, replace tiers with generic financing ads, alter 50% or 5% as final facts, or present hypothetical calculations as approved quotes.

## Three directors' review role

The user specified **three directors** who will review and conclude acquisition terms. They are not interchangeable with the currently functioning local **one administrator** role. Exact names, shareholding, signatory powers, independent review thresholds and whether all three must sign have **not** been stated. Work should present a suggested reviewer registry for user confirmation, not create fake approved directors or auto-approve contracts.

**Suggested approval gates (pending governance confirmation):**

1. Director reviews the full content/intent of each Tier and each Premium configuration, price/deposit/fee/currency rules, correct legal entity and scope of jurisdictions.
2. Commercial/legal reviewer uploads or references the signed agreement and confirms seller authority, buyer due-diligence, possession, delivery and cancellation terms.
3. Authorized director(s) explicitly approve each live tier offering and specific yacht's eligibility before the associated purchase CTA, deposit or contract generation is enabled.
4. Admin may operate catalogue states, support inquiries and audit/document tracking but cannot override binding director decisions.
5. Record signed decision, version, timestamp, signatory and effective date; re-approval on substantial changes.

**Never claim director approval or legal completion without actual documentation.**

## Proposed workflow until approvals

- Public: descriptive acquisition paths clearly marked “subject to director-approved terms and individual vessel contract”; inquiry/consultation only.
- Signed-in buyer: save and send a nonbinding enquiry, receive status; no checkout, deposit button, automated loan/valuation guarantee or ownership claim.
- Admin: prepare supporting documents and link enquiries; record verified *external* payment notes only when legally appropriate and independently reconciled.
- Directors: review contract drafts offline or in a properly secured approval flow once built.

## Prohibited assumptions

No regulated financial product launch, holding of client funds, confirmed yield, automatic 50% payment instruction, lender/escrow arrangements or ownership transfer based solely on calculator output. Obtain legal review of any value-linked arrangement prior to public claims.
