# MAREVERE · SBJR — Phase 6.16 Platform Quality Audit

**Date:** 17 November 2026  
**Scope:** Phase 6.15 local fictional site + Python/SQLite backend, with all primary public, buyer, seller, admin, shop and support frontend pages.  
**Production disposition: NO-GO.** Local demonstrations may continue on loopback with fictional data only.

## Tests performed *during Phase 6.16*

| Test | Result | What it actually verifies |
|---|---:|---|
| Static site, accessibility semantics and local references | **671/671 passed** | 17 primary HTML pages: semantic landmarks, one H1, page titles, image alt presence, skip links, form input labels, local reference resolution, MAREVERE/SBJR identity, JS syntax, mock asset existence. **Not** screen-reader WCAG certification. |
| Connected buyer/seller/admin regression | **35/35 passed** | Real HTTP tests against loopback Python/SQLite with fictional buyer registration, saved vessel, marine bag, broker submit, admin decision, access denial. |
| Authentication and security regression | **43/43 passed** | Real local HTTP tests: cookies, CSRF, same-origin and host protections, password change, session revocation, local-only recovery. |
| HTTP public routes | **20/20 passed** | Local server delivers primary HTML, respects internal static paths and security/recovery links, and selected JS syntax. |
| Full browser-to-backend E2E | **BLOCKED / NOT PASSED** | Chromium navigation for both `file://` and `http://127.0.0.1` returns `net::ERR_BLOCKED_BY_ADMINISTRATOR`. No claim of keyboard, visual, touch, overlay or Three.js browser runtime verification. |

The counts describe individual assertions, not independent systems or release-quality certifications. They must not be presented as 'the site is 100% tested.' All tests used local fictional data; no real financial activity occurred.

## Findings by priority

### P0 — blockers before real users or transactions

1. **Financial and legal model not approved.** Tier 2 Premium I/II must specify legal entitlement, payment, title transfer, due dates, value rights and 5% fee basis. Tier 3 must define valuation source, direction of gains/losses, caps, maturity, and lawful characterization. No contractual value/return promise and no deposit collection until reviewed.
2. **Production identity and privileged access absent.** Local demo accounts, `@marevere.invalid` restriction, localhost-only cookies, developer-issued recovery, in-memory rate limit and no hosted TLS identity environment. Require production-grade identity flow, verified contact channels, strong admin controls, monitoring, backups and incident response before launch.
3. **Browser E2E and accessibility not verified.** Need approved staging browser running against a test server, covering 320/390/768/1024/1440, keyboard/focus/menus/dialogs, reduced motion, mobile touch, contrast/semantic checks and real WebGL rendering.
4. **Real data and due diligence missing.** No verified listings, seller identity checks, manufacturer-accurate yacht-specific 3D/video, image rights or trustworthy pricing; no signed contract or delivery ownership evidence.
5. **No production payments or order lifecycle.** Payment/escrow/settlement, receipts and reversals, shipping and taxes, inventory and any investment/credit compliance remain unimplemented and intentionally disabled.

### P1 — core experience gaps

6. **Mixed demonstration vs integrated paths.** Some prior standalone interfaces still use browser-only state, scripted support and concept content. End-to-end buyer/seller/admin route journeys need confirmed browser verification against the same API.
7. **Marine shop isn't a retail checkout.** Eight fictional products and a cart endpoint exist; actual availability, compatible inventory, tax, fulfillment, refunds and verified technical fitment do not.
8. **Community and concierge aren't live services.** Current content and support drafts are local/scripted; no live staff routing, moderation, case-level messaging and SLA.
9. **3D quality cannot be accepted from code alone.** Model/video assets exist but their factual fidelity, licensing, LCP, frame rate, accessibility alternatives and real-device rendering have not been verified.

### P2 — polish and operational readiness

10. Validate brand name and SBJR signature on every responsive header and footer at actual rendered sizes; verify legibility and typography fallback when web fonts are blocked. Visual/static identity checks pass, but design QA is not equivalent to device review.
11. Prepare privacy, retention, seller verification, consumer disclosures, support policies, dispute handling, regional taxes and localization before market entry.

## What was verified about branding

All **17 primary site pages** contain MAREVERE in their document titles, show SBJR in the header and in the bottom identity block (homepage uses the `.end-footer` visual footer), and have one primary heading. The legacy redirect-only pages `seller-access.html` and `admin-access.html` are outside the primary-page checks and are redirected on the local server.

## Next recommended sequence

**6.17 Staging-ready browser QA harness** → Deploy only an isolated, access-controlled staging environment using fictional data, then complete actual browser-to-backend end-to-end testing and visual screenshots. Do **not** activate acquisition funds or real accounts.  
**6.18 Production architecture** → Auth/email/security/observability/privacy design, seller verification and audit controls.  
**6.19 Commercial validation** → Jurisdiction and approved Tier 2/Tier 3 contracts, payment flow and entity verification.  
**6.20 Asset and catalog productionization** → Verified inventory, media licenses, yacht-specific GLB/cinematics, product fitment, performance testing.  
**Release gate** → Independent security/privacy/accessibility review and approved legal/business rules before any public launch.

## Reproduce locally

From the extracted source directory run: `python backend/app.py` (loopback only, fictional demo). In a second terminal run:

```bash
MAREVERE_TEST_URL=http://127.0.0.1:8765 python tests/phase614_smoke.py
MAREVERE_TEST_URL=http://127.0.0.1:8765 python tests/phase615_security.py
MAREVERE_TEST_URL=http://127.0.0.1:8765 python tests/phase615_routes.py
python tests/phase616_audit.py
```

Use `docs/PHASE6_16_ACCEPTANCE_MATRIX.csv` for handoff. The Phase 6.16 ZIP excludes `.runtime`, demo credentials, databases and other private runtime files.
