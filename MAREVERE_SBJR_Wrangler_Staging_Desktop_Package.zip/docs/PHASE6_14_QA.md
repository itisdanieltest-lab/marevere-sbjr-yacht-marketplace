# Phase 6.14 — Local Integration QA

- Original role-based API regression checks: **36 / 36 passed** during the first run on a fresh local demo database (role restrictions, CSRF/origin, sessions, listing decisions, audit, support, saved vessels).
- New Phase 6.14 HTTP checks: **35 / 35 passed** (cart, product validation, server-side price, buyer-only access, fictional self-registration, role barriers, disabled payment endpoints, demo listing review and read-only approved concepts).
- Five responsive widths × three role views: **15 / 15 visual-only mock rendering checks**; no horizontal overflow or JavaScript page errors in that rendered preview.
- Static link scan found no missing local HTML asset references across 17 HTML pages. JavaScript syntax checks completed.
- **The browser sandbox blocked navigation to the local backend** with `ERR_BLOCKED_BY_ADMINISTRATOR`. Therefore these screenshots are from an embedded, mocked-data browser preview, NOT evidence of complete browser-to-backend E2E.
- User acceptance, independent privacy/security review, real WebGL tests, real device visual checks, and E2E with an accessible development browser are still required.
- No real funds, binding contracts, actual ownership, investments, customer data, delivery, shipping, seller verification, or support messages are handled.
