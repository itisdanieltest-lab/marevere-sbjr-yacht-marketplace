# MAREVERE · SBJR approved logo preservation

The previously approved homepage SVG mark and MAREVERE/SBJR identity are the sole reference for newly added admin inventory and 3D research views. Their graphic paths and gradient values were copied without modification from `index.html`. The generic capital-M placeholder used in some existing portal entry pages was replaced by the exact same SVG without changing the approved homepage. Header/footer wordmarks remain MAREVERE dominant with SBJR secondary.

No new logo was generated. All future pages must reuse this approved asset; modifications require explicit authorization.
