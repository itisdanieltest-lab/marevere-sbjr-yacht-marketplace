# Phase 6.13 QA — November 17, 2026

- Local API integration smoke: **36 / 36 passed** on the local Python server at port 18765.
- Negative authorization: denied buyer access to admin reviews, seller access to buyer saves, seller approval attempts and unauthorized API routes.
- CSRF/origin: missing CSRF rejected and mismatched origin rejected.
- Input: unknown vessel rejected; immutable review state prevents repeated approvals.
- Persistence: buyer saved selection persisted in SQLite and appeared on subsequent read; buyer support case reached admin queue; seller draft reached admin review; admin approval was audited; session logout invalidated session.
- Source exposure: `.runtime/demo_credentials.txt` (including URL-encoded name) and backend source inaccessible over HTTP.
- Static public homepage and new connected portal reachable through HTTP.
- Browser visual QA with mocked APIs (not live backend): **320, 390, 768, 1024 and 1440 px**, no horizontal overflow and no JS page errors after the last fix. Buyer, seller, admin layouts rendered. Visual screenshots under `docs/connected_*`.

**Limitations:** The available browser sandbox blocked navigation to the localhost server (`ERR_BLOCKED_BY_ADMINISTRATOR`), so real connected-browser end-to-end testing could not be completed. HTTP integration smoke did exercise the real backend separately. The browser screenshots are of the **visual-only mock API preview**, not proof that the live backend was rendered through the browser. Full browser+API E2E, security/performance/accessibility audits, actual device testing and deployment remain pending.
