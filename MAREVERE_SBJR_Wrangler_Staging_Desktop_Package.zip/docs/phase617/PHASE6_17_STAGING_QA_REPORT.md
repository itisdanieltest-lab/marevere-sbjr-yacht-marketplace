# MAREVERE · SBJR — Phase 6.17 Staging/Browser QA Handoff

**Date:** 17 November 2026  
**Release:** **NO-GO** — prototype engineering review only; never collect real yacht deposits.  
**Actual hosted staging site:** **NOT DEPLOYED.** This environment has no shared cloud browser and cannot perform a real external staging deployment.  

## Work completed

- Reused and preserved the Phase 6.16 yacht marketplace, buyer/seller/admin portals, Three.js viewer, acquisition concept, marine shop, community and customer support source.
- Added a reproducible one-command local QA harness (`qa/phase617_run.py`) and an expanded Chromium Playwright E2E suite (`qa/phase617_browser.py`). The E2E suite covers five viewport widths plus buyer save/cart, seller/admin role checks when run in a permitted browser environment.
- Added real local HTTP preflight coverage of route permissions, media delivery, asset integrity, and sensitive source restrictions.
- **Fixed a concrete local-server vulnerability:** the inherited `SimpleHTTPRequestHandler.do_HEAD()` bypassed the app's GET access controls and could reveal metadata about restricted files. HEAD is now explicitly rejected with HTTP 405. The negative test checks both GET and HEAD access to protected paths.
- Retested the local API and security regression suites against an isolated server using exclusively fictional identities.

## Observed results

| Check | Passed / attempted | Status |
|---|---:|---|
| Source/static semantics | 671 / 671 | Pass |
| New HTTP/asset preflight | 38 / 38 | Pass |
| Buyer/seller/admin API | 35 / 35 | Pass |
| Security regression | 43 / 43 | Pass |
| Public routes/JS delivery | 20 / 20 | Pass |
| Chromium real E2E | 0 / 0 | **Blocked: no browser tests executed** |

The total of the passing assertions is **807**, but many are overlapping checks, **not** independent features or any form of 100% readiness claim.

**Browser evidence:** `net::ERR_BLOCKED_BY_ADMINISTRATOR` prevented navigating Chromium to loopback and local files. `docs/phase617/browser_results.json` confirms **0** browser checks performed; there are no new genuine browser screenshots for this phase. The rest of the results come from HTTP, static, and Python tests.

## Running in an authorized local or cloud development browser

Requirements: Python 3.10+, `requests`, `beautifulsoup4`, Node.js for syntax checks, `ffprobe`, Playwright Python and Chromium (optional if browser cannot be provisioned). *Do not use a production/customer environment.*

Run from the extracted project root:

```bash
python qa/phase617_run.py
```

This starts a **loopback-only** fictional-data server on 127.0.0.1:18767, initializes fresh demonstration credentials in the excluded `.runtime/` folder, runs the static, API, route and browser checks, and shuts down the local server. Results are written to `docs/phase617/run_summary.json` and `docs/phase617/browser_results.json`.

To view the website on the same machine while QA is ongoing:

```bash
python backend/app.py
```

Then navigate to `http://127.0.0.1:8765/` in that machine's browser. Keep the local server loopback-only; don't open an unauthenticated public port. Buyer, seller and administrator fictional demo credentials are generated *locally* in `.runtime/demo_credentials.txt`; never upload that file.

## Protected staging access plan (not yet executed)

1. Prepare a private staging tenant with HTTPS, identity/access restrictions, no public indexing, isolated fake database, least-privilege access, CSRF/session controls and log redaction. Current Python dev server refuses non-loopback binding by design; **do not simply expose it on the public internet**.
2. In ChatGPT Work's browser or another authorized laptop browser, run `qa/phase617_browser.py` against a local loopback server in that browser's own environment to obtain actual live UI E2E evidence; do not interpret a standalone sandbox HTML preview as an end-to-end test.
3. Test the 320/390/768/1024/1440 views and buyer/seller/admin journeys with screenshots, keyboard/focus, reduced motion, media fallback and 3D/WebGL rendering. Run actual mobile-device performance and accessibility audits.
4. Require documented employer approval before any publication beyond protected staging. Real accounts, payments, contracts, investment claims, yacht ownership transfers and verified inventory remain disabled/unimplemented until approved.

## Release gate and risks

**NO-GO:** Legal/commercial tier rules undefined, no safe hosted production identity stack or email verification, browser E2E blocked, no approved payment system, no verified yacht inventory/media/3D authenticity, live support is not connected. `docs/phase617/acceptance_matrix.csv` provides actionable priorities.

**Visual foundation:** MAREVERE remains the dominant wordmark; SBJR remains visible but subtle in header and lower/footer identity. The established mobile-first cinematic design and the platform's complete yacht ownership + marine business model remain the basis for future work.
