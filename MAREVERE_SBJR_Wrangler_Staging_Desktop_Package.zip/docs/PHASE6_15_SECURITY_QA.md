# MAREVERE · SBJR — Phase 6.15: Account Security & Integration QA

**Environment:** Local loopback-only engineering demonstration; fictional identities and yacht data. **Production status: NO-GO.**

## What this phase actually changed

1. Added account-security UI (`security.html`) for any signed-in demo buyer, broker or admin, and a link from connected dashboards.
2. Added server-validated current-password change. On success the server revokes **all sessions** for that user; user must sign in again.
3. Added "sign out everywhere" control, with server-side session revocation.
4. Added a **local-terminal-only** developer reset-token generator, backed by SHA-256 hashes in SQLite, with a 10-minute expiry and single-use verification. No email delivery exists. Reset invalidates all old sessions. No reset codes are exposed via public HTTP.
5. Added dedicated recovery UI (`recovery.html`) with an explicit local-only warning; linked it from sign-in. Never enter real passwords or email addresses in this prototype.
6. Added Host header validation for local HTTP requests to reduce DNS-rebinding exposure in this intentionally localhost-only server.
7. Preserved the website layout and SBJR identity; did not alter yacht acquisition formulas, inventory, 3D model or commercial features.

## Testing performed

| Test suite | Result | Scope |
| --- | --- | --- |
| Phase 6.14 regression (`tests/phase614_smoke.py`) | **35/35 passed** | buyer registration, local session/auth, cart, saves, seller reviews, admin roles, lack of payment routes |
| Phase 6.15 security HTTP/API (`tests/phase615_security.py`) | **43/43 passed** | CSRF, origin, host, roles, password change, global session revocation, one-use recovery, expiry, protected source paths |
| Phase 6.15 site routes (`tests/phase615_routes.py`) | **20/20 passed** | 16 HTML routes, SBJR consistency, security/recovery links, JavaScript syntax |
| Chromium live browser-to-backend test | **BLOCKED** | Browser navigation to `http://127.0.0.1:18768/account.html` returned `net::ERR_BLOCKED_BY_ADMINISTRATOR`; no live browser E2E completion claim |

**Interpretation:** HTTP API regression passed in a local fictional dataset. Actual client-side user journeys, mobile layout, Three.js runtime, recovery UI interaction and cross-browser behavior still need human or browser E2E verification in an approved browser environment.

## Run locally

1. Extract source into a directory and open a terminal there.
2. Run `python backend/app.py` (binds only to `127.0.0.1:8765` unless changed by `MAREVERE_PORT`).
3. The server creates `.runtime/marevere_demo.sqlite3` and `.runtime/demo_credentials.txt` with fictional credentials. They are **not** bundled in the ZIP.
4. Open `http://127.0.0.1:8765/sign-in.html`, then open the **Account security** link inside any role-specific dashboard.
5. To test recovery: stop copying/using any real credentials. From that same local directory, run `python backend/app.py issue-demo-reset buyer@marevere.invalid` and paste the one-time code into `http://127.0.0.1:8765/recovery.html`. The code expires after ten minutes. Do **not** share it publicly.
6. Test with `MAREVERE_TEST_URL=http://127.0.0.1:8765 python tests/phase615_security.py` (requires `requests`), and `python tests/phase615_routes.py` (also requires Node to syntax-check the new JS).

## Remaining production blockers

- No hosted staging environment with approved domain, TLS, secure cookies, account identity provider, MFA for privileged roles, verified email recovery, rate limits shared across workers, monitoring, or incident response.
- No real buyer/seller KYC or verification, privacy controls, lawful basis for data processing, retention/disclosure policy, threat modeling or independent penetration test.
- Legacy frontend pages need systematic source-to-sink XSS review and automated accessibility checks; on-device testing for touch targets, focus and screen readers remains outstanding.
- Commercial terms (Tier 2 Premium I/II; Tier 3 valuation adjustments), jurisdiction, custodial flows, contracts and financing compliance remain **unapproved**; no payment, financial return or ownership promise should be activated.
- Accurate vessel-specific imagery, media licensing, manufacturer-verified 3D models, real vessel/product inventory, delivery, fulfillment and live community/chat systems remain unimplemented.

**Disposition:** Good progress for a local security prototype; **not ready for public use, deposit collection, genuine customer registration, or production deployment.**
