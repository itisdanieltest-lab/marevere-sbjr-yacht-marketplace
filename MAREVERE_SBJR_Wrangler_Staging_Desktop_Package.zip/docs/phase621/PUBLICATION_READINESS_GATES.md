# MAREVERE · SBJR — Secure Publication Gates

**Current release decision: NO-GO for public internet publication and all transactions.** This is a local Python/SQLite demonstration. The current `127.0.0.1` server must not be exposed or port-forwarded.

## Gate A — content and rights

- Obtain dated seller/broker authority and current availability/price/tax evidence for every live yacht listing.
- Obtain written republication rights for each photo and video, including commercial use, territory, term, derivative/resizing rights, and required credit. Record proof privately; pending rights means do not publish that asset externally.
- Keep ANYA and CLASSIC as Pending until verified; keep ARISTARCHOS I Sold/historical unless new credible evidence changes the state.
- Label research prices as nonbinding historical/reference figures. Keep approximate 3D models private or visibly approximate if later approved for public display.
- Verify any future products/services with supplier authority, stock, SKUs, compatibility, price, returns, and fulfillment. Current catalogue-normalized counts are zero.

## Gate B — commercial and governance decisions

- Obtain signed director outcomes under a confirmed quorum/authority policy for all four acquisition configurations and any yacht-specific eligibility.
- Obtain jurisdiction-specific legal and tax/consumer review, entity details, exact cancellation/default/dispute, title/possession/delivery, fee and valuation provisions.
- Keep payment collection, escrow, deposits, contracts, title transfer, and ownership claims disabled until reviewed implementation and approvals are independently verified.
- Maintain manual case notes as internal records only; implement a secure independent finance reconciliation process before any real payment status.

## Gate C — production architecture and privacy

- Select the authorized domain, hosting/provider, data region, database, object storage/CDN, and operational owner; record exact target and rollback plan.
- Replace the local demo server and generated `.invalid` accounts with production-grade managed identity, verified email/recovery, privileged staff MFA, least privilege, secure secret management, logging/alerting, backups/restore, rate/request limits, and patching.
- Publish a reviewed privacy notice, consent/retention/deletion process, support contact and incident/data-breach process before collecting real visitor/member data.
- Keep workbook, source evidence, raw originals, GLB/Blender files, credentials, runtime database, and internal manifests out of public assets. Review every route and storage ACL independently.
- Use a separately configured protected HTTPS staging environment with fictional data, no search indexing, and no live payment integrations.

## Gate D — independent testing

- Run real browser-to-backend journeys on reachable staging: public browse → dossier/media → nonbinding inquiry; member signup/save/inquiry; seller submission → admin review; status/visibility update → public refresh; admin audit and manual case notes.
- Cover 320, 390, 768, 1024 and 1440 widths, Android/desktop, keyboard/screen reader, reduced motion, media seeking/range, private-route denial, hidden media denial, session/recovery controls, and abuse limits.
- Obtain independent application-security and accessibility reviews. Load/performance claims require measured results on the chosen host.
- Capture logs and actual screenshots, include failures/skips, and confirm logo/hash and source media mapping.

## Gate E — authorization and release

- Obtain the owner's explicit authorization for the exact domain, host, public audience, content/version, and release date after all prior gates pass.
- Record authorized GO/NO-GO signatory, release version, monitoring owner, rollback trigger, incident contact, and post-release review date.
- Make public informational browsing a separate release from any commercial/financial capability. A website build, staging URL, or successful API test is not public deployment approval.

## Current decision register

| Gate | Current state | Evidence / blocker |
|---|---|---|
| Source integrity and local API regressions | Verified in part | See `INTAKE_AND_QA_AUDIT_2026-11-18.md`; browser E2E not run successfully. |
| Seller authority and current stock | Not verified | Zero confirmed active MAREVERE-controlled listings. |
| Media publication rights | Pending | Third-party research media; written licenses not documented. |
| Director identities/governance and terms | Requires decision | Three people, authority, quorum and legal terms not provided. |
| Production host/domain/identity | Not configured | No approved target or production infrastructure in source. |
| Privacy, monitoring, backups, independent security/accessibility | Not complete | No production assessment/evidence. |
| Payment/contract/ownership functions | Disabled / not implemented | Do not activate through this prototype. |
| Public release authorization | Not provided | Obtain exact-target authorization only after gates are satisfied. |
