# MAREVERE · SBJR — Director Decision and Approval Packet (Draft)

**Version:** 0.1 — prepared 18 November 2026  
**Status:** Discussion draft only. No director names, delegated authority, vote, quorum, contract term, or approval has been supplied or recorded. This document does not authorize an offer, payment, contract, or publication.

## Decisions requiring a recorded outcome

Create a separate versioned decision for each applicable subject:

1. Tier 1 — Outright acquisition.
2. Tier 2 — Premium I.
3. Tier 2 — Premium II.
4. Tier 3 — Deferred acquisition.
5. Eligibility and approved terms for each individual yacht.
6. Seller/broker mandate and public offer facts for each individual yacht.
7. Media and brand publication rights and intended territories/term.
8. Informational public release, approved domain, and release date.

The 50% contributions, possible 5% completion fee, fee base, and valuation-linked examples are proposals only. Each path requires its own exact approved agreement and disclosures. No calculator result is a quote, promise, or entitlement.

## Proposed review sequence — governance must confirm before enforcement

| Stage | Record | Gate |
|---|---|---|
| 1. Prepare | Owner/administrator creates a decision ID, subject, yacht IDs (if relevant), document versions, source evidence, proposed wording, jurisdictions, and requested effective date. | Incomplete evidence returns to preparation. |
| 2. Independent review | Three director seats are registered only after the owner supplies each person's verified identity, role, contact route, authority, and conflict-of-interest process. Each reviewer receives the same immutable packet version. | No reviewer identity or authority may be inferred from the current demo administrator. |
| 3. Record each decision | Each director records `Approve`, `Reject`, `Abstain`, or `Request changes`, with a signed decision/evidence reference, timestamp, and comments. | A blank or missing vote is not approval. |
| 4. Resolve governance | Owner confirms quorum, whether unanimity is required, delegated authority, tie handling, conflicts, and who can make final release decisions. | Until this policy is confirmed, no vote aggregation is treated as binding approval. |
| 5. Legal and operational checks | Counsel/qualified reviewers confirm entity, jurisdiction, consumer/privacy/tax/regulatory terms; finance confirms payment and reconciliation policy; inventory staff confirm seller authority and asset rights. | Director votes do not replace legal review, seller evidence, or payment controls. |
| 6. Activate a version | Only after the confirmed decision rule is met, an authorized release operator links the exact approved document/version and effective scope. Any material change creates a new decision. | No activation until sign-off evidence is attached and independently checked. |
| 7. Audit and revoke | Preserve the original proposal, all votes, signed evidence, timestamps, actor, scope, effective date, and superseding/revocation record. | Never overwrite an approval history. |

## Blank reviewer registry — owner to complete

| Seat | Legal name | Role/title | Authority evidence | Conflict declaration | Secure contact | Status |
|---|---|---|---|---|---|---|
| Director A | Not provided | Not provided | Not provided | Not provided | Not provided | Unregistered |
| Director B | Not provided | Not provided | Not provided | Not provided | Not provided | Unregistered |
| Director C | Not provided | Not provided | Not provided | Not provided | Not provided | Unregistered |

## Decision record template

- Decision ID / version:
- Decision subject and affected stable vessel ID(s):
- Proposed terms version / exact document hash:
- Legal entity / jurisdiction(s):
- Price, currency, tax/VAT, fee base, payment milestones, refund/default/cancellation terms (where applicable):
- Title, possession, survey, valuation, delivery, and dispute terms:
- Seller/broker authority evidence reference and checked date:
- Photo/video/model rights evidence and territory/term:
- Required director quorum/unanimity rule (owner-confirmed):
- Director A decision / signed evidence ref / timestamp:
- Director B decision / signed evidence ref / timestamp:
- Director C decision / signed evidence ref / timestamp:
- Legal review reference / scope / date:
- Finance/reconciliation review reference / scope / date:
- Final outcome under confirmed governance rule:
- Effective date, expiry/review date, restrictions, and revocation process:
- Independent checker / audit timestamp:

## Safe operating state until decisions are confirmed

- Visitors may see only appropriately labeled research information; no live purchase or deposit CTA.
- Admin status controls remain operational catalogue fields and do not themselves prove seller authority or director approval.
- Manual payment labels remain internal demo notes, not evidence that money was received.
- Do not create director users, assign the demo admin director powers, issue contracts, activate terms, or publish rights-pending third-party media.

## Owner decisions needed to turn this draft into a real process

Provide the three directors' verified names and roles; legal entity and jurisdictions; delegated authority; quorum/unanimity and conflict rules; accepted signature/evidence method; and the review scope for commercial terms, vessel eligibility, asset rights, and public release. Counsel/finance reviewers and the exact approved agreement versions must also be identified before enforcement.
