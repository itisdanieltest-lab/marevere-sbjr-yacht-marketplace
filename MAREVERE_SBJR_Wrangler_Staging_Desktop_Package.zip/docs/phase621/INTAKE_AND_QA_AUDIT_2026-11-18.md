# MAREVERE · SBJR — Phase 6.20 Intake and QA Audit

**Audit date:** 18 November 2026  
**Disposition:** Local prototype verified in part; **production NO-GO**.  
**Scope:** Handover package integrity, source provenance, inventory/media linkage, selected local API regressions, and browser access feasibility.

## Baseline and preservation

- The handover ZIP contains 256 entries (275,728,568 uncompressed bytes); `ZipFile.testzip()` returned no corrupt entry.
- The extracted canonical `SITE_SOURCE/` contains 230 files. Every one of the 230 site-source files matches the path, size, and SHA-256 recorded in `CHECKSUMS_AND_CONTENTS.json` at intake.
- Source is the documented Phase 6.20 local Python/SQLite prototype. No Git repository is included in the extracted source. No application, logo, design, inventory, or media source file was changed during this audit; test output JSON/logs were refreshed by the existing test scripts.
- Approved homepage baseline SHA-256: `index.html` = `38c74e9f186f6ce7034db98dcedcac530ad462e5d5d74e47c8e458492c256e1b`. The inline header SVG/wordmark and footer identity remain the locked source. No logo edit was made.
- `CHECKSUMS_AND_CONTENTS.json` reports release state as local demonstration, not deployed and not production-ready.

## Inventory and media

- Workbook: 16 worksheets; three research records: ANYA, CLASSIC 40M BENETTI, ARISTARCHOS I.
- Initial public states: Pending, Pending, Sold. No record is verified as active MAREVERE-controlled stock.
- Private asset manifest: 39/39 records resolve to files and match recorded SHA-256/size: 30 photos, 3 original MP4 videos, 3 approximate GLB models, and 3 model preview images. Each is assigned to a parent vessel ID. The editable Blender sources are also present.
- Full video measurements in the handover: ANYA 161.2 s, 1920×1080; CLASSIC 40M BENETTI 82.7 s, 1920×1080; ARISTARCHOS I 219.0 s, 1092×576.
- Media rights, seller mandate, current availability, and current offer price remain unverified. None of the three is cleared for commercial internet publication. Models are approximate and not survey- or builder-certified.
- The normalized catalogue currently reports 0 verified marine product records, 0 verified service-provider records, and 0 approved tier-term records. The site's concept/shop examples must not be described as actual stock or suppliers.

## Local test evidence

| Existing test | Result | Scope |
|---|---:|---|
| `tests/phase619_public_catalog.py` | 38/38 pass | Public state, role restrictions, CSRF, evidence gates, visibility, audit, state persistence |
| `tests/phase620_public_media.py` | 42/42 pass | Public image delivery, MP4 range responses, IDs/parents, hidden/private media denial |
| `tests/phase618_inventory.py` | 45/45 pass | Admin inventory access, protected source material, manual payment case notes, no payment movement |
| `tests/phase614_smoke.py` | 35/35 pass | Fictional buyer, seller and admin local API flows; saves/cart; no checkout; seller review |
| `tests/phase615_security.py` | 43/43 pass | Loopback security headers, role/CSRF controls, sessions, recovery and logout |
| `tests/phase615_routes.py` | 20/20 pass | Local page delivery and source-level SBJR/security navigation checks |
| `tests/phase618_asset_audit.py` | 39/39 asset files verified; 0 errors | File presence, checksums, GLB validity, parent/media mapping |
| Python/JavaScript syntax | pass | `backend/app.py`; `fleet.js`, `inventory-admin.js`, `acquisition.js` |
| `qa/phase617_run.py` | not completed | Harness requires `requests` and `beautifulsoup4`, unavailable in this runtime |
| `qa/phase617_browser.py` | 0 checks; blocked | Playwright Chromium closed during launch; no browser assertions or screenshots produced |
| Cloud browser to workspace loopback | blocked | Browser returned `ERR_CONNECTION_REFUSED`; it cannot reach this workspace's `127.0.0.1` server |

The successful tests are local source/API checks, not evidence of public deployment, real device behavior, public-browser E2E, production security, or legal approval. These tests used fictional local accounts and an isolated loopback server.

## Verified capability vs open gaps

**Verified in local source/API tests:** public research catalogue; correct vessel-linked photo/video IDs; video range support; four status values; separate hide/show; admin-only status updates with CSRF, reason/evidence fields and audit history; hidden listing/media denial; protected workbook/3D source; illustrative four acquisition configurations; manual payment notes remain non-payment demo records.

**Not implemented or not demonstrated end-to-end:** anonymous vessel inquiry queue and customer communication; verified production identity/email/MFA; director sign-off accounts and approvals; approved contract and fee rules; external payment reconciliation; rights-cleared seller-authorized inventory; secure hosted staging; domain/HTTPS; production monitoring/backup/rollback; live support, community posting, actual shop fulfilment, and verified marine suppliers. No untested feature is marked complete here.

## Next actions in order

1. Re-run full local harness in a runtime with its declared dependencies and a working Playwright Chromium; then obtain actual browser-to-backend evidence on a machine that can reach the local server.
2. Confirm the business entity, the three directors' identities/authority/quorum, jurisdictions, approval evidence rules, and acquisition term decisions. Use the companion draft packet; do not create real director accounts until confirmed.
3. Obtain seller authority, current availability/prices, and written rights for every image/video/brand asset proposed for publication. Replace or withhold anything uncleared.
4. Define privacy notice/consent, support handling, anti-abuse, data retention/deletion, and real identity requirements before collecting public visitor inquiries or member data.
5. Select authorized hosting, identity, database/storage, domain and operations; implement and independently assess before protected staging.
6. Complete real staging journeys and device/accessibility/security/performance checks. Public informational publication remains a later, separately authorized gate; all financial/contract functions remain disabled.
