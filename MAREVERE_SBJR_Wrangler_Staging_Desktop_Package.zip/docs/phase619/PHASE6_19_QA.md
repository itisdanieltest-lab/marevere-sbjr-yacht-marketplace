# Phase 6.19 QA and release scope

**Scope:** local, fictional demonstration backend with an actual source-workbook catalogue; 3 documented yacht vessels. Changes are not live on an internet-accessible server.

**New backend integration checks:** 38/38 pass (public visitor browsing, role boundaries, CSRF, available validation, sold proof, pending, out of stock, visibility, direct 404, audit trail, reimport persistence, media access denial, source workbook 404).

**Previous private-inventory integration regression:** 45/45 pass (full source workbook/technical specs still accessible to admin, protected 30 photos / 3 videos / 3D, restricted payment note records, unchanged identifier mapping).

**Responsive offline-browser visual checks:** 35/35 pass at 320 / 390 / 768 / 1024 / 1440 pixels (public inventory and admin-preview designs, zero JavaScript exceptions, no horizontal overflow, searching/filtering and public technical dossier display, illustration-only admin status interaction).

**Important testing limitation:** Browser navigation to the real local Python server was blocked by the testing environment (`ERR_BLOCKED_BY_ADMINISTRATOR`); backend HTTP API tests and offline-browser visual tests were run separately. A successful browser-to-backend full end-to-end test is still required in a suitable staging environment. Offline previews are **not connected to the database**.

## Publication boundaries

- ✔ The public-facing `/fleet.html` and `/api/public/inventory` are available to unauthenticated visitors *on the running localhost website*. They show original vessel IDs and workbook facts.
- ✔ Administrator controls store `available`, `pending`, `sold`, `out_of_stock`, visibility, audit reason and evidence reference in SQLite.
- ✔ Homepage yacht collection entry points link to the new public fleet route.
- ✔ Approved homepage logo and SBJR mark preserved without modifying SVG artwork.
- ✘ No live domain, external HTTPS deployment, real customer authentication, bank reconciliation, or actual payment collection.
- ✘ No acquired rights to distribute third-party yacht images/videos/models. Media remains behind admin routes; public uses concept imagery explicitly labeled as such.
- ✘ No verified sale offers or approved Tier 2/3 financial contracts.
- ✘ No guaranteed yachts-in-stock numbers beyond current 3 research entries.

## Current snapshot

- ANYA: Pending
- CLASSIC 40M BENETTI: Pending
- ARISTARCHOS I: Sold (historical announcement)
- Available: 0; Out of Stock: 0 (both can be assigned by an authenticated administrator with evidence requirements).

## Security design and remaining gaps

Status mutations require session role `admin`, CSRF, same-origin request and record an audit event. Declaring `Available` additionally requires administrator confirmation that seller authority and current availability have been verified, plus an evidence identifier. Changes remain separate from source workbook facts. Public detail data is allowlisted by field, preventing direct disclosure of broker/source notes, private ownership data, research file paths or media URLs.

This is **not a production security assurance**. The server uses demonstration credentials, has no production MFA, cloud infrastructure, monitoring, staff identity verification, email recovery service, content delivery network, or regulated transaction system. Public site deployment remains NO-GO.
