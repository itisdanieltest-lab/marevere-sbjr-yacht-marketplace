# Phase 6.13 — vertical integration matrix

| Flow | Frontend | Real local API | SQLite | Access rule | Production status |
|---|---|---|---|---|---|
| Public concept yacht discovery | Earlier collection + connected portal | `GET /api/vessels` | Seeded concepts | Public | Fictional, no sales |
| Buyer account login | `integrated.html` | `POST /api/auth/login` | PBKDF2, hashed session token | All 3 roles | Local demo only |
| Buyer saves yacht | Connected buyer portal | `POST /api/saved` | `saved` join table | Buyer | Functional demo |
| Buyer support request | Connected buyer portal | `POST /api/support/tickets` | `support_tickets` | Buyer | No staff delivery |
| Broker listing submission | Connected broker portal | `POST /api/seller/listings` | `listings` | Seller | No public publication |
| Admin review decision | Connected operations portal | `POST /api/admin/reviews/{id}/decision` | `listings`, `audit_events` | Admin | Fictional review only |
| Admin closes support case | Connected operations portal | `POST /api/admin/tickets/resolve` | `support_tickets`, `audit_events` | Admin | No live agent |
| Admin audit view | Connected operations portal | `GET /api/admin/audit` | `audit_events` | Admin | Local only |
| Tier 1 purchase | Design prototype only | None | None | Disabled | BLOCKED |
| Tier 2 Premium I/II | Design prototype only | None | None | Disabled | BLOCKED |
| Tier 3 deferred acquisition | Design prototype only | None | None | Disabled | BLOCKED |
| Deposits/payouts/settlement | None | None | None | Disabled | BLOCKED |
| 3D yacht presentation | Previous concept Three.js | No validated content API | None | Public concept | Accurate vessel-specific assets pending |
| Marine equipment checkout | Previous local cart demonstration | None | None | Disabled | BLOCKED |

## Security mechanisms proven within local demo

Password hashing with PBKDF2-SHA256 (320,000 rounds, per-user random salts); non-stored raw session tokens (SHA-256 token hash in database); HttpOnly + SameSite=Strict session cookies; six-hour session expiry; server-enforced role checks; CSRF token requirement for mutating API routes; same-origin validation on writes; request body size limits; typed inputs and length restrictions; parameterized SQL; protected server-side source/private `.runtime` paths; local-only listener; basic auth attempt limit.

**Not production-grade:** no HTTPS (localhost only), no production CSP audit for inherited pages, no durable distributed rate limiting, no account lifecycle controls, no production session/device management, no multi-factor access, no external identity proofing, no security certification, no production encryption/backup system. No claims of secure live financial handling.

## Important integration boundary

Legacy collection favorites, historical broker/admin mockups, marine shopping bag and simulated public concierge are **not yet rewritten to use the new API**. Their original frontend-only controls remain examples. The functioning server-backed workflow in this phase is explicitly the connected `integrated.html` portal. Unifying the earlier interfaces against these endpoints, adding real-account onboarding and implementing real commerce are separate pending phases. The visually simulated standalone preview never connects to the backend.
