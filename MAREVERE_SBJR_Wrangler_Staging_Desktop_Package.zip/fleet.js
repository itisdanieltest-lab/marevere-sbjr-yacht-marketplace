"use strict";
const $=id=>document.getElementById(id);
const area=$('researchGrid');
let records=[];
const badges={available:'Available · verification recorded',pending:'Pending verification',sold:'Sold',out_of_stock:'Out of stock'};
function el(t,text,cls){const e=document.createElement(t);if(text!==undefined&&text!==null)e.textContent=String(text);if(cls)e.className=cls;return e}
function label(k){return k.replace(/_/g,' ').replace(/\b\w/g,x=>x.toUpperCase())}
function show(v){return v===null||v===undefined||v===''?'Not confirmed':String(v)}
function price(v){return typeof v==='number'&&v>0?v.toLocaleString('en-IE',{style:'currency',currency:'EUR',maximumFractionDigits:0}):'Price unconfirmed'}
function badge(status){return el('span',badges[status]||status,'fleet-status '+status)}
function vesselMedia(r,kind){return (r.media||[]).filter(x=>x.type===kind)}
function makePhoto(photo,large=false){const image=el('img');image.src=photo.url;image.loading=large?'eager':'lazy';image.alt=photo.alt||'Yacht photograph';image.decoding='async';return image}
function render(){const q=$('fleetSearch').value.trim().toLowerCase(),status=$('fleetStatus').value,type=$('fleetType').value;
const shown=records.filter(r=>(status==='all'||r.status===status)&&(type==='all'||r.category===type)&&[r.name,r.builder,r.vessel_id,r.category].join(' ').toLowerCase().includes(q));
$('fleetCount').textContent=`${shown.length} of ${records.length} vessels`;area.replaceChildren();
if(!shown.length){area.append(el('p','No vessels match. Change your search or filters.'));return}
shown.forEach(r=>{const card=el('article',null,'research-card'),cover=el('div',null,'research-card-image'),body=el('div',null,'research-card-body');
const photos=vesselMedia(r,'image'),videos=vesselMedia(r,'video');
if(photos.length){const im=makePhoto(photos[0]);cover.append(im,el('span',`${photos.length} PHOTOGRAPHS · ${videos.length} VIDEO · ACTUAL LISTING MEDIA`))}
else{cover.append(el('div','Media not available','no-media'))}
body.append(el('span',r.vessel_id,'id'),el('h3',r.name),el('p',`${show(r.builder)} · ${show(r.length_m)} m · ${show(r.year)}`),el('p',show(r.summary)),badge(r.status),el('p','Workbook reference price: '+price(r.reference_price_eur),'fleet-price'),el('p','Reference price only; status and media publication rights require verification.','fleet-offer-note'));
if(r.public_note)body.append(el('p',r.public_note,'fleet-offer-note'));
const button=el('button','Explore photos & video ↗','card-button');button.type='button';button.onclick=()=>load(r.vessel_id);body.append(button);card.append(cover,body);area.append(card)})}
function mediaGallery(r){
const root=el('section',null,'vessel-gallery');const photos=vesselMedia(r,'image'),videos=vesselMedia(r,'video');
const top=el('div',null,'gallery-heading');top.append(el('h3','On board '+r.name),el('p',`${photos.length} vessel photographs · ${videos.length} listing video`));root.append(top);
const viewer=el('div',null,'gallery-viewer');viewer.setAttribute('aria-label','Vessel photo and video gallery');root.append(viewer);
const stage=el('div',null,'gallery-stage'),caption=el('p','','gallery-caption'),controls=el('div',null,'gallery-controls'),thumbs=el('div',null,'gallery-thumbs');
thumbs.setAttribute('aria-label','Choose a vessel photograph or video');
viewer.append(stage,caption,controls,thumbs);
const items=[...photos,...videos];let selected=0;
function select(index){selected=index;stage.replaceChildren();const item=items[index];if(!item)return;
if(item.type==='image') {const im=makePhoto(item,true);stage.append(im)}
else{const video=el('video');video.controls=true;video.preload='metadata';video.playsInline=true;video.setAttribute('aria-label',item.alt||'Vessel listing video');video.src=item.url;if(photos.length)video.poster=photos[0].url;stage.append(video)}
caption.textContent=item.caption||`${r.name} — ${item.type}`;
[...thumbs.children].forEach((button,i)=>{button.setAttribute('aria-pressed',String(i===index));button.classList.toggle('active',i===index)});
}
const prev=el('button','← Previous','gallery-step'),next=el('button','Next →','gallery-step');prev.type='button';next.type='button';prev.onclick=()=>select((selected-1+items.length)%items.length);next.onclick=()=>select((selected+1)%items.length);if(items.length>1)controls.append(prev,next);
items.forEach((item,i)=>{const button=el('button',null,'gallery-thumb');button.type='button';button.setAttribute('aria-label',item.type==='video'?`Watch ${r.name} video`:`View ${r.name} photo ${i+1}`);button.setAttribute('aria-pressed','false');
if(item.type==='image'){button.append(makePhoto(item))}else{const icon=el('span','▶ VIDEO','gallery-video-label');button.append(icon)}
button.onclick=()=>select(i);thumbs.append(button)});
if(items.length)select(0);else root.append(el('p','Images and video have not yet been provided for this vessel.'));
root.append(el('p','Media source: supplied listing archive. Third-party redistribution rights are not yet documented.','gallery-rights'));
return root;
}
async function load(id){const holder=$('researchDetail'),root=$('researchDetailContent');holder.hidden=false;root.replaceChildren(el('p','Loading photos, video and technical specifications…'));
try{const response=await fetch('/api/public/inventory/vessels/'+encodeURIComponent(id),{credentials:'same-origin'});if(!response.ok)throw Error('This vessel is no longer publicly listed.');const {vessel:r}=await response.json();$('researchDetailTitle').textContent=r.name;
root.replaceChildren(mediaGallery(r));const layout=el('div',null,'detail-layout'),overview=el('section'),specs=el('section');
overview.append(badge(r.status),el('h3','The vessel'),el('p',show(r.master.Full_Description||r.summary)),el('p','Workbook reference price · '+price(r.reference_price_eur),'fleet-detail-price'),el('p','Reference price only. No deposit, reservation, delivery or ownership transfer is available through this website.'));
if(r.public_note)overview.append(el('p',r.public_note));
specs.append(el('h3','Technical specification'));const dl=el('dl');for(const [key,v] of Object.entries({...r.master,...r.specifications})){if(key==='Full_Description'||key==='Short_Summary')continue;const box=el('div');box.append(el('dt',label(key)),el('dd',show(v)));dl.append(box)}specs.append(dl);layout.append(overview,specs);root.append(layout,el('p',r.disclosure,'detail-disclosure'));
holder.scrollIntoView({behavior:window.matchMedia('(prefers-reduced-motion: reduce)').matches?'auto':'smooth',block:'start'});holder.focus({preventScroll:true});
}catch(e){root.replaceChildren(el('p',e.message))}}
async function init(){try{const response=await fetch('/api/public/inventory',{credentials:'same-origin'});if(!response.ok)throw Error('Catalogue API is unavailable');const data=await response.json();records=data.vessels||[];
for(const category of [...new Set(records.map(x=>x.category))]){const option=el('option',category);option.value=category;$('fleetType').append(option)}
const desired=new URLSearchParams(location.search).get('vessel');render();if(desired&&records.some(x=>x.vessel_id===desired))load(desired)
}catch(e){area.replaceChildren(el('p','Inventory requires the running MAREVERE backend. '+e.message));$('fleetCount').textContent='Offline'}}
for(const id of ['fleetSearch','fleetStatus','fleetType'])$(id).addEventListener(id==='fleetSearch'?'input':'change',render);
$('closeDetail').addEventListener('click',()=>{$('researchDetail').querySelectorAll('video').forEach(v=>{v.pause();v.removeAttribute('src');v.load()});$('researchDetail').hidden=true;$('fleetSearch').focus()});init();
