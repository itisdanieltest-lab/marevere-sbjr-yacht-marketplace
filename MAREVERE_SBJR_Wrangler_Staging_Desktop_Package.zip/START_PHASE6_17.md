MAREVERE · SBJR — Phase 6.17 staging/browser QA handoff.
Read docs/phase617/PHASE6_17_STAGING_QA_REPORT.md; run `python qa/phase617_run.py`. No public staging URL is deployed. Production NO-GO.
