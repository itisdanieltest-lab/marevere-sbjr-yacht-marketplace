# MAREVERE · SBJR / Phase 6.19 — Public catalogue routes & admin listing-status control

## What was built

The new `/fleet.html` page is accessible to **visitors without login** and is linked from the existing approved-design homepage. It displays the three source-workbook vessels and their carefully limited public technical details. Each public vessel has an administrator-managed availability label: `Pending`, `Available`, `Sold`, `Out of Stock`. Admin may additionally **hide/show** a vessel; a hidden record is not in the public API and the direct public detail endpoint returns 404. The approved original MAREVERE · SBJR SVG/logo paths were **not changed**.

The admin page `/admin-inventory.html` retains the full private workbook dossiers including 30 photographs, three videos, and approximate 3D studies, while adding status forms with server-side role checking, CSRF protection, evidence requirements and audit history.

### Import initial states

| Workbook vessel | Initial site label | Why |
|---|---|---|
| MAREVERE-SBJR-MOTOR-YACHT-001 — ANYA | Pending | Seller authority / sale status unverified |
| MAREVERE-SBJR-MOTOR-YACHT-002 — CLASSIC 40M BENETTI | Pending | Source availability conflict |
| MAREVERE-SBJR-SAILING-YACHT-001 — ARISTARCHOS I | Sold | Historical sold announcement in source workbook |

The public catalogue shows the **workbook reference price only** and explicitly states it is *not a current offer*. It does not publish private evidence, owner information, workbook source URLs, research photographs, video or 3D without permission. Public pages currently use explicitly labeled **editorial concept imagery**.

### Start the integrated site on a computer

```
python backend/app.py
```

The server intentionally binds **127.0.0.1:8765** only. On the same computer, open:

- `http://127.0.0.1:8765/` — previously approved cinematic homepage
- `http://127.0.0.1:8765/fleet.html` — new no-login yacht catalogue
- `http://127.0.0.1:8765/integrated.html` — demonstration role-specific sign-in
- `http://127.0.0.1:8765/admin-inventory.html` — administrative status, media review and manual demo payment notes

On first run, the server generates fictional credentials at `.runtime/demo_credentials.txt`. Never upload those credentials or the `.runtime` directory. The ZIP excludes the `.runtime` directory.

### Tests

```
python tests/phase619_public_catalog.py
python tests/phase618_inventory.py
```

Tests cover public access, counts, pending/sold/out-of-stock/available, hidden-record 404, proof requirements for available and sold, role denial, CSRF checks, no public media disclosure, recorded status history, and status persistence through subsequent workbook synchronization.

### What “public” means **here**

The catalogue is **a public-facing route in the site source**, visible to any visitor on the running local server. This package has **not been deployed to an internet-accessible domain**. The local Python server deliberately refuses external binding. Do **not** open it directly to the internet: it contains `.invalid` demonstration accounts and incomplete production authentication. A separate secure staging/production architecture and deployment approval are required.

### What admin status *does not* do

Changing a status does not verify seller authority by itself, publish third-party media, process payments, create a reservation, execute Tier 1/2/3 contracts, or transfer vessel ownership. Marking *Available* requires the admin to attest both current availability and selling authority, plus provide an evidence reference. Marking *Sold* requires an evidence reference. All changes require a written reason and are audited.

The prior manual-payment interface remains **fictional DEMO case notes only**; it does not process or independently verify payments.

## Next steps before internet publication

Establish seller authorization and publication rights, reconfirm availability and asking prices, replace demo authentication with a production identity system, review server security, and deploy with secure HTTPS, staff security and monitoring. Additional inventory can be added under the same stable vessel IDs (new vessels get new IDs).
