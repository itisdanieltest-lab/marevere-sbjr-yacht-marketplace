# MAREVERE · SBJR — Phase 6.15

The luxury yacht marketplace frontend, collection, cinematic concept showroom, tier-comparison illustrations, marine shop, community, support, buyer/broker/admin portals are preserved from Phase 6.14.

**Added here:** fictional account password changes, global session revocation, developer-issued single-use token recovery, local host header validation, and repeatable security/route QA.

**Start:** `python backend/app.py` then open `http://127.0.0.1:8765/`.

**Account demo:** `http://127.0.0.1:8765/sign-in.html` (first-run generated credentials are stored locally in `.runtime/demo_credentials.txt`).

**Account security:** `http://127.0.0.1:8765/security.html` (requires a fictional signed-in session).

**Local recovery:** `python backend/app.py issue-demo-reset buyer@marevere.invalid`; then open `http://127.0.0.1:8765/recovery.html` and enter the code. No emails are sent.

**QA:** `MAREVERE_TEST_URL=http://127.0.0.1:8765 python tests/phase614_smoke.py`, then `python tests/phase615_security.py`, and `python tests/phase615_routes.py`.

Full QA and status: `docs/PHASE6_15_SECURITY_QA.md`.

This is a **local fictional demo only**. No real accounts, money, yacht ownership, payments, delivery or operational support.
