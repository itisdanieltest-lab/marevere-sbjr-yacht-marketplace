(() => {
'use strict';
const $=id=>document.getElementById(id);
const yachts=window.MAREVERE_VESSELS || [];
const inputId=new URLSearchParams(location.search).get('id');
const vessel=yachts.find(v=>v.id===inputId) || yachts[0];
if(!vessel)return;
const announce=msg=>{const el=$('announcement');el.textContent='';setTimeout(()=>el.textContent=msg,10)};
let modalReturn=null;
// Persistent site header and accessible mobile menu.
const menu=$('mobileMenu'),menuBtn=$('menuButton'),header=$('siteHeader'),scrollLine=$('scrollLine');
function setMenu(open,returnFocus=true){menuBtn.setAttribute('aria-expanded',String(open));menuBtn.setAttribute('aria-label',open?'Close navigation':'Open navigation');menu.inert=!open;menu.classList.toggle('open',open);header.classList.toggle('menu-active',open);document.body.classList.toggle('menu-open',open);if(open)menu.querySelector('a')?.focus();else if(returnFocus)menuBtn.focus();}
menuBtn.addEventListener('click',()=>setMenu(menuBtn.getAttribute('aria-expanded')!=='true'));
menu.querySelectorAll('a').forEach(a=>a.addEventListener('click',()=>setMenu(false,false)));
function updateHeader(){header.classList.toggle('is-scrolled',scrollY>25);const h=document.documentElement.scrollHeight-innerHeight;scrollLine.style.width=(h?Math.min(100,scrollY/h*100):0)+'%';}
addEventListener('scroll',updateHeader,{passive:true});updateHeader();
// Vessel information derives from shared demo catalogue.
document.title=`${vessel.name} — Vessel Dossier | MAREVERE · SBJR`;
$('edition').textContent=vessel.edition;$('overviewEdition').textContent=vessel.edition;
$('heroImage').src=vessel.image;$('heroImage').alt=`Conceptual visual representing ${vessel.name}, not verified photography of a yacht for sale`;
$('heroImage').style.objectPosition=vessel.position;
$('vesselTitle').innerHTML=`${vessel.name}<span>.</span>`;
$('heroType').textContent=vessel.type.toUpperCase();$('heroLength').textContent=`${vessel.length} METRES`;
$('heroRegion').textContent=vessel.region.replace(/ study/i,'').toUpperCase();
$('vesselFeature').textContent=vessel.feature+'.';
$('overviewDesc').textContent=vessel.desc;
$('specBigLength').textContent=vessel.length;$('specType').textContent=vessel.type;$('specLength').textContent=vessel.length+' m';$('specCabins').textContent=vessel.cabins;$('specRegion').textContent=vessel.region;
// Shared demo saved state, with a safe fallback if local storage is unavailable.
const STORAGE_KEY='marevere-demo-saved';
function readSaved(){try{const a=JSON.parse(localStorage.getItem(STORAGE_KEY)||'[]');return new Set(Array.isArray(a)?a.filter(v=>yachts.some(y=>y.id===v)):[])}catch{return new Set()}}
const saved=readSaved();let connectedBuyer=false;
function displaySaved(){const yes=saved.has(vessel.id);$('saveVessel').setAttribute('aria-pressed',String(yes));$('saveVessel').innerHTML= `${yes?'♥':'♡'} <span>${yes?'Remove saved vessel':'Save this vessel'}</span>`;$('mobileSave').textContent=yes?'♥':'♡';$('mobileSave').setAttribute('aria-pressed',String(yes));$('mobileSave').setAttribute('aria-label',yes?'Remove saved vessel':'Save vessel');}
async function toggleSaved(){if(connectedBuyer){try{await window.MarevereConnected.toggleSaved(vessel.id)}catch(err){announce('Unable to save to account: '+err.message);return}}saved.has(vessel.id)?saved.delete(vessel.id):saved.add(vessel.id);if(!connectedBuyer){try{localStorage.setItem(STORAGE_KEY,JSON.stringify([...saved]))}catch{}}displaySaved();announce(saved.has(vessel.id)?`${vessel.name} saved ${connectedBuyer?'to your buyer account':'on this device'}.`:`${vessel.name} removed from saved vessels.`);}
$('saveVessel').addEventListener('click',toggleSaved);$('mobileSave').addEventListener('click',toggleSaved);displaySaved();
// The gallery is a real working image study; no absent film or 3D model is misrepresented as delivered.
const gallery=[
 {image:vessel.image,title:'EXTERIOR CONCEPT',position:vessel.position},
 {image:'assets/yacht-close.webp',title:'THE HULL / CONCEPT',position:'62% center'},
 {image:'assets/yacht-deck.webp',title:'LIFE ON DECK / CONCEPT',position:'58% center'}
];
let photoIndex=0;
function showImage(index){photoIndex=(index+gallery.length)%gallery.length;const v=gallery[photoIndex],img=$('mediaImage');img.src=v.image;img.alt=`${v.title.toLowerCase()} — illustrative imagery only; not a verified photo of ${vessel.name}`;img.style.objectPosition=v.position;$('mediaCounter').textContent=`${String(photoIndex+1).padStart(2,'0')} / 03`;$('mediaCaption').textContent=v.title;document.querySelectorAll('.media-thumb').forEach((b,i)=>{b.setAttribute('aria-pressed',String(i===photoIndex))});}
$('mediaPrevious').addEventListener('click',()=>showImage(photoIndex-1));$('mediaNext').addEventListener('click',()=>showImage(photoIndex+1));document.querySelectorAll('.media-thumb').forEach((btn,i)=>btn.addEventListener('click',()=>showImage(i)));showImage(0);
// Accurate tier structure: Tier 1; Tier 2 (Premium I or II); Tier 3.
const tiers={
 full:{kicker:'TIER 1 / OUTRIGHT ACQUISITION',title:'A clear path<br><em>to ownership.</em>',desc:'Full settlement followed by the agreed legal transfer, documentation and delivery process.',initial:'Full agreed price',extra:'Disclosed purchase costs',delivery:'After agreed closing',required:'full'},
 p1:{kicker:'TIER 2 / PREMIUM CONFIGURATION I',title:'Secure your<br><em>chosen horizon.</em>',desc:'An initial 50% contribution under a contract whose reservation rights, legal interests, maturity dates and final obligations must be specified.',initial:'Proposed 50%',extra:'Balance and rights to define',delivery:'Per approved contract',required:'premium'},
 p2:{kicker:'TIER 2 / PREMIUM CONFIGURATION II',title:'Flexibility,<br><em>fully disclosed.</em>',desc:'The proposed 50% initial contribution with a separate 5% completion fee. The fee base, due date, title transfer and delivery permissions require approval.',initial:'Proposed 50%',extra:'Proposed 5% fee*',delivery:'Contract-dependent',required:'premium'},
 deferred:{kicker:'TIER 3 / DEFERRED ACQUISITION',title:'Time, terms<br><em>and transparency.</em>',desc:'An initial 50% contribution and a contract-defined valuation adjustment before potential final acquisition. Yacht value can rise or fall; no profit or purchase discount is guaranteed.',initial:'Proposed 50%',extra:'Valuation rule pending',delivery:'After contractual close',required:'deferred'}
};
const tierButtons=[...document.querySelectorAll('[data-tier]')];
function setTier(key,focus=false){const t=tiers[key];if(!t)return;const selectedButton=tierButtons.find(b=>b.dataset.tier===key);tierButtons.forEach(b=>{const active=b===selectedButton;b.setAttribute('aria-selected',String(active));b.tabIndex=active?0:-1;});if(focus)selectedButton.focus();$('tier-content').setAttribute('aria-labelledby',selectedButton.id);$('tierKicker').textContent=t.kicker;$('tierTitle').innerHTML=t.title;$('tierDescription').textContent=t.desc;$('tierInitial').textContent=t.initial;$('tierExtra').textContent=t.extra;$('tierDelivery').textContent=t.delivery;const available=vessel.paths.includes(t.required);$('tierAvailability').textContent=available?'Illustrative option shown for this vessel; not a real offer.':'This option is not proposed for this concept vessel.';$('tierAvailability').classList.toggle('not-available',!available);}
for(const b of tierButtons){b.addEventListener('click',()=>setTier(b.dataset.tier));b.addEventListener('keydown',e=>{const idx=tierButtons.indexOf(b);let next;if(e.key==='ArrowRight')next=(idx+1)%tierButtons.length;else if(e.key==='ArrowLeft')next=(idx-1+tierButtons.length)%tierButtons.length;else if(e.key==='Home')next=0;else if(e.key==='End')next=tierButtons.length-1;else return;e.preventDefault();setTier(tierButtons[next].dataset.tier,true);});}setTier('full');
const compareLink=$('comparePathways'); if(compareLink) compareLink.href='acquisition.html?vessel='+encodeURIComponent(vessel.id);
// The next vessels remain clearly imaginary and link back into the functional dossier.
const other=yachts.filter(y=>y.id!==vessel.id).slice(0,2);
$('relatedGrid').innerHTML=other.map(v=>`<a class="related-card" href="vessel.html?id=${v.id}"><div class="related-card-photo"><img src="${v.image}" alt="Illustrative yacht visual for concept ${v.name}" loading="lazy" style="object-position:${v.position}"><span>CONCEPT DOSSIER / ${v.edition}</span></div><div class="related-card-info"><div><h3>${v.name}<em>.</em></h3><p>${v.type} · ${v.length} m · ${v.cabins} cabins</p></div><b aria-hidden="true">↗</b></div></a>`).join('');
// Functioning demo modal: validates but NEVER sends or stores submitted personal data.
const modal=$('enquiryModal'),form=$('enquiryForm');
function openEnquiry(){modalReturn=document.activeElement;modal.hidden=false;document.body.classList.add('modal-open');$('demoConfirmation').hidden=true;form.hidden=false;$('closeEnquiry').focus();}
function closeEnquiry(){modal.hidden=true;document.body.classList.remove('modal-open');form.reset();form.hidden=false;$('demoConfirmation').hidden=true;modalReturn?.focus();}
$('openEnquiry').addEventListener('click',openEnquiry);$('closeEnquiry').addEventListener('click',closeEnquiry);
modal.addEventListener('click',e=>{if(e.target===modal)closeEnquiry()});
form.addEventListener('submit',e=>{e.preventDefault();if(!form.reportValidity())return;form.reset();form.hidden=true;$('demoConfirmation').hidden=false;$('demoConfirmation').setAttribute('tabindex','-1');$('demoConfirmation').focus();});
addEventListener('keydown',e=>{
 if(e.key==='Escape'){if(!modal.hidden)closeEnquiry();else if(menuBtn.getAttribute('aria-expanded')==='true')setMenu(false);}
 if(e.key==='Tab'&&!modal.hidden){const f=[...modal.querySelectorAll('button:not([disabled]),input:not([disabled]),select:not([disabled]),textarea:not([disabled]),a[href]')].filter(x=>x.getClientRects().length);if(!f.length)return;if(e.shiftKey&&document.activeElement===f[0]){e.preventDefault();f.at(-1).focus();}else if(!e.shiftKey&&document.activeElement===f.at(-1)){e.preventDefault();f[0].focus();}}
});
// Page label and state are always derived from the selected concept vessel.
announce(`${vessel.name} conceptual dossier loaded.`);
(async()=>{const c=window.MarevereConnected;if(!c)return;const s=await c.load();if(s?.user?.role==='buyer'){try{const data=await c.saved();connectedBuyer=true;saved.clear();data.saved.forEach(x=>saved.add(x.slug));displaySaved()}catch(err){announce('Buyer bookmark sync unavailable: '+err.message)}}})();
})();
