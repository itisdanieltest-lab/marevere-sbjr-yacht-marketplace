"""MAREVERE · SBJR Phase 6.16 static site/asset/semantics audit.
Covers source facts, NOT keyboard, color contrast, motion or visual browser QA.
No real users or financial activities are involved.
"""
from pathlib import Path
from urllib.parse import urlsplit,unquote
import json,subprocess,re
from bs4 import BeautifulSoup
ROOT=Path(__file__).resolve().parents[1]
PAGES=['index.html','collection.html','vessel.html','showroom.html','acquisition.html',
'shop.html','services.html','community.html','support.html','account.html',
'seller.html','admin.html','sign-in.html','register.html','security.html','recovery.html','integrated.html']
VIRTUAL_HASHES={('shop.html','bag')} # JavaScript opens the bag overlay for location.hash === '#bag'
entries=[]
def check(label,passed,detail='',severity='medium'):
 entries.append(dict(test=label,passed=bool(passed),detail=detail,severity=severity))
 if not passed:print('FAIL',label,detail)

pages={f:BeautifulSoup((ROOT/f).read_text(encoding='utf-8'),'html.parser') for f in PAGES}
for name,doc in pages.items():
 html=doc.find('html');main=doc.find('main')
 check(f'{name} language',bool(html and html.get('lang')=='en'))
 check(f'{name} main landmark',bool(main))
 check(f'{name} exactly one H1',len(doc.find_all('h1'))==1)
 check(f'{name} document title',bool(doc.title and 'MAREVERE' in doc.title.get_text()))
 check(f'{name} SBJR header signature',bool(doc.find('header') and 'SBJR' in doc.find('header').get_text(' ',strip=True)))
 check(f'{name} bottom-of-page SBJR identity',bool(doc.select_one('footer,.end-footer') and 'SBJR' in doc.select_one('footer,.end-footer').get_text(' ',strip=True)))
 ids=[x.get('id') for x in doc.find_all(id=True)]
 check(f'{name} unique HTML element IDs',len(ids)==len(set(ids)))
 images=doc.find_all('img')
 check(f'{name} image alt attributes',all(img.has_attr('alt') for img in images))
 skips=doc.select('a.skip,a.skip-link')
 check(f'{name} keyboard skip link',bool(skips) and any((link.get('href','').startswith('#') and bool(doc.find(id=link['href'][1:]))) for link in skips))
 for field in doc.find_all(['input','textarea','select']):
  if field.name=='input' and field.get('type')=='hidden':continue
  textlabel=field.find_parent('label')
  labelled=bool(field.get('aria-label') or field.get('aria-labelledby') or textlabel or field.get('id') and doc.find('label',attrs={'for':field['id']}))
  check(f'{name}: accessible name for {field.name}:{field.get("name") or field.get("id") or field.get("type")}',labelled)
 for target in doc.select('a[href],link[href],script[src],img[src],source[src],video[src]'):
  ref=target.get('href') or target.get('src')
  if not ref or ref.startswith(('data:','mailto:','tel:','javascript:')):continue
  u=urlsplit(ref)
  if u.scheme or u.netloc:continue
  path=unquote(u.path)
  if path and path!='/' and path.endswith(('.html','.js','.css','.webp','.png','.jpg','.jpeg','.svg','.glb','.mp4','.webm')):
   check(f'{name}: local reference {ref}',(ROOT/path.lstrip('/')).is_file(),severity='high')
  if u.fragment:
   targetdoc=pages.get(path.lstrip('/'),doc if not path else None)
   # Externally linked page may be a legacy redirect-only page, not in primary routes.
   if targetdoc:
    valid=bool(targetdoc.find(id=u.fragment)) or (path.lstrip('/') or name,u.fragment) in VIRTUAL_HASHES
    check(f'{name}: in-page anchor {ref}',valid)
for fname in sorted(ROOT.glob('*.js')):
 if fname.name.endswith('.min.js'):continue
 r=subprocess.run(['node','--check',str(fname)],capture_output=True,text=True)
 check(f'{fname.name} JavaScript syntax',r.returncode==0,r.stderr.strip()[:300],severity='high')
for f in ['assets/marevere_concept_yacht.glb','assets/marevere_cinematic_motion_study.mp4']:
 p=ROOT/f;check(f'concept media exists: {f}',p.exists() and p.stat().st_size>2000)
# Source-only disclaimers and forbidden financial API guard, not legal review.
check('acquisition page includes fictional/no-live-offer disclaimers', all(x in (ROOT/'acquisition.html').read_text().lower() for x in ['fictional','no live offers','no deposits']))
check('local backend explicitly prevents non-loopback binding','Refusing non-loopback binding' in (ROOT/'backend/app.py').read_text())
check('backend advertises disabled payments',"'payments_enabled':False" in (ROOT/'backend/app.py').read_text())
report={
 'scope':'static source semantics, file references, scripts and content labels; not rendered browser usability or security certification',
 'total':len(entries),'passed':sum(x['passed'] for x in entries),
 'failed':sum(not x['passed'] for x in entries),'failures':[x for x in entries if not x['passed']],
 'checks':entries,
 'browser_e2e':'BLOCKED_BY_ADMINISTRATOR for local/file Chromium navigation; not tested',
 'production_status':'NO-GO'
}
out=ROOT/'docs/PHASE6_16_STATIC_RESULTS.json'
out.write_text(json.dumps(report,indent=2),encoding='utf-8')
print(f'STATIC_AUDIT {report["passed"]}/{report["total"]} passed, {report["failed"]} failed; saved {out}')
