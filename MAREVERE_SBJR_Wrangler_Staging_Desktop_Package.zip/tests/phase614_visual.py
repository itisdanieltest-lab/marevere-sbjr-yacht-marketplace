"""Visual-only UI tests, NOT live backend E2E; about:blank mocked fetch only."""
from pathlib import Path
import json
from playwright.sync_api import sync_playwright
root=Path(__file__).resolve().parents[1]
html=Path('/mnt/data/MAREVERE_SBJR_Phase6_14_Visual_Only_Preview.html').read_text()
out=root/'docs'/'phase614_visual';out.mkdir(exist_ok=True)
results=[]
with sync_playwright() as pw:
    b=pw.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox','--disable-dev-shm-usage'])
    for w in (320,390,768,1024,1440):
        page=b.new_page(viewport={'width':w,'height':850},reduced_motion='reduce')
        errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
        page.set_content(html,wait_until='domcontentloaded')
        page.wait_for_timeout(250)
        # buyer role initially
        assert page.locator('#portal').is_visible(),f'portal hidden at {w}'
        for role,tab in [('buyer','marine'),('seller','listings'),('admin','reviews')]:
            page.locator('#previewRole').select_option(role)
            page.wait_for_timeout(150)
            assert page.locator('#roleBadge').inner_text().lower()==role,f'wrong role {role}'
            nav=page.locator('#roleNav button').filter(has_text={'marine':'Marine bag','listings':'My listings','reviews':'Vessel reviews'}[tab])
            nav.click();page.wait_for_timeout(120)
            assert page.locator('#workspaceBody').inner_text(),f'blank {role} {tab}'
            wide=page.evaluate('document.documentElement.scrollWidth - document.documentElement.clientWidth')
            results.append({'viewport':w,'role':role,'tab':tab,'overflow_px':wide,'page_errors':errors[:]})
            if wide>1: print('OVERFLOW',w,role,wide)
            if w in (390,1440): page.screenshot(path=str(out/f'{role}_{w}.png'),full_page=True)
        assert not errors,errors
        page.close()
    b.close()
(root/'docs'/'phase614_visual_test_results.json').write_text(json.dumps({'checks':results,'passed':sum(x['overflow_px']<=1 and not x['page_errors'] for x in results),'total':len(results)},indent=2))
print('VISUAL',sum(x['overflow_px']<=1 and not x['page_errors'] for x in results),'/',len(results))
