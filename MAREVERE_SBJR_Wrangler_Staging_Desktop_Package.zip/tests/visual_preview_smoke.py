"""Visual-preview browser QA; uses in-memory mock and is NOT live backend browser E2E."""
from pathlib import Path
from playwright.sync_api import sync_playwright
import json, sys
ROOT=Path(__file__).resolve().parents[1]
page_text=Path('/mnt/data/MAREVERE_SBJR_Phase6_13_Visual_Only_Preview.html').read_text()
results=[]
with sync_playwright() as p:
    browser=p.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox'])
    for width in (320,390,768,1024,1440):
        page=browser.new_page(viewport={'width':width,'height':900})
        errors=[]
        page.on('pageerror',lambda e:errors.append(str(e)))
        page.set_content(page_text)
        page.wait_for_timeout(150)
        assert page.locator('#portal').is_visible() and not page.locator('#loginPanel').is_visible()
        assert page.evaluate('document.documentElement.scrollWidth-innerWidth')==0
        assert not errors,errors
        results.append({'viewport':width,'no_overflow':True,'no_runtime_errors':True})
        if width in (390,1440):
            page.screenshot(path=str(ROOT/'docs'/f'connected_buyer_{width}.png'),full_page=True)
            page.locator('#previewRole').select_option('seller')
            page.wait_for_timeout(100)
            if width==390: page.screenshot(path=str(ROOT/'docs'/'connected_seller_390.png'),full_page=True)
            page.locator('#previewRole').select_option('admin')
            page.wait_for_timeout(100)
            if width==390: page.screenshot(path=str(ROOT/'docs'/'connected_admin_390.png'),full_page=True)
            page.get_by_role('button',name='Vessel reviews').click()
            assert page.locator('#workspaceHeading').inner_text()=='Listing verification.'
        page.close()
    browser.close()
(ROOT/'docs'/'visual_preview_test_results.json').write_text(json.dumps(results,indent=2))
print('PASS 5 viewports; buyer/broker/admin preview views; navigation; no JS errors, no overflow')
