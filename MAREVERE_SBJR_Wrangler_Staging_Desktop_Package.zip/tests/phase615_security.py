"""MAREVERE Phase 6.15 HTTP+SQLite security E2E. Run on LOOPBACK local fictional server only.
Do not use real identities, credentials, money, or payment data.
"""
from __future__ import annotations
import os, json, secrets, subprocess, sys, sqlite3, time
from pathlib import Path
import requests

ROOT=Path(__file__).resolve().parents[1]
BASE=os.getenv('MAREVERE_TEST_URL','http://127.0.0.1:8765')
if not BASE.startswith(('http://127.0.0.1:','http://localhost:')):
    raise SystemExit('Refusing tests against anything but a local loopback server')
results=[]
def check(label, assertion):
    ok=bool(assertion)
    results.append({'check':label,'passed':ok})
    print(('PASS ' if ok else 'FAIL ')+label,flush=True)
    if not ok: raise AssertionError(label)

def anon():
    s=requests.Session()
    r=s.get(BASE+'/api/session',timeout=10)
    check('anonymous session bootstrap '+str(len(results)+1),r.ok and not r.json()['user'])
    return s,r.json()['csrf']

def send(s,csrf,path,data):
    return s.post(BASE+path,json=data,headers={'Origin':BASE,'X-CSRF-Token':csrf},timeout=12)

def login(s,csrf,email,password):
    return send(s,csrf,'/api/auth/login',{'email':email,'password':password})

r=requests.get(BASE+'/api/health',timeout=10)
check('server local demo: payments disabled',r.status_code==200 and r.json()['payments_enabled'] is False)
check('security response headers',all(k in r.headers for k in ('Content-Security-Policy','X-Frame-Options','X-Content-Type-Options','Referrer-Policy')))
check('host header restricted to localhost',requests.get(BASE+'/api/health',headers={'Host':'evil.example'},timeout=10).status_code==400)
check('source, database and archive are hidden',all(requests.get(BASE+x,timeout=10).status_code==404 for x in ('/backend/app.py','/migrations/0001_init.sql','/.runtime/demo_credentials.txt','/design_archive/admin.html')))
check('new security pages are available',all(requests.get(BASE+'/'+x,timeout=10).status_code==200 for x in ('security.html','recovery.html','security.js','recovery.js')))
check('no real payment route',requests.get(BASE+'/api/payment/checkout',timeout=10).status_code==404)
info=requests.get(BASE+'/api/auth/recovery/info',timeout=10).json()
check('no mail/identity provider is falsely enabled',info['email_delivery'] is False and info['token_delivery']=='local developer CLI only')

# Register fictional buyer, obtain two sessions to verify global revocation.
s,c=anon()
email='security_'+secrets.token_hex(6)+'@marevere.invalid'
pw='fictional-security-2026-X1';new_pw='fictional-new-secret-2026-X2';reset_pw='fictional-reset-secret-2026-X3'
check('no real email registration',send(s,c,'/api/auth/register',{'email':'real-user@gmail.com','name':'Demo Person','password':pw}).status_code==400)
check('fictional registration',send(s,c,'/api/auth/register',{'email':email,'name':'Security Explorer','password':pw}).status_code==201)
check('cannot login with forged origin',s.post(BASE+'/api/auth/login',headers={'Origin':'https://evil.example','X-CSRF-Token':c},json={'email':email,'password':pw},timeout=10).status_code==403)
check('cannot login with missing CSRF',s.post(BASE+'/api/auth/login',headers={'Origin':BASE},json={'email':email,'password':pw},timeout=10).status_code==403)
check('fictional account login',login(s,c,email,pw).status_code==200)
c=s.get(BASE+'/api/session',timeout=10).json()['csrf']
check('session cookie stored for demo browser',bool(s.cookies.get('mv_session')))
# Cookie attributes must be asserted from a fresh response.
s3,c3=anon();r=login(s3,c3,email,pw)
check('second parallel session works',r.status_code==200)
check('session cookie has HttpOnly and Strict',all(x in r.headers.get('Set-Cookie','') for x in ('HttpOnly','SameSite=Strict')))
check('authenticated role is buyer',s.get(BASE+'/api/session').json()['user']['role']=='buyer')
check('buyer may not approve a vessel',send(s,c,'/api/admin/reviews/1/decision',{'decision':'approved'}).status_code==403)
check('broker operations are forbidden to buyer',s.get(BASE+'/api/seller/listings').status_code==403)
check('current password must match',send(s,c,'/api/auth/change-password',{'current_password':'incorrect','new_password':new_pw}).status_code==403)
check('weak password rejected',send(s,c,'/api/auth/change-password',{'current_password':pw,'new_password':'short'}).status_code==400)
check('missing csrf rejects password change',s.post(BASE+'/api/auth/change-password',headers={'Origin':BASE},json={'current_password':pw,'new_password':new_pw},timeout=10).status_code==403)
check('password change succeeds',send(s,c,'/api/auth/change-password',{'current_password':pw,'new_password':new_pw}).status_code==200)
check('change revokes current and parallel sessions',s.get(BASE+'/api/session').json()['user'] is None and s3.get(BASE+'/api/session').json()['user'] is None)
wrong,xc=anon();check('old password invalid after change',login(wrong,xc,email,pw).status_code==401)
s4,c4=anon();check('new password valid after change',login(s4,c4,email,new_pw).status_code==200)
c4=s4.get(BASE+'/api/session').json()['csrf']

# Local reset CLI: only developer terminal has token, no public mail delivery.
cli=subprocess.run([sys.executable,str(ROOT/'backend/app.py'),'issue-demo-reset',email],capture_output=True,text=True,timeout=15)
check('developer-only recovery token command runs',cli.returncode==0 and 'LOCAL-ONLY' in cli.stdout)
token=cli.stdout.strip().splitlines()[-1]
check('generated recovery token is unpredictable length',len(token)>=40)
check('reset token is not stored in clear text',token not in str((ROOT/'.runtime/marevere_demo.sqlite3').read_bytes()))
recovery,rc=anon()
check('invalid recovery token rejected',send(recovery,rc,'/api/auth/recovery/complete',{'token':'x'*54,'new_password':reset_pw}).status_code==400)
check('recovery cannot bypass origin',recovery.post(BASE+'/api/auth/recovery/complete',headers={'Origin':'https://evil.example','X-CSRF-Token':rc},json={'token':token,'new_password':reset_pw},timeout=10).status_code==403)
check('valid single-use recovery completes',send(recovery,rc,'/api/auth/recovery/complete',{'token':token,'new_password':reset_pw}).status_code==200)
check('recovery token replay denied',send(recovery,rc,'/api/auth/recovery/complete',{'token':token,'new_password':new_pw}).status_code==400)
check('recovery revokes prior sessions',s4.get(BASE+'/api/session').json()['user'] is None)
last,lc=anon();check('reset password now signs in',login(last,lc,email,reset_pw).status_code==200)
lc=last.get(BASE+'/api/session').json()['csrf']
check('logout all succeeds',send(last,lc,'/api/auth/logout-all',{}).status_code==200)
check('logout all invalidates session',last.get(BASE+'/api/session').json()['user'] is None)

# Expiry simulation: direct modification is local test-only, no live identities.
cli=subprocess.run([sys.executable,str(ROOT/'backend/app.py'),'issue-demo-reset',email],capture_output=True,text=True,timeout=15)
expired_token=cli.stdout.strip().splitlines()[-1]
import hashlib
with sqlite3.connect(ROOT/'.runtime/marevere_demo.sqlite3') as db:
    db.execute('UPDATE password_reset_tokens SET expires_at=? WHERE token_hash=?',(int(time.time())-1,hashlib.sha256(expired_token.encode()).hexdigest()))
check('expired recovery token is rejected',send(recovery,rc,'/api/auth/recovery/complete',{'token':expired_token,'new_password':new_pw}).status_code==400)

# Avoid logging secrets or PII in the generated report.
report={'phase':'6.15','scope':'loopback-only fictional HTTP/API/security tests','total':len(results),'passed':sum(x['passed'] for x in results),'cases':results}
output=ROOT/'docs/phase615_security_results.json';output.write_text(json.dumps(report,indent=2))
print('SECURITY_RESULT',report['passed'],'/',report['total'],flush=True)
