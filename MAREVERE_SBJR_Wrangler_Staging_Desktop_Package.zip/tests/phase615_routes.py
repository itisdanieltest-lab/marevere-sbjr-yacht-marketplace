"""Phase 6.15 local public-surface route and JS delivery checks; not a browser layout test."""
from pathlib import Path
from html.parser import HTMLParser
from urllib.parse import urlsplit,unquote
import os,requests,json,subprocess
ROOT=Path(__file__).resolve().parents[1]
BASE=os.environ.get('MAREVERE_TEST_URL','http://127.0.0.1:8765')
PAGES=['index.html','collection.html','vessel.html','showroom.html','acquisition.html',
       'shop.html','services.html','community.html','support.html','account.html',
       'seller.html','admin.html','sign-in.html','register.html','security.html','recovery.html']
class Refs(HTMLParser):
  def __init__(self):super().__init__();self.refs=[]
  def handle_starttag(self, tag, attrs):
    data=dict(attrs)
    for key in ('href','src'):
      if key in data and tag in ('a','script','link','img','source'):
        self.refs.append((tag,key,data[key]))
checks=[]
def check(name,ok):
  checks.append({'name':name,'passed':bool(ok)})
  print(('PASS ' if ok else 'FAIL ')+name)
  if not ok: raise AssertionError(name)

s=requests.Session()
for page in PAGES:
  r=s.get(BASE+'/'+page,timeout=10)
  check(page+' served',r.status_code==200 and '<html' in r.text.lower())
  parser=Refs();parser.feed(r.text)
  for tag,key,ref in parser.refs:
    if not ref or ref.startswith(('#','data:','mailto:','tel:')):continue
    u=urlsplit(ref)
    if u.scheme or u.netloc:continue
    path=unquote(u.path)
    if not path:continue
    # Only test links to static page/css/js/image/video assets; hash and API routes handled elsewhere.
    if not any(path.lower().endswith(ext) for ext in ('.html','.css','.js','.webp','.png','.jpg','.svg','.glb','.mp4')):continue
    if not (ROOT/path.lstrip('/')).is_file():
      check(page+' local asset '+path,False)
check('all listed pages use SBJR signature',all('SBJR' in (ROOT/x).read_text() for x in PAGES))
check('security link appears in connected buyer/seller/admin navigation',all('href="security.html"' in (ROOT/x).read_text() for x in ['account.html','seller.html','admin.html']))
check('local recovery link visible from sign-in', 'href="recovery.html"' in (ROOT/'sign-in.html').read_text())
check('new security JS compiles',all(subprocess.run(['node','--check',str(ROOT/x)],capture_output=True).returncode==0 for x in ('security.js','recovery.js')))
report={'total':len(checks),'passed':sum(c['passed'] for c in checks),'checks':checks,'browser_rendering':'NOT TESTED: Chromium blocked loopback navigation by administrator policy'}
(ROOT/'docs/phase615_routes_results.json').write_text(json.dumps(report,indent=2))
print('ROUTES_RESULT',report['passed'],'/',report['total'])
