"""Phase 6.14 buyer registration, saved/catalog/cart, seller and staff workflow smoke tests. Fictional local data only."""
from pathlib import Path
import json, os, re, secrets
import requests
BASE=os.environ.get('MAREVERE_TEST_URL','http://127.0.0.1:8765')
report=[]
def ck(msg, result):
 result=bool(result);report.append({'check':msg,'pass':result});print(('PASS' if result else 'FAIL')+' '+msg)
 if not result:raise AssertionError(msg)

def new_session():
 s=requests.Session();csrf=s.get(BASE+'/api/session').json()['csrf'];return s,csrf

def post(s,c,path,payload):return s.post(BASE+path,json=payload,headers={'Origin':BASE,'X-CSRF-Token':c},timeout=10)

def login(role):
 text=(Path(__file__).resolve().parents[1]/'.runtime/demo_credentials.txt').read_text()
 row=next(x for x in text.splitlines() if x.startswith(role.upper()))
 email=re.search(r'[\w.+-]+@marevere\.invalid',row).group();pwd=row.split('PASSWORD: ')[1]
 s,c=new_session();resp=post(s,c,'/api/auth/login',{'email':email,'password':pwd});ck(role+' authenticates',resp.status_code==200)
 return s,s.get(BASE+'/api/session').json()['csrf']

ck('homepage served',requests.get(BASE+'/').status_code==200)
ck('account, seller, admin and register HTML served',all(requests.get(BASE+'/'+p).status_code==200 for p in ['account.html','seller.html','admin.html','sign-in.html','register.html']))
ck('no archived unprotected account UI exposed',requests.get(BASE+'/design_archive/admin.html').status_code==404)
ck('public concept products available',len(requests.get(BASE+'/api/products').json()['products'])==8)
ck('unauthenticated marine bag denied',requests.get(BASE+'/api/cart').status_code==401)
ck('payments still blocked',requests.get(BASE+'/api/health').json()['payments_enabled'] is False)
s,c=new_session()
ck('fictional registration rejects real domains',post(s,c,'/api/auth/register',{'email':'buyer@gmail.com','name':'Demo Explorer','password':'this-is-a-long-demo-pass'}).status_code==400)
ck('fictional registration rejects weak password',post(s,c,'/api/auth/register',{'email':'demo@marevere.invalid','name':'Demo Explorer','password':'short'}).status_code==400)
email='demo_'+secrets.token_hex(4)+'@marevere.invalid';pw='fictional-long-pass-147'
ck('fictional buyer registration accepted',post(s,c,'/api/auth/register',{'email':email,'name':'Demo Explorer','password':pw}).status_code==201)
ck('duplicate fiction registration rejected',post(s,c,'/api/auth/register',{'email':email,'name':'Demo Explorer','password':pw}).status_code==409)
ck('new fictional account can sign in',post(s,c,'/api/auth/login',{'email':email,'password':pw}).status_code==200)
c=s.get(BASE+'/api/session').json()['csrf']
ck('buyer sees empty cart',s.get(BASE+'/api/cart').status_code==200)
ck('cart rejects unknown product',post(s,c,'/api/cart',{'product_id':'ghost','quantity':1}).status_code==404)
ck('cart rejects negative quantities',post(s,c,'/api/cart',{'product_id':'teak','quantity':-1}).status_code==400)
ck('cart rejects tampered quantities',post(s,c,'/api/cart',{'product_id':'teak','quantity':999}).status_code==400)
ck('cart rejects forged origin',s.post(BASE+'/api/cart',json={'product_id':'teak','quantity':1},headers={'Origin':'http://bad.invalid','X-CSRF-Token':c}).status_code==403)
ck('cart rejects missing csrf',s.post(BASE+'/api/cart',json={'product_id':'teak','quantity':1},headers={'Origin':BASE}).status_code==403)
ck('buyer adds a fictional marine product',post(s,c,'/api/cart',{'product_id':'teak','quantity':2,'price_eur':0}).status_code==200)
r=s.get(BASE+'/api/cart').json()
ck('server computes authoritative illustrative price',r['total_eur']==2960 and len(r['items'])==1 and r['items'][0]['quantity']==2)
ck('no checkout flag',r['checkout_enabled'] is False)
ck('buyer saves vessel in account',post(s,c,'/api/saved',{'slug':'vela'}).status_code==200)
ck('buyer saved vessel persists',any(x['slug']=='vela' for x in s.get(BASE+'/api/saved').json()['saved']))
ck('buyer cart remains after fresh GET',s.get(BASE+'/api/cart').json()['total_eur']==2960)
ck('buyer removes marine item',post(s,c,'/api/cart',{'product_id':'teak','quantity':0}).status_code==200 and not s.get(BASE+'/api/cart').json()['items'])
seller,sc=login('seller');admin,ac=login('admin')
ck('seller cannot read buyer cart',seller.get(BASE+'/api/cart').status_code==403)
ck('administrator cannot update buyer cart',post(admin,ac,'/api/cart',{'product_id':'teak','quantity':1}).status_code==403)
name='VICTOR '+secrets.token_hex(3)
r=post(seller,sc,'/api/seller/listings',{'name':name,'length_m':27,'description':'Fictional marina cruiser concept for staging testing.'})
ck('seller submits fictional vessel for review',r.status_code==201)
ident=r.json()['id']
ck('pending submission is not in public list',not any(x['id']==ident for x in requests.get(BASE+'/api/public/listings').json()['listings']))
ck('admin marks fictional vessel reviewed',post(admin,ac,f'/api/admin/reviews/{ident}/decision',{'decision':'approved'}).status_code==200)
ck('approved fictional concept read-only listing visible',any(x['id']==ident and x['name']==name for x in requests.get(BASE+'/api/public/listings').json()['listings']))
ck('no payment endpoint',post(s,c,'/api/payments',{'amount':500}).status_code==404)
ck('no real email sent or password reset capability',requests.get(BASE+'/api/auth/reset').status_code==404)
ck('logout invalidates local session',post(s,c,'/api/auth/logout',{}).status_code==200 and s.get(BASE+'/api/cart').status_code==401)
output=Path(__file__).parents[1]/'docs/phase614_api_test_results.json';output.write_text(json.dumps({'total':len(report),'passed':sum(x['pass'] for x in report),'cases':report},indent=2))
print('RESULT',sum(x['pass'] for x in report),'/',len(report),'→',output)
