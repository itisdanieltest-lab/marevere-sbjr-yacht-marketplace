"""Read-only import + private media + role enforcement + manual demo status integration tests."""
from __future__ import annotations
from pathlib import Path
import importlib.util, tempfile, threading, json, urllib.request, urllib.error, http.cookiejar, re, shutil
from http.server import ThreadingHTTPServer

ROOT=Path(__file__).resolve().parent.parent
spec=importlib.util.spec_from_file_location('marevere_backend',ROOT/'backend/app.py')
app=importlib.util.module_from_spec(spec);spec.loader.exec_module(app)
results=[]
def check(name,cond):
    results.append((name,bool(cond)))
    if not cond:raise AssertionError('FAIL: '+name)

def client():
    return urllib.request.build_opener(urllib.request.HTTPCookieProcessor(http.cookiejar.CookieJar()))

def req(op,url,method='GET',body=None,headers=None):
    payload=None if body is None else json.dumps(body).encode('utf8')
    h={'Content-Type':'application/json'} if body is not None else {}
    h.update(headers or {})
    request=urllib.request.Request(BASE+url,data=payload,method=method,headers=h)
    try:
        with op.open(request,timeout=15) as r:
            data=r.read(); return r.status,r.headers,data
    except urllib.error.HTTPError as e:
        return e.code,e.headers,e.read()

def decoded(*args,**kwargs):
    code,headers,data=req(*args,**kwargs)
    return code,json.loads(data) if data else {},headers

def login(op,role,pwd):
    _,session,_=decoded(op,'/api/session')
    assert session['csrf']
    c,resp,_=decoded(op,'/api/auth/login','POST',{'email':('broker' if role=='seller' else role)+'@marevere.invalid','password':pwd},{'Origin':BASE,'X-CSRF-Token':session['csrf']})
    check(role+' login',c==200 and resp.get('role')==('seller' if role=='broker' else role))
    return decoded(op,'/api/session')[1]['csrf']

with tempfile.TemporaryDirectory(prefix='marevere618-tests-') as tmp:
    app.DATA=Path(tmp)/'.runtime';app.DB_PATH=app.DATA/'test.sqlite3';app.CRED_PATH=app.DATA/'passwords.txt';app.init_db()
    # Prior demo uses seller@marevere.invalid, not broker@...
    pwd={}
    for line in app.CRED_PATH.read_text().splitlines():
        match=re.search(r'^(BUYER|SELLER|ADMIN)\s+([^\s]+)\s+PASSWORD: (.+)',line)
        if match:pwd[match.group(1).lower()]=match.group(3)
    check('3 local demo role accounts',len(pwd)==3)
    server=ThreadingHTTPServer(('127.0.0.1',0),app.Handler)
    port=server.server_port;BASE=f'http://127.0.0.1:{port}'
    thread=threading.Thread(target=server.serve_forever,daemon=True);thread.start()
    try:
        anon,buyer,seller,admin=client(),client(),client(),client()
        buyer_csrf=login(buyer,'buyer',pwd['buyer']); seller_csrf=login(seller,'seller',pwd['seller']);admin_csrf=login(admin,'admin',pwd['admin'])
        c,data,_=decoded(anon,'/api/admin/inventory/vessels');check('anonymous inventory forbidden',c==401)
        c,data,_=decoded(buyer,'/api/admin/inventory/vessels');check('buyer inventory forbidden',c==403)
        c,data,_=decoded(seller,'/api/admin/inventory/vessels');check('broker inventory forbidden',c==403)
        c,data,_=decoded(admin,'/api/admin/inventory/vessels');check('admin inventory list',c==200 and len(data['records'])==3)
        ids=[x['vessel_id'] for x in data['records']]
        check('stable original IDs',set(ids)=={'MAREVERE-SBJR-MOTOR-YACHT-001','MAREVERE-SBJR-MOTOR-YACHT-002','MAREVERE-SBJR-SAILING-YACHT-001'})
        check('zero published',data['publicly_approved']==0 and all(not r['can_publish'] for r in data['records']))
        check('private hero media present',all(r['hero'] and '/api/admin/' in r['hero'] for r in data['records']))
        mid='MAREVERE-SBJR-MOTOR-YACHT-001'
        c,info,_=decoded(admin,'/api/admin/inventory/vessels/'+mid)
        check('full admin dossier',c==200 and 'technical' in info['record'] and 'master' in info['record'])
        check('workbook specs preserved',info['record']['technical']['Beam_m']==8.1 and info['record']['master']['Asking_Price']==9495000)
        check('13 media per dossier',len(info['record']['media'])==13)
        check('original source evidence available',len(info['record']['evidence'])>=2)
        check('unapproved clearance flags',not any(info['record']['clearance'].values()))
        c,h,b=req(anon,'/inventory_private/images/MAREVERE-SBJR-MOTOR-YACHT-001-IMG-001.webp');check('direct private directory forbidden',c==404)
        c,h,b=req(anon,'/inventory_private/inventory_normalized_private.json');check('private JSON direct forbidden',c==404)
        image='/api/admin/inventory/media/MAREVERE-SBJR-MOTOR-YACHT-001-IMG-001'
        c,h,b=req(anon,image);check('anonymous media denied',c==401)
        c,h,b=req(buyer,image);check('buyer media denied',c==403)
        c,h,b=req(admin,image,headers={'Range':'bytes=0-31'});check('admin image range streaming',c==206 and len(b)==32 and h['Content-Range'].startswith('bytes 0-31/'))
        video='/api/admin/inventory/media/MAREVERE-SBJR-MOTOR-YACHT-001-VID-001'
        c,h,b=req(admin,video,headers={'Range':'bytes=0-63'});check('video range supports player',c==206 and len(b)==64 and b[4:8]==b'ftyp')
        glb='/api/admin/inventory/media/MAREVERE-SBJR-MOTOR-YACHT-001-3D-001'
        c,h,b=req(admin,glb,headers={'Range':'bytes=0-19'});check('protected 3D model',c==206 and b[:4]==b'glTF')
        c,h,b=req(buyer,'/api/admin/inventory/workbook');check('buyer workbook denied',c==403)
        c,h,b=req(admin,'/api/admin/inventory/workbook');check('admin workbook download',c==200 and b[:2]==b'PK' and len(b)>50000)
        c,data,_=decoded(anon,'/api/public/listings');check('zero research records in public listings',c==200 and not any(x.get('name')=='ANYA' for x in data.get('listings',[])))
        c,data,_=decoded(buyer,'/api/vessels');check('research yachts not inserted into demo buyer catalogue',c==200 and all(v['name']!='ANYA' for v in data['vessels']))
        pay={'vessel_id':mid,'buyer_reference':'DEMO-CLIENT-111','amount_eur':'25000.00','private_note':'Local demonstration only'}
        headers={'Origin':BASE,'X-CSRF-Token':buyer_csrf}
        c,data,_=decoded(buyer,'/api/admin/inventory/manual-payments','POST',pay,headers);check('buyer cannot open payment case',c==403)
        c,data,_=decoded(admin,'/api/admin/inventory/manual-payments','POST',pay,{'Origin':BASE});check('missing csrf blocks payment edit',c==403)
        pay['buyer_reference']='REAL-CLIENT-111'
        c,data,_=decoded(admin,'/api/admin/inventory/manual-payments','POST',pay,{'Origin':BASE,'X-CSRF-Token':admin_csrf});check('non demo buyer ref rejected',c==400)
        pay['buyer_reference']='DEMO-CLIENT-111'
        c,data,_=decoded(admin,'/api/admin/inventory/manual-payments','POST',pay,{'Origin':BASE,'X-CSRF-Token':admin_csrf});check('admin creates internal payment case',c==201 and data['real_payments_enabled'] is False)
        case_id=data.get('case_id')
        c,data,_=decoded(admin,f'/api/admin/inventory/manual-payments/{case_id}/status','POST',{'status':'marked_paid_offline'}, {'Origin':BASE,'X-CSRF-Token':admin_csrf});check('paid status requires evidence and note',c==400)
        c,data,_=decoded(admin,f'/api/admin/inventory/manual-payments/{case_id}/status','POST',{'status':'marked_paid_offline','evidence_reference':'EXTERNAL-DEMO-123','private_note':'Fictional bank transfer verified offline for demonstration only.'},{'Origin':BASE,'X-CSRF-Token':admin_csrf});check('admin may manually update local status',c==200 and data['actual_money_movement'] is False)
        c,data,_=decoded(admin,'/api/admin/inventory/manual-payments');check('payment case persisted',c==200 and data['payments'][0]['status']=='marked_paid_offline')
        c,data,_=decoded(admin,f'/api/admin/inventory/manual-payments/{case_id}/history');check('admin action history persisted',c==200 and len(data['events'])==2)
        c,data,_=decoded(buyer,'/api/admin/inventory/manual-payments');check('buyer blocked from payment ledger',c==403)
        c,data,_=decoded(admin,'/api/admin/audit');check('payment operations in general audit',c==200 and any('DEMO_PAYMENT' in x['event'] for x in data['events']))
        app.init_db()
        c,data,_=decoded(admin,'/api/admin/inventory/manual-payments');check('import idempotent preserves payment cases',c==200 and len(data['payments'])==1)
        c,h,b=req(admin,'/inventory_private/models/MAREVERE-SBJR-MOTOR-YACHT-001-3D-001.glb');check('direct GLB static path denied',c==404)
        c,h,b=req(anon,'/admin-inventory.html');check('admin screen static shell available without private data',c==200 and b'PUBLIC REFERENCE CATALOGUE' in b)
        c,h,b=req(anon,'/api/admin/inventory/media/MAREVERE-SBJR-MOTOR-YACHT-002-IMG-001');check('different research media denied',c==401)
        c,h,b=req(anon,'/api/admin/inventory/vessels/MAREVERE-SBJR-SAILING-YACHT-001');check('sailing research detail denied',c==401)
        c,h,b=req(anon,'/api/admin/inventory/manual-payments');check('anonymous payment notes denied',c==401)
        c,h,b=req(anon,'/inventory_private/MAREVERE_SBJR_Inventory_Research_Catalog_v2.xlsx');check('workbook static path denied',c==404)
        c,h,b=req(anon,'/inventory_private/source%20notes/ASSET_MANIFEST.csv');check('manifest static path denied',c==404)
    finally:
        server.shutdown();server.server_close();thread.join(timeout=5)
report={'passed':sum(x[1] for x in results),'total':len(results),'results':[{'test':x,'passed':y}for x,y in results]}
(ROOT/'docs'/'phase618').mkdir(parents=True,exist_ok=True)
(ROOT/'docs'/'phase618'/'api_test_results.json').write_text(json.dumps(report,indent=2))
print(json.dumps({'passed':report['passed'],'total':report['total']},indent=2))
