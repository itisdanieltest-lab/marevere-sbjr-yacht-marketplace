"""Browser-to-backend checks with local fictional accounts, Playwright Chromium."""
from pathlib import Path
from playwright.sync_api import sync_playwright
import json,os,re
BASE=os.environ.get('MAREVERE_TEST_URL','http://127.0.0.1:8765')
project=Path(__file__).parents[1]
creds=(project/'.runtime/demo_credentials.txt').read_text()
accounts={}
for role in ('buyer','seller','admin'):
    row=next(x for x in creds.splitlines() if x.startswith(role.upper()))
    accounts[role]=(re.search(r'[\w.+-]+@marevere\.invalid',row).group(),row.split('PASSWORD: ')[1])
output=project/'docs'/'phase614_visual';output.mkdir(exist_ok=True,parents=True)
results=[]
def check(msg,ok):
    print(('PASS' if ok else 'FAIL')+' '+msg);results.append({'test':msg,'pass':bool(ok)})
    if not ok:raise AssertionError(msg)

def login(page,role,route):
    email,pwd=accounts[role]
    page.goto(BASE+'/'+route,wait_until='domcontentloaded')
    page.locator('#loginPanel').wait_for(state='visible',timeout=12000)
    page.locator('[name=email]').fill(email)
    page.locator('[name=password]').fill(pwd)
    page.locator('#loginForm button[type=submit]').click()
    page.locator('#portal').wait_for(state='visible',timeout=15000)
    page.locator('#personName').wait_for(state='visible',timeout=8000)

with sync_playwright() as pw:
    browser=pw.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox','--disable-dev-shm-usage'])
    for width in (390,1440):
        context=browser.new_context(viewport={'width':width,'height':850},device_scale_factor=1,reduced_motion='reduce')
        page=context.new_page();errors=[]
        page.on('pageerror',lambda e:errors.append(str(e)))
        login(page,'buyer','account.html')
        check(f'buyer page visible at {width}',page.locator('#workspaceHeading').is_visible())
        page.screenshot(path=str(output/f'buyer_{width}.png'),full_page=True)
        page.goto(BASE+'/collection.html',wait_until='domcontentloaded');page.locator('.catalog-card').first.wait_for()
        page.wait_for_timeout(1400)
        check(f'collection displays 6 curated fictional concepts at {width}',page.locator('.catalog-card').count()==6)
        check(f'collection loaded shared account saves at {width}',page.evaluate("document.querySelector('#savedCount').textContent.includes('saved')"))
        page.screenshot(path=str(output/f'collection_{width}.png'),full_page=False)
        # Simulate new site integration, using a vessel not previously saved.
        before=page.locator('[data-save="tide"]').get_attribute('aria-pressed')
        page.locator('[data-save="tide"]').click()
        page.wait_for_timeout(650)
        after=page.locator('[data-save="tide"]').get_attribute('aria-pressed')
        check(f'collection save toggles via API at {width}',before!=after)
        page.goto(BASE+'/vessel.html?id=tide',wait_until='domcontentloaded');page.locator('#saveVessel').wait_for();page.wait_for_timeout(900)
        check(f'vessel dossier reflects persisted bookmark at {width}',page.locator('#saveVessel').get_attribute('aria-pressed')==after)
        page.goto(BASE+'/shop.html',wait_until='domcontentloaded');page.locator('[data-add="kit"]').wait_for();page.wait_for_timeout(800)
        count1=int(page.locator('#bagCount').inner_text());page.locator('[data-add="kit"]').click();page.wait_for_timeout(700)
        count2=int(page.locator('#bagCount').inner_text())
        check(f'marine bag updates at {width}',count2==count1+1)
        page.screenshot(path=str(output/f'marine_{width}.png'),full_page=False)
        page.goto(BASE+'/account.html?tab=marine',wait_until='domcontentloaded');page.locator('#portal').wait_for(state='visible');page.wait_for_timeout(600)
        check(f'buyer dashboard marine tab at {width}',page.locator('#workspaceHeading').inner_text().strip()=='The marine atelier.')
        check(f'connected bag shows fictional item at {width}',page.locator('#workspaceBody').inner_text().find('Vessel Care Kit')>=0)
        page.screenshot(path=str(output/f'cart_{width}.png'),full_page=False)
        page.goto(BASE+'/support.html',wait_until='domcontentloaded');check(f'public support link to buyer cases at {width}',page.locator('a[href="account.html?tab=tickets"]').count()==1)
        check(f'no JS page exceptions in buyer journeys at {width}',not errors)
        check(f'no horizontal overflow account at {width}',(page.goto(BASE+'/account.html') or True) and page.evaluate('document.documentElement.scrollWidth <= window.innerWidth+1'))
        context.close()
    # Separate authenticated broker context
    context=browser.new_context(viewport={'width':390,'height':850},reduced_motion='reduce');p=context.new_page();errs=[];p.on('pageerror',lambda e:errs.append(str(e)))
    login(p,'seller','seller.html');check('broker connected portal works',p.locator('#roleBadge').inner_text()=='SELLER');p.screenshot(path=str(output/'broker_390.png'),full_page=False)
    p.goto(BASE+'/admin.html',wait_until='domcontentloaded');p.locator('#offline').wait_for(state='visible')
    check('broker cannot open admin workspace', 'another role' in p.locator('#offline').inner_text())
    context.close()
    # Admin separate context
    context=browser.new_context(viewport={'width':1440,'height':900},reduced_motion='reduce');p=context.new_page();p.on('pageerror',lambda e:errors.append(str(e)))
    login(p,'admin','admin.html');check('admin connected portal works',p.locator('#roleBadge').inner_text()=='ADMIN');p.screenshot(path=str(output/'admin_1440.png'),full_page=True)
    check('no JS exceptions in admin',not errors)
    context.close();browser.close()
(output.parent/'phase614_browser_results.json').write_text(json.dumps({'total':len(results),'passed':sum(x['pass'] for x in results),'cases':results},indent=2))
print('BROWSER',sum(x['pass'] for x in results),'/',len(results))
