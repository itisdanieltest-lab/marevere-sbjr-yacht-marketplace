"""Validate that the workbook's unique media IDs map to actual files and known hashes."""
from pathlib import Path
import json, csv, hashlib, collections, struct
r=Path(__file__).resolve().parent.parent
p=r/'inventory_private'; manifest=p/'source notes'/'ASSET_MANIFEST.csv'; source=p/'inventory_normalized_private.json'
data=json.loads(source.read_text()); records=data['records']
items=list(csv.DictReader(manifest.open(newline='')))
errors=[];actual=[]
for row in items:
 file=(p/row['Relative_Path']).resolve()
 if not file.is_relative_to(p.resolve()) or not file.exists(): errors.append('missing/invalid: '+row['Media_ID']);continue
 actual.append(file)
 if str(file.stat().st_size)!=row['Size_Bytes']: errors.append('size mismatch: '+row['Media_ID'])
 sha=hashlib.sha256(file.read_bytes()).hexdigest()
 if sha.lower()!=row['SHA256'].lower(): errors.append('hash mismatch: '+row['Media_ID'])
 if file.suffix.lower()=='.glb':
  raw=file.read_bytes();m,ver,size=struct.unpack('<4sII',raw[:12]);
  if m!=b'glTF' or ver!=2 or size!=len(raw):errors.append('GLB invalid: '+row['Media_ID'])
media=[m for x in records for m in x['media']]
if set(x['Media_ID'] for x in media)!=set(x['Media_ID'] for x in items): errors.append('manifest workbook ID mismatch')
for x in records:
 id=x['vessel_id'];group=[m for m in media if m['Vessel_ID']==id]
 if len(group)!=13:errors.append('Unexpected media count '+id)
 if x['clearance']['public_listing'] or x['clearance']['media_publication_rights']:errors.append('Incorrectly marked cleared '+id)
print('Media manifest',len(items),'all media',len(media),'files passed',len(actual),'total bytes',sum(x.stat().st_size for x in actual))
summary={'vessels':len(records),'media':len(media),'images':sum(x['Media_Type']=='Image' for x in media),'videos':sum(x['Media_Type']=='Video' for x in media),'glb_models':sum(x['Media_Type']=='3D' for x in media),'preview_images':sum(x['Media_Type']=='3D Preview' for x in media),'verified_sha256_count':len(actual),'errors':errors,'publishable_vessels':0,'product_records':data['catalogue_counts']['marine_products'],'service_records':data['catalogue_counts']['services'],'tier_terms_records':data['catalogue_counts']['tier_terms']}
out=r/'docs'/'phase618'/'asset_audit.json';out.parent.mkdir(parents=True,exist_ok=True);out.write_text(json.dumps(summary,indent=2))
print(json.dumps(summary,indent=2))
if errors:raise SystemExit(1)
