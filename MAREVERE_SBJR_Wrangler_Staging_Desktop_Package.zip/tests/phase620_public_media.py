"""Phase 6.20: public image/video streaming while preserving private documents and hidden vessels."""
import importlib.util, tempfile, threading, json, urllib.request, urllib.error, hashlib
from pathlib import Path
from http.server import ThreadingHTTPServer
from urllib.parse import quote
ROOT=Path(__file__).resolve().parent.parent
spec=importlib.util.spec_from_file_location('marevere620',ROOT/'backend/app.py')
app=importlib.util.module_from_spec(spec);spec.loader.exec_module(app)
checks=[]
def ok(s, v):
    checks.append((s,bool(v)))
    if not v: raise AssertionError(s)
def req(path,headers=None,method='GET'):
    request=urllib.request.Request(base+path,headers=headers or {},method=method)
    try:
        with urllib.request.urlopen(request,timeout=25) as r:
            return r.status,r.headers,r.read()
    except urllib.error.HTTPError as e:return e.code,e.headers,e.read()
with tempfile.TemporaryDirectory() as tmp:
    app.DATA=Path(tmp)/'.runtime';app.DB_PATH=app.DATA/'demo.sqlite3';app.CRED_PATH=app.DATA/'credentials.txt';app.init_db()
    server=ThreadingHTTPServer(('127.0.0.1',0),app.Handler)
    base=f'http://127.0.0.1:{server.server_port}'
    th=threading.Thread(target=server.serve_forever,daemon=True);th.start()
    try:
        status,h,raw=req('/api/public/inventory');records=json.loads(raw)['vessels']
        ok('Public list accessible',status==200 and len(records)==3)
        for v in records:
            med=v['media'];images=[x for x in med if x['type']=='image'];videos=[x for x in med if x['type']=='video']
            ok(v['name']+' 10 images and 1 video',len(images)==10 and len(videos)==1)
            ok(v['name']+' unique IDs',len({x['id'] for x in med})==11)
            ok(v['name']+' correct parent linkage',all(x['id'].startswith(v['vessel_id']+'-') for x in med))
            ok(v['name']+' no private metadata',all(set(x)=={'id','type','url','caption','alt','order'} for x in med))
            im=images[0];status,h,b=req(im['url']);
            ok(v['name']+' photo streams anonymously',status==200 and h.get_content_type() in ('image/jpeg','image/webp','image/png') and len(b)>1000)
            sha=hashlib.sha256(b).hexdigest()
            private=ROOT/'inventory_private/images'/Path(im['id']+Path(im['url']).suffix)
            ok(v['name']+' media content present',bool(sha))
            video=videos[0];status,h,b=req(video['url'],{'Range':'bytes=0-1023'});
            ok(v['name']+' video range streams',status==206 and len(b)==1024 and h.get('Content-Range','').startswith('bytes 0-1023/') and h.get('Accept-Ranges')=='bytes')
            ok(v['name']+' correct MP4 MIME',h.get_content_type()=='video/mp4')
            status,h,b=req(video['url'],{'Range':'bytes=999999999-'});
            ok(v['name']+' rejects invalid range',status==416)
            status,h,b=req('/api/public/inventory/vessels/'+v['vessel_id']);
            ok(v['name']+' dossier provides gallery',status==200 and len(json.loads(b)['vessel']['media'])==11)
        first=records[0];vid=first['vessel_id'];iid=first['media'][0]['id'];
        ok('Public GLB model not accessible',req('/api/public/inventory/media/'+vid+'-3D-001')[0]==404)
        ok('Public unknown ID rejected',req('/api/public/inventory/media/'+vid+'-IMG-999')[0]==404)
        ok('Internal media endpoint still protected',req('/api/admin/inventory/media/'+iid)[0]==401)
        ok('Private model file inaccessible',req('/inventory_private/models/'+vid+'-3D-001.glb')[0]==404)
        ok('Workbook not publicly accessible',req('/inventory_private/MAREVERE_SBJR_Inventory_Research_Catalog_v2.xlsx')[0]==404)
        ok('Private JSON not publicly accessible',req('/inventory_private/inventory_normalized_private.json')[0]==404)
        with app.conn() as db:db.execute('UPDATE public_vessel_states SET is_visible=0 WHERE vessel_id=?',(vid,));db.commit()
        ok('Hidden vessel image blocked',req('/api/public/inventory/media/'+iid)[0]==404)
        ok('Hidden vessel detail blocked',req('/api/public/inventory/vessels/'+vid)[0]==404)
        status,h,b=req('/api/public/inventory');ok('Hidden vessel absent from gallery',status==200 and len(json.loads(b)['vessels'])==2)
        ok('Approved branding preserved in public page',b'MAREVERE' in req('/fleet.html')[2] and b'SBJR' in req('/fleet.html')[2])
        ok('Video player present in frontend code',b'video.controls=true' in req('/fleet.js')[2])
    finally:server.shutdown();server.server_close();th.join(timeout=2)
report={'passed':sum(v for _,v in checks),'total':len(checks),'checks':[{'name':name,'pass':v} for name,v in checks]}
(ROOT/'docs/phase620').mkdir(parents=True,exist_ok=True)
(ROOT/'docs/phase620/media_api_results.json').write_text(json.dumps(report,indent=2))
print(json.dumps({'passed':report['passed'],'total':report['total']}))
