"""Local integration and role isolation smoke tests. Run against local server; no real accounts."""
import json
import os
from pathlib import Path
import re
import requests

BASE=os.environ.get('MAREVERE_TEST_URL','http://127.0.0.1:8765')
creds=(Path(__file__).parents[1]/'.runtime'/'demo_credentials.txt').read_text()
accounts={}
for line in creds.splitlines():
    m=re.match(r'(BUYER|SELLER|ADMIN)\s+(\S+)\s+PASSWORD: (\S+)',line)
    if m: accounts[m.group(1).lower()]=(m.group(2),m.group(3))
results=[]

def check(label, ok):
    results.append((label,bool(ok)))
    print(('PASS' if ok else 'FAIL')+' '+label)
    if not ok: raise AssertionError(label)

def client(role):
    s=requests.Session()
    session=s.get(BASE+'/api/session')
    check(f'{role} initial session CSRF issued',session.ok and bool(session.json()['csrf']))
    email,pwd=accounts[role]
    r=s.post(BASE+'/api/auth/login',json={'email':email,'password':pwd},headers={'Origin':BASE,'X-CSRF-Token':session.json()['csrf']})
    check(f'{role} sign in',r.ok)
    csrf=s.get(BASE+'/api/session').json()['csrf']
    return s,csrf

check('health says payments disabled',requests.get(BASE+'/api/health').json()['payments_enabled'] is False)
check('server refuses credential disclosure',requests.get(BASE+'/.runtime/demo_credentials.txt').status_code==404)
check('server refuses encoded credential disclosure',requests.get(BASE+'/%2Eruntime/demo_credentials.txt').status_code==404)
check('server refuses backend source disclosure',requests.get(BASE+'/backend/app.py').status_code==404)
check('public marketing homepage available',requests.get(BASE+'/index.html').status_code==200)
check('connected portal available',requests.get(BASE+'/integrated.html').status_code==200)
check('connected admin UI renders',requests.get(BASE+'/admin.html',allow_redirects=False).status_code==200)
check('unauthenticated admin API denied',requests.get(BASE+'/api/admin/reviews').status_code==401)
check('unauthenticated ticket API denied',requests.get(BASE+'/api/support/tickets').status_code==401)

buyer,bcsrf=client('buyer')
seller,scsrf=client('seller')
admin,ac=client('admin')
check('buyer cannot view admin queue',buyer.get(BASE+'/api/admin/reviews').status_code==403)
check('seller cannot view buyer saved list',seller.get(BASE+'/api/saved').status_code==403)
check('buyer cannot submit broker listings',buyer.post(BASE+'/api/seller/listings',json={'name':'Fake','description':'An illustrative listing','length_m':50},headers={'Origin':BASE,'X-CSRF-Token':bcsrf}).status_code==403)
check('wrong Origin rejected',buyer.post(BASE+'/api/saved',json={'slug':'solenne'},headers={'Origin':'http://evil.invalid','X-CSRF-Token':bcsrf}).status_code==403)
check('missing CSRF rejected',buyer.post(BASE+'/api/saved',json={'slug':'solenne'},headers={'Origin':BASE}).status_code==403)
r=buyer.post(BASE+'/api/saved',json={'slug':'solenne'},headers={'Origin':BASE,'X-CSRF-Token':bcsrf})
check('buyer saves yacht',r.status_code==200 and r.json()['saved'])
check('saved yacht persisted',len(buyer.get(BASE+'/api/saved').json()['saved'])==1)
check('negative scenario — unknown yacht rejected',buyer.post(BASE+'/api/saved',json={'slug':'invalid'},headers={'Origin':BASE,'X-CSRF-Token':bcsrf}).status_code==404)
r=buyer.post(BASE+'/api/support/tickets',json={'subject':'Acquisition plans','message':'Could I see the proposed contract conditions?'},headers={'Origin':BASE,'X-CSRF-Token':bcsrf})
check('buyer can file local support case',r.status_code==201)
check('admin sees buyer case',len(admin.get(BASE+'/api/support/tickets').json()['tickets'])>=1)
r=seller.post(BASE+'/api/seller/listings',json={'name':'Northstar — Demo','description':'A fictional vessel, not real inventory.','length_m':41},headers={'Origin':BASE,'X-CSRF-Token':scsrf})
check('seller submits pending listing',r.status_code==201)
listing_id=r.json()['id']
check('seller listing shows submitted',any(x['id']==listing_id and x['status']=='submitted' for x in seller.get(BASE+'/api/seller/listings').json()['listings']))
check('admin sees pending listing',any(x['id']==listing_id for x in admin.get(BASE+'/api/admin/reviews').json()['reviews']))
check('seller cannot approve listing',seller.post(BASE+f'/api/admin/reviews/{listing_id}/decision',json={'decision':'approved'},headers={'Origin':BASE,'X-CSRF-Token':scsrf}).status_code==403)
r=admin.post(BASE+f'/api/admin/reviews/{listing_id}/decision',json={'decision':'approved'},headers={'Origin':BASE,'X-CSRF-Token':ac})
check('admin can approve demo listing',r.status_code==200 and r.json()['status']=='approved')
check('double review blocked',admin.post(BASE+f'/api/admin/reviews/{listing_id}/decision',json={'decision':'approved'},headers={'Origin':BASE,'X-CSRF-Token':ac}).status_code==409)
check('approval is audited',any(x['event']=='LISTING_APPROVED' for x in admin.get(BASE+'/api/admin/audit').json()['events']))
check('cannot access payment endpoint',buyer.post(BASE+'/api/payments',json={'price':100},headers={'Origin':BASE,'X-CSRF-Token':bcsrf}).status_code==404)
check('seller cannot read audit',seller.get(BASE+'/api/admin/audit').status_code==403)
check('logout works',buyer.post(BASE+'/api/auth/logout',json={},headers={'Origin':BASE,'X-CSRF-Token':bcsrf}).status_code==200)
check('buyer session invalidated',buyer.get(BASE+'/api/saved').status_code==401)
result={'base':BASE,'passed':sum(v for _,v in results),'total':len(results),'results':[{'test':k,'pass':v} for k,v in results]}
out=Path(__file__).parents[1]/'docs'/'api_test_results.json'
out.write_text(json.dumps(result,indent=2))
print('WROTE',out)
