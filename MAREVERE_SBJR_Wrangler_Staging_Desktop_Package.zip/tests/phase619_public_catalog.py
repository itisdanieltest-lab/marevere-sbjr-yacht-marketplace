"""Phase 6.19 public vessel availability & private media / admin-only transitions."""
from __future__ import annotations
from pathlib import Path
import importlib.util, tempfile, threading, json, urllib.request, urllib.error, http.cookiejar, re
from http.server import ThreadingHTTPServer
ROOT=Path(__file__).resolve().parent.parent
spec=importlib.util.spec_from_file_location('localbackend',ROOT/'backend/app.py')
app=importlib.util.module_from_spec(spec);spec.loader.exec_module(app)
checks=[]
def ok(name,test):
    checks.append((name,bool(test)))
    if not test: raise AssertionError('FAILED: '+name)

def client():return urllib.request.build_opener(urllib.request.HTTPCookieProcessor(http.cookiejar.CookieJar()))
def request(op,path,method='GET',body=None,headers=None):
    h={'Content-Type':'application/json'} if body is not None else {}
    h.update(headers or {})
    rq=urllib.request.Request(BASE+path,data=json.dumps(body).encode('utf8') if body is not None else None,headers=h,method=method)
    try:
        with op.open(rq,timeout=12) as res:return res.status,res.headers,res.read()
    except urllib.error.HTTPError as e:return e.code,e.headers,e.read()
def api(*args,**kw):
    code,headers,raw=request(*args,**kw)
    try: body=json.loads(raw)
    except Exception:body=None
    return code,body,headers
with tempfile.TemporaryDirectory(prefix='marevere619-local-') as tmp:
    app.DATA=Path(tmp)/'.runtime';app.DB_PATH=app.DATA/'audit.sqlite3';app.CRED_PATH=app.DATA/'secrets.txt';app.init_db()
    passwords={}
    for line in app.CRED_PATH.read_text().splitlines():
        m=re.search(r'^(BUYER|SELLER|ADMIN)\s+\S+\s+PASSWORD: (.+)',line)
        if m:passwords[m.group(1).lower()]=m.group(2)
    server=ThreadingHTTPServer(('127.0.0.1',0),app.Handler);BASE=f'http://127.0.0.1:{server.server_port}'
    thread=threading.Thread(target=server.serve_forever,daemon=True);thread.start()
    try:
        anon,buyer,broker,admin=client(),client(),client(),client()
        def login(op,role):
            nonce=api(op,'/api/session')[1]['csrf']
            code,resp,_=api(op,'/api/auth/login','POST',{'email':('broker' if role=='seller' else role)+'@marevere.invalid','password':passwords[role]},{'Origin':BASE,'X-CSRF-Token':nonce})
            ok(role+' login',code==200)
            return api(op,'/api/session')[1]['csrf']
        buyerCsrf=login(buyer,'buyer');brokerCsrf=login(broker,'seller');adminCsrf=login(admin,'admin')
        code,data,_=api(anon,'/api/public/inventory');ok('public inventory no login',code==200)
        ok('3 workbook vessels public',len(data['vessels'])==3)
        ok('initial pending and sold',data['status_counts']=={'available':0,'pending':2,'sold':1,'out_of_stock':0})
        ok('public images and video mapped',all(sum(m['type']=='image' for m in x['media'])==10 and sum(m['type']=='video' for m in x['media'])==1 and x['media_public'] for x in data['vessels']))
        ok('no current price offers',all(not x['price_is_current_offer'] and not x['acquisition_enabled'] for x in data['vessels']))
        vid='MAREVERE-SBJR-MOTOR-YACHT-001'
        code,vessel,_=api(anon,'/api/public/inventory/vessels/'+vid);ok('public technical dossier',code==200 and vessel['vessel']['specifications']['Beam_m']==8.1)
        ok('public dossier no private workbook evidence',not any(x in str(vessel) for x in ['Data_Source_URL','Tech_Data_Source','Seller_ID','private_media_url','source notes']))
        code,records,_=api(anon,'/api/admin/inventory/statuses');ok('anonymous admin statuses denied',code==401)
        code,_,_=api(buyer,'/api/admin/inventory/statuses');ok('buyer admin statuses denied',code==403)
        code,_,_=api(broker,'/api/admin/inventory/statuses');ok('broker admin statuses denied',code==403)
        code,records,_=api(admin,'/api/admin/inventory/statuses');ok('admin controls read',code==200 and len(records['records'])==3)
        endpoint='/api/admin/inventory/statuses/'+vid
        payload={'status':'out_of_stock','visible':True,'availability_verified':False,'seller_authority_confirmed':False,
                 'evidence_reference':'','private_reason':'Awaiting confirmation from the owner'}
        hc={'Origin':BASE,'X-CSRF-Token':adminCsrf}
        code,_,_=api(anon,endpoint,'POST',payload,{'Origin':BASE});ok('anon update blocked',code==403)
        code,_,_=api(buyer,endpoint,'POST',payload,{'Origin':BASE,'X-CSRF-Token':buyerCsrf});ok('buyer status update blocked',code==403)
        code,_,_=api(broker,endpoint,'POST',payload,{'Origin':BASE,'X-CSRF-Token':brokerCsrf});ok('broker status update blocked',code==403)
        code,_,_=api(admin,endpoint,'POST',payload,{'Origin':BASE});ok('csrf required',code==403)
        code,_,_=api(admin,endpoint,'POST',dict(payload,status='available'),hc);ok('cannot declare available without verification',code==400)
        code,_,_=api(admin,endpoint,'POST',dict(payload,status='sold'),hc);ok('sold requires evidence',code==400)
        code,out,_=api(admin,endpoint,'POST',payload,hc);ok('admin marks out of stock',code==200 and out['status']=='out_of_stock')
        code,vis,_=api(anon,'/api/public/inventory');ok('public sees out of stock',code==200 and next(x for x in vis['vessels'] if x['vessel_id']==vid)['status']=='out_of_stock')
        code,_,_=api(admin,endpoint,'POST',dict(payload,status='pending'),hc);ok('admin marks pending',code==200)
        code,_,_=api(admin,endpoint,'POST',dict(payload,status='available',seller_authority_confirmed=True,availability_verified=True,evidence_reference='BROKER-VERIFY-2026'),hc);ok('admin confirms available with attestation',code==200)
        code,vis,_=api(anon,'/api/public/inventory');ok('public sees available',code==200 and vis['status_counts']['available']==1)
        code,vessel,_=api(anon,'/api/public/inventory/vessels/'+vid);ok('available media and no transactions',code==200 and len(vessel['vessel']['media'])==11 and not vessel['vessel']['price_is_current_offer'] and not vessel['vessel']['acquisition_enabled'])
        code,_,_=api(admin,endpoint,'POST',dict(payload,status='sold',evidence_reference='OWNER-SOLD-2026'),hc);ok('admin marks sold',code==200)
        code,_,_=api(admin,endpoint,'POST',dict(payload,status='pending',visible=False),hc);ok('admin hides public record',code==200)
        code,vis,_=api(anon,'/api/public/inventory');ok('hidden not in public index',code==200 and len(vis['vessels'])==2)
        code,_,_=api(anon,'/api/public/inventory/vessels/'+vid);ok('hidden detail 404',code==404)
        code,hist,_=api(admin,endpoint+'/history');ok('audit history saved',code==200 and len(hist['events'])==5)
        ok('reason recorded in audit log',hist['events'][0]['private_reason']=='Awaiting confirmation from the owner')
        app.init_db()
        code,vis,_=api(anon,'/api/public/inventory');ok('reimport preserves admin visibility',code==200 and len(vis['vessels'])==2)
        code,info,_=api(admin,'/api/admin/inventory/statuses');ok('reimport preserves current state',code==200 and next(x for x in info['records'] if x['vessel_id']==vid)['is_visible']==0)
        code,_,_=api(anon,'/api/admin/inventory/media/MAREVERE-SBJR-MOTOR-YACHT-001-IMG-001');ok('actual image protected',code==401)
        code,_,_=api(anon,'/inventory_private/MAREVERE_SBJR_Inventory_Research_Catalog_v2.xlsx');ok('direct workbook protected',code==404)
        code,_,_=api(anon,'/fleet.html');ok('public site page served',code==200)
        code,_,_=api(anon,'/fleet.js');ok('public JS served',code==200)
    finally:
        server.shutdown();server.server_close();thread.join(timeout=3)
report={'passed':sum(c for _,c in checks),'total':len(checks),'checks':[{'name':x,'pass':y} for x,y in checks]}
(ROOT/'docs'/'phase619').mkdir(parents=True,exist_ok=True)
(ROOT/'docs'/'phase619'/'api_results.json').write_text(json.dumps(report,indent=2))
print(json.dumps({'passed':report['passed'],'total':report['total']},indent=2))
