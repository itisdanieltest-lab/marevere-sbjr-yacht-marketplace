"""Local-only MAREVERE Phase 6.15 security-test prototype. NOT production-ready."""
from __future__ import annotations
import base64
from decimal import Decimal, InvalidOperation
import hashlib
import hmac
import json
import mimetypes
import os
from pathlib import Path
import re
import secrets
import sqlite3
import sys
import time
from http import HTTPStatus
from http.cookies import SimpleCookie
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlsplit, unquote

ROOT = Path(__file__).resolve().parent.parent
DATA = ROOT / '.runtime'
DB_PATH = DATA / 'marevere_demo.sqlite3'
CRED_PATH = DATA / 'demo_credentials.txt'
PRIVATE_INVENTORY = ROOT / 'inventory_private'
PBKDF_ITERATIONS = 320_000
MAX_BODY = 10_000
LOGIN_ATTEMPTS = {}  # Local demo guard; real deployments need distributed throttling.


def conn():
    db = sqlite3.connect(DB_PATH, timeout=10)
    db.row_factory = sqlite3.Row
    db.execute('PRAGMA foreign_keys=ON')
    db.execute('PRAGMA busy_timeout=10000')
    return db


def make_hash(password: str) -> str:
    salt = secrets.token_bytes(16)
    dig = hashlib.pbkdf2_hmac('sha256', password.encode(), salt, PBKDF_ITERATIONS)
    return 'pbkdf2_sha256$%s$%s$%s' % (PBKDF_ITERATIONS, salt.hex(), dig.hex())


def check_hash(password: str, stored: str) -> bool:
    try:
        algo, iters, salt, value = stored.split('$')
        if algo != 'pbkdf2_sha256' or int(iters) > 1_000_000: return False
        proposed = hashlib.pbkdf2_hmac('sha256', password.encode(), bytes.fromhex(salt), int(iters))
        return hmac.compare_digest(proposed, bytes.fromhex(value))
    except (ValueError, TypeError):
        return False


def synchronize_research_inventory(db):
    """Import private workbook facts; publish a sanitized vessel and image/video view."""
    archive=PRIVATE_INVENTORY/'inventory_normalized_private.json'
    if not archive.is_file():
        return
    body=json.loads(archive.read_text(encoding='utf-8'))
    digest=body['workbook_sha256']
    for rec in body['records']:
        master=rec['master']
        vessel_id=rec['vessel_id']
        db.execute("""INSERT INTO research_vessels
        (vessel_id,name,category,status_text,data_json,workbook_sha256)
        VALUES(?,?,?,?,?,?) ON CONFLICT(vessel_id) DO UPDATE SET
        name=excluded.name,category=excluded.category,status_text=excluded.status_text,
        data_json=excluded.data_json,workbook_sha256=excluded.workbook_sha256,imported_at=CURRENT_TIMESTAMP""",
        (vessel_id,str(master.get('Display_Title') or ''),str(master.get('Primary_Category') or ''),
        str(master.get('Listing_Status') or ''),json.dumps(rec,ensure_ascii=False),digest))
        for item in rec['media']:
            relative=str(item.get('File_Name_or_URL') or '')
            prefix=relative.split('/',1)[0]
            # Checked at import, but file route also verifies containment.
            if prefix not in ('images','videos','models','previews') or not (PRIVATE_INVENTORY/relative).is_file():
                raise ValueError('Inventory media missing or outside allowed directories: '+relative)
            db.execute("""INSERT INTO research_media(media_id,vessel_id,media_type,relative_path,rights_status,sort_order)
            VALUES(?,?,?,?,?,?) ON CONFLICT(media_id) DO UPDATE SET
            vessel_id=excluded.vessel_id,media_type=excluded.media_type,
            relative_path=excluded.relative_path,rights_status=excluded.rights_status,sort_order=excluded.sort_order""",
            (str(item['Media_ID']),vessel_id,str(item.get('Media_Type') or ''),relative,
            str(item.get('Usage_Rights') or ''),int(item.get('Sort_Order') or 0)))


# Public status is intentionally independent of the unmodified imported workbook.
VALID_VESSEL_STATES=('available','pending','sold','out_of_stock')
PUBLIC_MASTER_KEYS=('Builder','Model','Build_Year','Primary_Category','Style_Subtype',
 'Length_m','Cabins','Location_Country','Condition','Currency','Short_Summary',
 'Full_Description','Key_Features')
PUBLIC_TECH_KEYS=('Beam_m','Draft_m','Hull_Material','Hull_Type','Propulsion',
 'Engines_Make_Model','Engines_Count','Total_Power_kW','Cruise_Speed_kn',
 'Max_Speed_kn','Range_nm','Gross_Tonnage','Guest_Capacity','Crew_Capacity',
 'Year_Refit','Flag','Fuel_Capacity_L','Fresh_Water_L','Bathrooms','Berths')

def reconcile_public_vessel_states(db):
    for row in db.execute('SELECT vessel_id,status_text FROM research_vessels').fetchall():
        initial='sold' if 'Historical record' in row['status_text'] else 'pending'
        db.execute('''INSERT OR IGNORE INTO public_vessel_states(vessel_id,status,is_visible)
                      VALUES(?,?,1)''',(row['vessel_id'],initial))

def public_media_metadata(facts):
    """Only vessel-specific image/video IDs are public. No source notes, licenses, or models."""
    allowed={'Image':'image','Video':'video'}
    result=[]
    for entry in facts.get('media',[]):
        kind=allowed.get(entry.get('Media_Type'))
        if not kind:continue
        media_id=entry.get('Media_ID','')
        if not re.fullmatch(r'MAREVERE-SBJR-[A-Z0-9-]+-(?:IMG|VID)-\d{3}',media_id):continue
        result.append({'id':media_id,'type':kind,
            'url':'/api/public/inventory/media/'+media_id,
            'caption':str(entry.get('Caption') or '')[:300],
            'alt':str(entry.get('Accessible_Alt_Text') or 'Vessel '+kind)[:300],
            'order':int(entry.get('Sort_Order') or 0)})
    return sorted(result,key=lambda x:x['order'])


def public_vessel_payload(row, include_specs=False):
    facts=json.loads(row['data_json'])
    source=facts['master'];tech=facts['technical']
    state=row['public_status']; visible=bool(row['is_visible'])
    item={'vessel_id':row['vessel_id'],'name':row['name'],'category':row['category'],
          'status':state,'visible':visible,'year':source.get('Build_Year'),
          'builder':source.get('Builder'),'length_m':source.get('Length_m'),
          'summary':source.get('Short_Summary'),
          'reference_price_eur':source.get('Asking_Price'),
          'price_is_current_offer':False,'currency':source.get('Currency') or 'EUR',
          'media_public':True,'media':public_media_metadata(facts), 'acquisition_enabled':False,
          'listing_id':row['vessel_id'], 'updated_at':row['state_updated_at'],
          'public_note':row['public_note']}
    if include_specs:
        item['master']={key:source.get(key) for key in PUBLIC_MASTER_KEYS}
        item['specifications']={key:tech.get(key) for key in PUBLIC_TECH_KEYS}
        item['disclosure']='Workbook research information. Vessel photographs and listing videos are shown as instructed by the project owner; underlying photographer, broker and video redistribution permissions have not been verified. 3D studies remain internal. Availability and prices are not verified offers.'
    return item

def parse_cents(value):
    try:
        d=Decimal(str(value))
        if not d.is_finite() or d<=0 or d>Decimal('1000000000') or d.as_tuple().exponent < -2:
            return None
        return int(d*100)
    except (InvalidOperation,ValueError,TypeError):
        return None


def inventory_media_url(media_id):
    return '/api/admin/inventory/media/'+media_id


def research_row(row):
    data=json.loads(row['data_json'])
    master=data['master']
    media=data['media']
    hero=next((x for x in media if x.get('Hero_Asset')=='Yes' and x.get('Media_Type')=='Image'),None)
    return {
        'vessel_id':row['vessel_id'], 'name':row['name'], 'category':row['category'],
        'status':row['status_text'], 'builder':master.get('Builder'),
        'year':master.get('Build_Year'), 'length_m':master.get('Length_m'),
        'price_eur_historical_or_unverified':master.get('Asking_Price'),
        'hero':inventory_media_url(hero['Media_ID']) if hero else None,
        'media_count':len(media), 'can_publish':False
    }


def media_file(handler, source, download=False):
    """Protected media streaming with single-range requests for HTML5 video."""
    size=source.stat().st_size
    start=0;end=size-1;status=200
    requested=handler.headers.get('Range','') if not download else ''
    if requested:
        match=re.fullmatch(r'bytes=(\d*)-(\d*)',requested)
        if not match or not (match.group(1) or match.group(2)):
            handler.send_response(416);handler.send_header('Content-Range',f'bytes */{size}');handler.end_headers();return
        if match.group(1):
            start=int(match.group(1)); end=min(size-1,int(match.group(2))) if match.group(2) else size-1
        else:
            length=int(match.group(2));start=max(0,size-length)
        if start>=size or end<start:
            handler.send_response(416);handler.send_header('Content-Range',f'bytes */{size}');handler.end_headers();return
        status=206
    handler.send_response(status)
    handler.send_header('Content-Type',mimetypes.guess_type(source.name)[0] or 'application/octet-stream')
    handler.send_header('Content-Length',str(end-start+1))
    handler.send_header('Accept-Ranges','bytes')
    handler.send_header('Cross-Origin-Resource-Policy','same-origin')
    if status==206:handler.send_header('Content-Range',f'bytes {start}-{end}/{size}')
    if download:handler.send_header('Content-Disposition','attachment; filename="'+source.name.replace('"','')+'"')
    handler.end_headers()
    with source.open('rb') as f:
        f.seek(start);remaining=end-start+1
        while remaining:
            part=f.read(min(512*1024,remaining))
            if not part:break
            try:handler.wfile.write(part)
            except (ConnectionResetError,BrokenPipeError):break
            remaining-=len(part)


def init_db():
    DATA.mkdir(exist_ok=True, mode=0o700)
    with conn() as db:
        db.executescript((ROOT / 'migrations/0001_init.sql').read_text())
        db.executescript((ROOT / 'migrations/0002_marine_cart.sql').read_text())
        db.executescript((ROOT / 'migrations/0003_security.sql').read_text())
        db.executescript((ROOT / 'migrations/0004_research_inventory_manual_payments.sql').read_text())
        synchronize_research_inventory(db)
        db.executescript((ROOT / 'migrations/0005_public_catalog_status.sql').read_text())
        reconcile_public_vessel_states(db)
        db.executemany('INSERT OR IGNORE INTO marine_products(id,name,category,price_eur) VALUES(?,?,?,?)',[
            ('meridian','Meridian 12','Electronics',2490),('teak','Teak Lounge','Interiors',1480),
            ('beacon','Coastal Beacon','Safety & care',380),('compass','Latitude Compass','Electronics',415),
            ('fender','Harbor Fender','Deck & docking',195),('light','Aster Deck Light','Deck & docking',620),
            ('ladder','Aftline Ladder','Deck & docking',860),('kit','Vessel Care Kit','Safety & care',129)])
        if db.execute('SELECT count(*) FROM users').fetchone()[0]: return
        records = [('buyer@marevere.invalid', 'buyer', 'Alex Morgan'),
                   ('broker@marevere.invalid', 'seller', 'Avery Lane'),
                   ('admin@marevere.invalid', 'admin', 'Operations Administrator')]
        lines = ['LOCAL FICTIONAL DEMO ACCOUNTS — DO NOT DEPLOY OR SHARE PUBLICLY', '']
        for email, role, name in records:
            pwd = secrets.token_urlsafe(18)
            db.execute('INSERT INTO users(email,password_hash,role,display_name) VALUES(?,?,?,?)',
                       (email,make_hash(pwd),role,name))
            lines += [f'{role.upper():7} {email}  PASSWORD: {pwd}']
        vessels = [
            ('solenne','Solenne','Superyacht',68,'Illustrative 68m yacht concept; not a verified listing.'),
            ('aureline','Aureline','Motor yacht',42,'Illustrative motor yacht concept; no approved offer.'),
            ('vela','Vela','Sailing yacht',31,'Illustrative sailing yacht concept; no approved offer.'),
            ('maris','Maris','Catamaran',25,'Illustrative catamaran concept; no approved offer.'),
            ('orion','Orion','Explorer',54,'Illustrative explorer yacht concept; no approved offer.'),
            ('tide','Tide','Day cruiser',18,'Illustrative day cruiser concept; no approved offer.')]
        db.executemany('INSERT INTO vessels(slug,name,type,length_m,summary) VALUES(?,?,?,?,?)',vessels)
        seller_id = db.execute("SELECT id FROM users WHERE role='seller'").fetchone()['id']
        db.execute("INSERT INTO listings(seller_id,name,description,length_m,status) VALUES(?,?,?,?,?)",
                   (seller_id,'Aureline 42 — demonstration','Fictional broker listing awaiting review.',42,'submitted'))
    CRED_PATH.write_text('\n'.join(lines)+'\n',encoding='utf-8')
    os.chmod(CRED_PATH,0o600)


def issue_demo_reset(email: str) -> str:
    """LOCAL DEVELOPER TERMINAL ONLY; never exposed through an HTTP route."""
    if not re.fullmatch(r'[a-z0-9][a-z0-9._+-]{0,60}@marevere\.invalid', email):
        raise SystemExit('Only fictional @marevere.invalid addresses can use local recovery.')
    with conn() as db:
        row = db.execute('SELECT id FROM users WHERE email=?', (email,)).fetchone()
        if not row:
            raise SystemExit('Fictional account not found. No token was issued.')
        token = secrets.token_urlsafe(40)
        digest = hashlib.sha256(token.encode('ascii')).hexdigest()
        db.execute('DELETE FROM password_reset_tokens WHERE user_id=?', (row['id'],))
        db.execute('DELETE FROM password_reset_tokens WHERE expires_at<=?', (int(time.time()),))
        db.execute('INSERT INTO password_reset_tokens(token_hash,user_id,expires_at) VALUES(?,?,?)',
                   (digest,row['id'],int(time.time()) + 10*60))
        db.commit()
    return token


class Handler(SimpleHTTPRequestHandler):
    server_version = 'MAREVERE-LocalDemo'
    sys_version = ''

    def valid_host(self):
        # Explicit protection against DNS rebinding on a localhost-only demo.
        host = self.headers.get('Host', '')
        if not host or any(x in host for x in ('@','/','\\',' ', '\t', '\r', '\n')):
            return False
        try:
            parsed = urlsplit('http://' + host)
            return parsed.hostname in ('localhost','127.0.0.1','::1') and parsed.port == self.server.server_port
        except ValueError:
            return False
    def __init__(self, *args, **kwargs):
        super().__init__(*args, directory=str(ROOT), **kwargs)

    def list_directory(self,path):
        self.err(404,'Not found')
        return None

    def log_message(self, format, *args):
        # Avoid logging cookies, query strings or submitted form bodies.
        print('[LOCAL DEMO]',format % args, file=sys.stderr)

    def end_headers(self):
        self.send_header('X-Content-Type-Options','nosniff')
        self.send_header('Referrer-Policy','same-origin')
        self.send_header('X-Frame-Options','DENY')
        self.send_header('Cache-Control','no-store')
        # Legacy showroom requires a tiny inline importmap; restrict this exception
        # to that page. The authenticated integration interface has no inline JS.
        legacy_map=urlsplit(self.path).path in ('/showroom.html','/inventory-model.html')
        script_policy="'self' 'unsafe-inline' https://cdn.jsdelivr.net https://unpkg.com" if legacy_map else "'self' https://cdn.jsdelivr.net https://unpkg.com"
        self.send_header('Content-Security-Policy',f"default-src 'self' https://fonts.googleapis.com https://fonts.gstatic.com https://cdn.jsdelivr.net https://unpkg.com; script-src {script_policy}; style-src 'self' 'unsafe-inline' https://fonts.googleapis.com; img-src 'self' data:; media-src 'self'; connect-src 'self'; font-src 'self' data: https://fonts.gstatic.com; object-src 'none'; base-uri 'self'; frame-ancestors 'none'")
        super().end_headers()

    def send_json(self, obj, code=200, cookie=None):
        payload=json.dumps(obj, ensure_ascii=False).encode('utf-8')
        self.send_response(code)
        self.send_header('Content-Type','application/json; charset=utf-8')
        self.send_header('Content-Length',str(len(payload)))
        if cookie: self.send_header('Set-Cookie',cookie)
        self.end_headers()
        self.wfile.write(payload)

    def err(self, code, msg):
        self.send_json({'error':msg},code)

    def cookie_token(self):
        c=SimpleCookie()
        try: c.load(self.headers.get('Cookie',''))
        except Exception: return None
        return c.get('mv_session').value if c.get('mv_session') else None

    def current(self, db):
        t=self.cookie_token()
        if not t: return None
        hashed=hashlib.sha256(t.encode()).hexdigest()
        row=db.execute('''SELECT users.id,users.email,users.display_name,users.role,sessions.csrf,sessions.expires_at
              FROM sessions JOIN users ON users.id=sessions.user_id
              WHERE sessions.token_hash=?''',(hashed,)).fetchone()
        return row if row and row['expires_at'] > int(time.time()) else None

    def init_csrf(self):
        c=SimpleCookie()
        try: c.load(self.headers.get('Cookie',''))
        except Exception: c=SimpleCookie()
        existing=c.get('mv_anon_csrf')
        if existing and re.fullmatch(r'[A-Za-z0-9_-]{24,100}',existing.value): return existing.value, None
        csrf=secrets.token_urlsafe(32)
        return csrf, f'mv_anon_csrf={csrf}; Path=/; SameSite=Strict; HttpOnly'

    def same_origin(self):
        origin=self.headers.get('Origin')
        host=self.headers.get('Host','')
        expected='http://' + host
        return (origin == expected) if origin else (self.headers.get('Referer','').startswith(expected+'/'))

    def verify_csrf(self,user):
        header=self.headers.get('X-CSRF-Token','')
        if user: return hmac.compare_digest(header,user['csrf'])
        cookie,_=self.init_csrf()
        return bool(header) and hmac.compare_digest(header,cookie)

    def read_json(self):
        try: length=int(self.headers.get('Content-Length','0'))
        except ValueError: return None
        if length < 1 or length > MAX_BODY: return None
        if 'application/json' not in self.headers.get('Content-Type',''): return None
        try:
            value=json.loads(self.rfile.read(length))
            return value if isinstance(value,dict) else None
        except (ValueError,UnicodeDecodeError): return None

    def allow(self,user,*roles):
        if not user: self.err(401,'Sign in required'); return False
        if roles and user['role'] not in roles: self.err(403,'Not authorized for this action'); return False
        return True

    def do_HEAD(self):
        # Security hardening: SimpleHTTPRequestHandler.do_HEAD bypasses our
        # do_GET static allowlist, so it could disclose metadata for .runtime
        # and restricted developer files. Disable HEAD for the local demo.
        if not self.valid_host():
            return self.err(400, 'Invalid local host')
        self.send_response(405)
        self.send_header('Allow', 'GET, POST')
        self.end_headers()

    def do_GET(self):
        if not self.valid_host(): return self.err(400,'Invalid local host')
        path=urlsplit(self.path).path
        if path.startswith('/api/'):
            with conn() as db:
                user=self.current(db)
                if path=='/api/health': return self.send_json({'status':'ok','mode':'LOCAL_DEMO','payments_enabled':False})
                if path=='/api/auth/recovery/info':
                    return self.send_json({'mode':'LOCAL_DEMO','email_delivery':False,'token_delivery':'local developer CLI only','expiry_minutes':10})
                if path=='/api/session':
                    csrf,cookie=self.init_csrf()
                    if user: return self.send_json({'user':dict(id=user['id'],role=user['role'],name=user['display_name'],email=user['email']), 'csrf':user['csrf'], 'mode':'FICTIONAL_DATA'}, cookie=cookie)
                    return self.send_json({'user':None,'csrf':csrf,'mode':'FICTIONAL_DATA'},cookie=cookie)
                if path=='/api/public/inventory':
                    rows=db.execute('''SELECT v.*,s.status AS public_status,s.is_visible,s.public_note,s.updated_at AS state_updated_at
                        FROM research_vessels v JOIN public_vessel_states s ON s.vessel_id=v.vessel_id
                        WHERE s.is_visible=1 ORDER BY CASE s.status WHEN 'available' THEN 0
                        WHEN 'pending' THEN 1 WHEN 'out_of_stock' THEN 2 ELSE 3 END, v.name''').fetchall()
                    items=[public_vessel_payload(x) for x in rows]
                    return self.send_json({'vessels':items,'total':len(items),
                      'status_counts':{t:sum(x['status']==t for x in items) for t in VALID_VESSEL_STATES},
                      'all_payments_disabled':True,'media_rights_unverified':True,
                      'notice':'Public research records and vessel-specific photographs/videos, with admin-managed availability. Media license documentation pending. No payments, deposits or acquisition contracts.'})
                m=re.fullmatch(r'/api/public/inventory/vessels/(MAREVERE-SBJR-[A-Z0-9-]+)',path)
                if m:
                    row=db.execute('''SELECT v.*,s.status AS public_status,s.is_visible,s.public_note,s.updated_at AS state_updated_at
                        FROM research_vessels v JOIN public_vessel_states s ON v.vessel_id=s.vessel_id
                        WHERE v.vessel_id=? AND s.is_visible=1''',(m.group(1),)).fetchone()
                    if not row:return self.err(404,'Public record unavailable')
                    return self.send_json({'vessel':public_vessel_payload(row,True),
                                          'transaction_enabled':False})
                m=re.fullmatch(r'/api/public/inventory/media/(MAREVERE-SBJR-[A-Z0-9-]+)',path)
                if m:
                    # No login required, but only images/videos attached to VISIBLE vessels.
                    # Explicit type allowlist prevents GLB, workbook, evidence and private note disclosure.
                    item=db.execute('''SELECT m.relative_path,m.media_type FROM research_media m
                        JOIN public_vessel_states s ON s.vessel_id=m.vessel_id
                        WHERE m.media_id=? AND s.is_visible=1''',(m.group(1),)).fetchone()
                    if not item or item['media_type'] not in ('Image','Video'):
                        return self.err(404,'Public vessel media unavailable')
                    relative=Path(item['relative_path'])
                    expected_dir='images' if item['media_type']=='Image' else 'videos'
                    expected_ext=('.webp','.jpg','.jpeg','.png') if expected_dir=='images' else ('.mp4','.webm')
                    if len(relative.parts)!=2 or relative.parts[0]!=expected_dir or relative.suffix.lower() not in expected_ext:
                        return self.err(404,'Public vessel media unavailable')
                    source=(PRIVATE_INVENTORY/relative).resolve()
                    if not source.is_relative_to((PRIVATE_INVENTORY/expected_dir).resolve()) or not source.is_file():
                        return self.err(404,'Public vessel media missing')
                    return media_file(self,source)
                if path=='/api/admin/inventory/statuses':
                    if not self.allow(user,'admin'):return
                    rows=db.execute('''SELECT v.vessel_id,v.name,v.category,s.status,s.is_visible,
                        s.availability_verified,s.seller_authority_confirmed,s.evidence_reference,
                        s.public_note,s.updated_at FROM research_vessels v JOIN public_vessel_states s
                        ON s.vessel_id=v.vessel_id ORDER BY v.name''').fetchall()
                    return self.send_json({'records':[dict(r) for r in rows],
                        'statuses':list(VALID_VESSEL_STATES), 'online_payments':False})
                m=re.fullmatch(r'/api/admin/inventory/statuses/(MAREVERE-SBJR-[A-Z0-9-]+)/history',path)
                if m:
                    if not self.allow(user,'admin'):return
                    items=db.execute('''SELECT old_status,new_status,old_visible,new_visible,
                        evidence_reference,private_reason,created_at,actor_id
                        FROM public_vessel_status_events WHERE vessel_id=? ORDER BY id DESC LIMIT 60''',(m.group(1),))
                    return self.send_json({'events':[dict(x) for x in items]})
                if path=='/api/public/listings':
                    rows=db.execute("SELECT id,name,description,length_m FROM listings WHERE status='approved' ORDER BY id DESC LIMIT 25")
                    return self.send_json({'listings':[dict(x) for x in rows], 'notice':'Fictional demo-approved concepts only; not published yacht inventory.'})
                if path=='/api/research/vessels':
                    # Explicitly NON-TRANSACTIONAL, limited factual research display.
                    # Photos, videos, CAD, private evidence and seller information never leave admin routes.
                    records=[]
                    for entry in db.execute('SELECT * FROM research_vessels ORDER BY category,name'):
                        item=json.loads(entry['data_json']);v=item['master'];t=item['technical']
                        fields=('Builder','Model','Build_Year','Primary_Category','Style_Subtype',
                                'Length_m','Cabins','Location_Country','Location_Port','Condition',
                                'Short_Summary','Full_Description','Key_Features','Price_Display',
                                'Availability','Listing_Status')
                        tech_fields=('Beam_m','Draft_m','Hull_Material','Hull_Type','Propulsion',
                                     'Engines_Make_Model','Engines_Count','Total_Power_kW',
                                     'Cruise_Speed_kn','Max_Speed_kn','Range_nm','Gross_Tonnage',
                                     'Guest_Capacity','Crew_Capacity','Year_Refit')
                        status='historical_sold' if 'Historical' in entry['status_text'] else ('verification_hold' if 'hold' in entry['status_text'] else 'research_unverified')
                        records.append({'vessel_id':entry['vessel_id'],'name':entry['name'],
                            'status':status,'is_active_offer':False,'seller_authorized':False,
                            'media_cleared':False,'master':{f:v.get(f) for f in fields},
                            'specifications':{f:t.get(f) for f in tech_fields},
                            'asking_price_eur_snapshot':v.get('Asking_Price')})
                    return self.send_json({'records':records,'real_inventory_for_sale':0,
                         'notice':'RESEARCH REFERENCE ONLY. Sale status, permission and prices are not verified. No enquiries or payments accepted for these vessels.'})
                if path=='/api/admin/inventory/vessels':
                    if not self.allow(user,'admin'): return
                    rows=db.execute('SELECT * FROM research_vessels ORDER BY category,name').fetchall()
                    return self.send_json({'records':[research_row(x) for x in rows],
                        'workbook_count':len(rows),'publicly_approved':0,
                        'warning':'Public workbook reference catalogue is visible. Seller authority, media rights, actual sale offers and contracts remain unverified.'})
                m=re.fullmatch(r'/api/admin/inventory/vessels/(MAREVERE-SBJR-[A-Z0-9-]+)',path)
                if m:
                    if not self.allow(user,'admin'): return
                    row=db.execute('SELECT * FROM research_vessels WHERE vessel_id=?',(m.group(1),)).fetchone()
                    if not row:return self.err(404,'Unknown research vessel')
                    detail=json.loads(row['data_json'])
                    for item in detail['media']:
                        item['private_media_url']=inventory_media_url(item['Media_ID'])
                    return self.send_json({'record':detail,'publicly_approved':False,
                        'notice':'Workbook source dossier for administrator review. Images and videos are also published through the visitor media route; 3D and private evidence remain restricted.'})
                m=re.fullmatch(r'/api/admin/inventory/media/(MAREVERE-SBJR-[A-Z0-9-]+)',path)
                if m:
                    if not self.allow(user,'admin'): return
                    item=db.execute('SELECT relative_path FROM research_media WHERE media_id=?',(m.group(1),)).fetchone()
                    if not item:return self.err(404,'Unknown research media')
                    path_on_disk=(PRIVATE_INVENTORY/item['relative_path']).resolve()
                    if not path_on_disk.is_relative_to(PRIVATE_INVENTORY.resolve()) or not path_on_disk.is_file():
                        return self.err(404,'Media unavailable')
                    return media_file(self,path_on_disk)
                if path=='/api/admin/inventory/workbook':
                    if not self.allow(user,'admin'): return
                    source=PRIVATE_INVENTORY/'MAREVERE_SBJR_Inventory_Research_Catalog_v2.xlsx'
                    return media_file(self,source,download=True)
                if path=='/api/admin/inventory/manual-payments':
                    if not self.allow(user,'admin'):return
                    rows=db.execute('''SELECT p.*,v.name AS vessel_name FROM manual_payment_cases p
                                     JOIN research_vessels v ON v.vessel_id=p.vessel_id ORDER BY p.id DESC''')
                    return self.send_json({'payments':[dict(x) for x in rows],
                        'notice':'Local-only manual status register. No funds accepted, no receipt issued, no ownership transfer.'})
                m=re.fullmatch(r'/api/admin/inventory/manual-payments/(\d+)/history',path)
                if m:
                    if not self.allow(user,'admin'):return
                    items=db.execute('SELECT * FROM manual_payment_events WHERE case_id=? ORDER BY id DESC',(int(m.group(1)),))
                    return self.send_json({'events':[dict(x) for x in items]})
                if path=='/api/products':
                    rows=db.execute('SELECT id,name,category,price_eur FROM marine_products ORDER BY id')
                    return self.send_json({'products':[dict(x) for x in rows], 'currency':'EUR','disclaimer':'Illustrative prices and products. No checkout.'})
                if path=='/api/cart':
                    if not self.allow(user,'buyer'): return
                    rows=db.execute('''SELECT c.product_id, p.name, c.quantity, p.price_eur
                        FROM marine_cart c JOIN marine_products p ON p.id=c.product_id
                        WHERE c.buyer_id=? ORDER BY p.name''',(user['id'],))
                    items=[dict(x) for x in rows]
                    return self.send_json({'items':items,'total_eur':sum(x['quantity']*x['price_eur'] for x in items),'checkout_enabled':False})
                if path=='/api/vessels':
                    return self.send_json({'vessels':[dict(x) for x in db.execute('SELECT id,slug,name,type,length_m,summary FROM vessels ORDER BY id')], 'disclaimer':'Fictional vessels; no purchase functionality.'})
                if path=='/api/saved':
                    if not self.allow(user,'buyer'): return
                    rows=db.execute('SELECT vessels.slug,vessels.name,vessels.type FROM saved JOIN vessels ON vessels.id=saved.vessel_id WHERE saved.user_id=?',(user['id'],))
                    return self.send_json({'saved':[dict(x) for x in rows]})
                if path=='/api/support/tickets':
                    if not self.allow(user,'buyer','admin'): return
                    rows=(db.execute('SELECT id,subject,message,status,created_at FROM support_tickets WHERE buyer_id=? ORDER BY id DESC',(user['id'],)) if user['role']=='buyer' else
                          db.execute('SELECT t.id,t.subject,t.message,t.status,t.created_at,u.display_name AS buyer FROM support_tickets t JOIN users u ON u.id=t.buyer_id ORDER BY t.id DESC'))
                    return self.send_json({'tickets':[dict(x) for x in rows]})
                if path=='/api/seller/listings':
                    if not self.allow(user,'seller'): return
                    rows=db.execute('SELECT id,name,description,length_m,status,created_at FROM listings WHERE seller_id=? ORDER BY id DESC',(user['id'],))
                    return self.send_json({'listings':[dict(x) for x in rows]})
                if path=='/api/admin/reviews':
                    if not self.allow(user,'admin'): return
                    rows=db.execute('''SELECT l.id,l.name,l.description,l.length_m,l.status,l.created_at,u.display_name AS seller
                        FROM listings l JOIN users u ON u.id=l.seller_id WHERE l.status IN ('submitted','approved','rejected') ORDER BY l.id DESC''')
                    return self.send_json({'reviews':[dict(x) for x in rows]})
                if path=='/api/admin/audit':
                    if not self.allow(user,'admin'): return
                    rows=db.execute('SELECT event,resource,created_at FROM audit_events ORDER BY id DESC LIMIT 35')
                    return self.send_json({'events':[dict(x) for x in rows]})
                return self.err(404,'Unknown API endpoint')
        # Only explicitly supported public file classes are served. Prevent encoded
        # dotfile/secret access and directory browsing while preserving site assets.
        clean=unquote(path)
        parts=Path(clean.lstrip('/')).parts
        if any(p.startswith('.') or p in ('..','') for p in parts):
            return self.err(404,'Not found')
        if clean in ('/admin-access.html','/seller-access.html'):
            # Historical unprotected visual mockups stay in the source archive,
            # but visitors on the connected local server enter the RBAC demo.
            self.send_response(302)
            self.send_header('Location','/integrated.html')
            self.end_headers()
            return
        if clean=='/': self.path='/index.html'; return super().do_GET()
        allowed={'.html','.css','.js','.webp','.png','.jpg','.jpeg','.svg','.glb','.gltf','.mp4','.webm','.woff2','.ico'}
        if Path(clean).suffix.lower() not in allowed or parts[0] in ('backend','migrations','tests','docs','qa_community','qa_admin','qa_member','qa_marine','qa_seller','design_archive','inventory_private','inventory_research'):
            return self.err(404,'Not found')
        return super().do_GET()

    def do_POST(self):
        if not self.valid_host(): return self.err(400,'Invalid local host')
        path=urlsplit(self.path).path
        if not path.startswith('/api/'): return self.err(404,'Unknown endpoint')
        if not self.same_origin(): return self.err(403,'Origin check failed')
        with conn() as db:
            user=self.current(db)
            if not self.verify_csrf(user): return self.err(403,'CSRF validation failed')
            data=self.read_json()
            if data is None: return self.err(400,'Invalid JSON payload')
            m=re.fullmatch(r'/api/admin/inventory/statuses/(MAREVERE-SBJR-[A-Z0-9-]+)',path)
            if m:
                if not self.allow(user,'admin'):return
                vessel_id=m.group(1)
                new=data.get('status')
                visible=data.get('visible')
                evidence=data.get('evidence_reference','')
                reason=data.get('private_reason','')
                public_note=data.get('public_note','')
                verified=data.get('availability_verified',False)
                authorized=data.get('seller_authority_confirmed',False)
                if (new not in VALID_VESSEL_STATES or type(visible) is not bool or
                    type(evidence) is not str or len(evidence)>140 or
                    type(reason) is not str or len(reason.strip())<12 or len(reason)>900 or
                    type(public_note) is not str or len(public_note)>180 or
                    type(verified) is not bool or type(authorized) is not bool):
                    return self.err(400,'Valid status, visibility and a reason of at least 12 characters required')
                if new=='available' and (not verified or not authorized or len(evidence.strip())<8):
                    return self.err(400,'Available requires confirmed seller authority, availability and an evidence reference')
                if new=='sold' and len(evidence.strip())<6:
                    return self.err(400,'Sold requires supporting evidence reference')
                row=db.execute('SELECT * FROM public_vessel_states WHERE vessel_id=?',(vessel_id,)).fetchone()
                if row is None:return self.err(404,'Unknown inventory vessel')
                db.execute('''UPDATE public_vessel_states SET status=?,is_visible=?,availability_verified=?,
                    seller_authority_confirmed=?,evidence_reference=?,public_note=?,updated_by=?,
                    updated_at=CURRENT_TIMESTAMP WHERE vessel_id=?''',
                    (new,int(visible),int(verified),int(authorized),evidence.strip(),public_note.strip(),user['id'],vessel_id))
                db.execute('''INSERT INTO public_vessel_status_events(vessel_id,actor_id,old_status,new_status,
                    old_visible,new_visible,evidence_reference,private_reason)
                    VALUES(?,?,?,?,?,?,?,?)''',
                    (vessel_id,user['id'],row['status'],new,row['is_visible'],int(visible),evidence.strip(),reason.strip()))
                db.execute('INSERT INTO audit_events(actor_id,event,resource) VALUES(?,?,?)',
                           (user['id'],'INVENTORY_STATUS_CHANGE',vessel_id+':'+new))
                db.commit()
                return self.send_json({'ok':True,'vessel_id':vessel_id,'status':new,
                    'visible':visible,'payments_enabled':False,'public_media_enabled':True})
            if path=='/api/admin/inventory/manual-payments':
                if not self.allow(user,'admin'):return
                vessel_id=str(data.get('vessel_id') or '')
                buyer_ref=str(data.get('buyer_reference') or '').strip()
                cents=parse_cents(data.get('amount_eur'))
                note=str(data.get('private_note') or '').strip()
                if not re.fullmatch(r'MAREVERE-SBJR-[A-Z0-9-]{1,70}',vessel_id) or not re.fullmatch(r'DEMO-[A-Za-z0-9-]{3,70}',buyer_ref) or cents is None or len(note)>800:
                    return self.err(400,'Invalid demo case. Buyer reference must begin DEMO-, and amount must be positive EUR.')
                exists=db.execute('SELECT 1 FROM research_vessels WHERE vessel_id=?',(vessel_id,)).fetchone()
                if not exists:return self.err(404,'Unknown inventory vessel')
                cur=db.execute('''INSERT INTO manual_payment_cases(vessel_id,buyer_reference,amount_cents,currency,private_note,updated_by)
                                  VALUES(?,?,?,?,?,?)''',(vessel_id,buyer_ref,cents,'EUR',note,user['id']))
                case_id=cur.lastrowid
                db.execute('''INSERT INTO manual_payment_events(case_id,actor_id,new_status,private_note) VALUES(?,?,?,?)''',
                           (case_id,user['id'],'awaiting_external_review',note))
                db.execute('INSERT INTO audit_events(actor_id,event,resource) VALUES(?,?,?)',
                           (user['id'],'DEMO_PAYMENT_CASE_CREATED','manual-payment:'+str(case_id)))
                db.commit()
                return self.send_json({'ok':True,'case_id':case_id,'status':'awaiting_external_review','real_payments_enabled':False},201)
            m=re.fullmatch(r'/api/admin/inventory/manual-payments/(\d+)/status',path)
            if m:
                if not self.allow(user,'admin'):return
                case_id=int(m.group(1));status=str(data.get('status') or '')
                evidence=str(data.get('evidence_reference') or '').strip()
                note=str(data.get('private_note') or '').strip()
                valid=('awaiting_external_review','buyer_reported','evidence_reviewed','marked_paid_offline','disputed','cancelled')
                if status not in valid or len(evidence)>140 or len(note)>800:
                    return self.err(400,'Invalid manual demo payment status')
                if status in ('evidence_reviewed','marked_paid_offline') and (len(evidence)<6 or len(note)<12):
                    return self.err(400,'Evidence reference (6+ chars) and explanatory note (12+ chars) are required')
                prev=db.execute('SELECT status FROM manual_payment_cases WHERE id=?',(case_id,)).fetchone()
                if not prev:return self.err(404,'Unknown demo payment case')
                if prev['status']=='cancelled' and status!='cancelled':
                    return self.err(409,'Cancelled demo cases cannot be reopened')
                db.execute('''UPDATE manual_payment_cases SET status=?,evidence_reference=?,private_note=?,updated_by=?,updated_at=CURRENT_TIMESTAMP WHERE id=?''',
                           (status,evidence,note,user['id'],case_id))
                db.execute('''INSERT INTO manual_payment_events(case_id,actor_id,previous_status,new_status,evidence_reference,private_note) VALUES(?,?,?,?,?,?)''',
                           (case_id,user['id'],prev['status'],status,evidence,note))
                db.execute('INSERT INTO audit_events(actor_id,event,resource) VALUES(?,?,?)',
                           (user['id'],'DEMO_PAYMENT_STATUS_UPDATED','manual-payment:'+str(case_id)+':'+status))
                db.commit()
                return self.send_json({'ok':True,'status':status,'actual_money_movement':False})
            if path=='/api/auth/login':
                if user: return self.err(409,'Sign out before switching accounts')
                email=str(data.get('email','')).strip().lower()
                password=data.get('password','')
                if not isinstance(password,str) or len(email)>254 or len(password)>256: return self.err(400,'Invalid credentials')
                peer=self.client_address[0]
                now=time.time()
                recent=[x for x in LOGIN_ATTEMPTS.get(peer,[]) if now-x < 120]
                if len(recent)>=12: return self.err(429,'Too many login attempts; wait two minutes')
                LOGIN_ATTEMPTS[peer]=recent+[now]
                record=db.execute('SELECT * FROM users WHERE email=?',(email,)).fetchone()
                # Avoid fast no-user path timing differences.
                fake='pbkdf2_sha256$320000$'+ '00'*16+'$'+'00'*32
                success=check_hash(password,record['password_hash'] if record else fake)
                if not record or not success: return self.err(401,'Email or password is incorrect')
                token=secrets.token_urlsafe(40)
                csrf=secrets.token_urlsafe(32)
                expires=int(time.time()) + 6*3600
                db.execute('INSERT INTO sessions(token_hash,user_id,csrf,expires_at) VALUES(?,?,?,?)',
                           (hashlib.sha256(token.encode()).hexdigest(),record['id'],csrf,expires))
                db.execute('INSERT INTO audit_events(actor_id,event,resource) VALUES(?,?,?)',(record['id'],'LOGIN','session'))
                db.commit()
                return self.send_json({'ok':True,'role':record['role']},cookie=f'mv_session={token}; Path=/; HttpOnly; SameSite=Strict; Max-Age=21600')
            if path=='/api/auth/logout':
                if not self.allow(user): return
                token=self.cookie_token()
                db.execute('DELETE FROM sessions WHERE token_hash=?',(hashlib.sha256(token.encode()).hexdigest(),))
                db.commit()
                return self.send_json({'ok':True},cookie='mv_session=; Path=/; HttpOnly; SameSite=Strict; Max-Age=0')
            if path=='/api/auth/change-password':
                if not self.allow(user): return
                old_pw=data.get('current_password')
                new_pw=data.get('new_password')
                if not isinstance(old_pw,str) or not isinstance(new_pw,str) or not 12<=len(new_pw)<=128 or len(old_pw)>256 or old_pw==new_pw:
                    return self.err(400,'New fictional password must have 12–128 characters and differ from the current password')
                record=db.execute('SELECT password_hash FROM users WHERE id=?',(user['id'],)).fetchone()
                if not check_hash(old_pw,record['password_hash']):
                    return self.err(403,'Current password is incorrect')
                db.execute('UPDATE users SET password_hash=? WHERE id=?',(make_hash(new_pw),user['id']))
                db.execute('DELETE FROM sessions WHERE user_id=?',(user['id'],))
                db.execute('DELETE FROM password_reset_tokens WHERE user_id=?',(user['id'],))
                db.execute('INSERT INTO audit_events(actor_id,event,resource) VALUES(?,?,?)',(user['id'],'PASSWORD_CHANGED','account'))
                db.commit()
                return self.send_json({'ok':True,'notice':'All demonstration sessions were ended. Sign in again.'},
                                      cookie='mv_session=; Path=/; HttpOnly; SameSite=Strict; Max-Age=0')
            if path=='/api/auth/logout-all':
                if not self.allow(user): return
                db.execute('DELETE FROM sessions WHERE user_id=?',(user['id'],))
                db.execute('INSERT INTO audit_events(actor_id,event,resource) VALUES(?,?,?)',(user['id'],'SESSIONS_REVOKED','account'))
                db.commit()
                return self.send_json({'ok':True,'notice':'All local demonstration sessions ended.'},
                                      cookie='mv_session=; Path=/; HttpOnly; SameSite=Strict; Max-Age=0')
            if path=='/api/auth/recovery/complete':
                if user: return self.err(409,'Sign out before using local recovery')
                token=data.get('token'); new_pw=data.get('new_password')
                if not isinstance(token,str) or not 32<=len(token)<=128 or not isinstance(new_pw,str) or not 12<=len(new_pw)<=128:
                    return self.err(400,'Invalid or expired local recovery token or password')
                digest=hashlib.sha256(token.encode('utf-8')).hexdigest()
                # A write lock serializes racing uses of the same single-use token.
                db.execute('BEGIN IMMEDIATE')
                record=db.execute('SELECT user_id FROM password_reset_tokens WHERE token_hash=? AND expires_at>?',
                                  (digest,int(time.time()))).fetchone()
                if not record:
                    db.rollback()
                    return self.err(400,'Invalid or expired local recovery token')
                db.execute('UPDATE users SET password_hash=? WHERE id=?',(make_hash(new_pw),record['user_id']))
                db.execute('DELETE FROM sessions WHERE user_id=?',(record['user_id'],))
                db.execute('DELETE FROM password_reset_tokens WHERE user_id=?',(record['user_id'],))
                db.execute('INSERT INTO audit_events(actor_id,event,resource) VALUES(?,?,?)',(record['user_id'],'LOCAL_RECOVERY','account'))
                db.commit()
                return self.send_json({'ok':True,'notice':'Demonstration password reset; prior sessions revoked. No email was sent.'})
            if path=='/api/cart':
                if not self.allow(user,'buyer'): return
                product_id=data.get('product_id'); quantity=data.get('quantity')
                if not isinstance(product_id,str) or type(quantity) is not int or not 0<=quantity<=20:
                    return self.err(400,'Product ID and quantity (0–20) required')
                product=db.execute('SELECT id FROM marine_products WHERE id=?',(product_id,)).fetchone()
                if not product: return self.err(404,'Concept product not found')
                if quantity==0:
                    db.execute('DELETE FROM marine_cart WHERE buyer_id=? AND product_id=?',(user['id'],product_id))
                else:
                    db.execute('''INSERT INTO marine_cart(buyer_id,product_id,quantity) VALUES(?,?,?)
                        ON CONFLICT(buyer_id,product_id) DO UPDATE SET quantity=excluded.quantity,updated_at=CURRENT_TIMESTAMP''',
                        (user['id'],product_id,quantity))
                db.commit()
                return self.send_json({'ok':True,'product_id':product_id,'quantity':quantity,'notice':'Saved in fictional buyer bag only. Checkout disabled.'})
            if path=='/api/auth/register':
                if user: return self.err(409,'Sign out before creating an account')
                email=data.get('email'); name=data.get('name'); password=data.get('password')
                if isinstance(email,str): email=email.strip().lower()
                # Restrict this demonstration to reserved fictional email addresses; never request real PII.
                if not isinstance(email,str) or not re.fullmatch(r'[a-z0-9][a-z0-9._+-]{0,60}@marevere\.invalid',email):
                    return self.err(400,'Use a fictional address ending @marevere.invalid')
                if not isinstance(name,str) or not 2<=len(name.strip())<=70 or not isinstance(password,str) or not 12<=len(password)<=128:
                    return self.err(400,'Fictional name (2–70 characters) and password (12–128 characters) required')
                try:
                    db.execute('INSERT INTO users(email,password_hash,role,display_name) VALUES(?,?,?,?)',
                               (email,make_hash(password),'buyer',name.strip()))
                    db.commit()
                except sqlite3.IntegrityError:
                    return self.err(409,'Fictional address already registered')
                return self.send_json({'ok':True,'notice':'Local demo buyer account created. No email verification; recovery requires a local developer-issued token.'},201)
            if path=='/api/saved':
                if not self.allow(user,'buyer'): return
                slug=data.get('slug')
                if not isinstance(slug,str): return self.err(400,'Invalid vessel')
                vessel=db.execute('SELECT id FROM vessels WHERE slug=?',(slug,)).fetchone()
                if not vessel: return self.err(404,'Vessel not found')
                existing=db.execute('SELECT 1 FROM saved WHERE user_id=? AND vessel_id=?',(user['id'],vessel['id'])).fetchone()
                if existing: db.execute('DELETE FROM saved WHERE user_id=? AND vessel_id=?',(user['id'],vessel['id']))
                else: db.execute('INSERT INTO saved(user_id,vessel_id) VALUES(?,?)',(user['id'],vessel['id']))
                db.commit()
                return self.send_json({'saved':not bool(existing)})
            if path=='/api/support/tickets':
                if not self.allow(user,'buyer'): return
                subject=data.get('subject'); message=data.get('message')
                if not isinstance(subject,str) or not 4<=len(subject.strip())<=120 or not isinstance(message,str) or not 10<=len(message.strip())<=2000:
                    return self.err(400,'Subject (4–120) and message (10–2000) are required')
                cursor=db.execute('INSERT INTO support_tickets(buyer_id,subject,message) VALUES(?,?,?)',(user['id'],subject.strip(),message.strip()))
                db.execute('INSERT INTO audit_events(actor_id,event,resource) VALUES(?,?,?)',(user['id'],'SUPPORT_OPENED',f'ticket:{cursor.lastrowid}'))
                db.commit(); return self.send_json({'id':cursor.lastrowid,'status':'open','notice':'Local demonstration only; no staff notified.'},201)
            if path=='/api/seller/listings':
                if not self.allow(user,'seller'): return
                name=data.get('name'); desc=data.get('description'); length=data.get('length_m')
                if not isinstance(name,str) or not 3<=len(name.strip())<=100 or not isinstance(desc,str) or not 10<=len(desc.strip())<=700 or type(length)!=int or not 5<=length<=200:
                    return self.err(400,'Valid name, description, and length (5–200m) required')
                cur=db.execute('INSERT INTO listings(seller_id,name,description,length_m,status) VALUES(?,?,?,?,?)',(user['id'],name.strip(),desc.strip(),length,'submitted'))
                db.execute('INSERT INTO audit_events(actor_id,event,resource) VALUES(?,?,?)',(user['id'],'LISTING_SUBMITTED',f'listing:{cur.lastrowid}'))
                db.commit(); return self.send_json({'id':cur.lastrowid,'status':'submitted'},201)
            m=re.fullmatch(r'/api/admin/reviews/(\d+)/decision',path)
            if m:
                if not self.allow(user,'admin'): return
                status=data.get('decision')
                if status not in ('approved','rejected'): return self.err(400,'Decision must be approved or rejected')
                listing_id=int(m.group(1))
                cur=db.execute("UPDATE listings SET status=?, reviewed_by=?, reviewed_at=CURRENT_TIMESTAMP WHERE id=? AND status='submitted'",(status,user['id'],listing_id))
                if cur.rowcount!=1: return self.err(409,'Listing not submitted or not found')
                db.execute('INSERT INTO audit_events(actor_id,event,resource) VALUES(?,?,?)',(user['id'],'LISTING_'+status.upper(),f'listing:{listing_id}'))
                db.commit(); return self.send_json({'id':listing_id,'status':status})
            if path=='/api/admin/tickets/resolve':
                if not self.allow(user,'admin'): return
                ticket_id=data.get('id')
                if type(ticket_id)!=int: return self.err(400,'Ticket ID required')
                cur=db.execute("UPDATE support_tickets SET status='resolved' WHERE id=? AND status='open'",(ticket_id,))
                if cur.rowcount!=1: return self.err(409,'Ticket already resolved or missing')
                db.execute('INSERT INTO audit_events(actor_id,event,resource) VALUES(?,?,?)',(user['id'],'TICKET_RESOLVED',f'ticket:{ticket_id}'))
                db.commit(); return self.send_json({'id':ticket_id,'status':'resolved'})
            return self.err(404,'Unknown endpoint')


def main():
    if len(sys.argv) == 3 and sys.argv[1]=='issue-demo-reset':
        init_db()
        token=issue_demo_reset(sys.argv[2].strip().lower())
        print('LOCAL-ONLY 10-MINUTE RECOVERY TOKEN (do not share publicly):\n'+token)
        return
    if len(sys.argv) != 1:
        sys.exit('Usage: python backend/app.py [issue-demo-reset fictional@marevere.invalid]')
    host=os.environ.get('MAREVERE_HOST','127.0.0.1')
    port=int(os.environ.get('MAREVERE_PORT','8765'))
    if host not in ('127.0.0.1','localhost','::1'):
        sys.exit('LOCAL DEMO: Refusing non-loopback binding. Use a protected staging deployment design instead.')
    init_db()
    print(f'\nMAREVERE · SBJR Local Integration Demo — http://{host}:{port}/integrated.html')
    print(f'Demo-only sign-in credentials: {CRED_PATH}')
    print('Local fictional accounts only. No real payments, investment activity, or production data.\n',flush=True)
    ThreadingHTTPServer((host,port),Handler).serve_forever()

if __name__=='__main__': main()
