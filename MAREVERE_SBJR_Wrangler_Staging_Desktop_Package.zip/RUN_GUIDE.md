# MAREVERE · SBJR — Phase 6.14

## Local engineering demo (Python 3.10+; no pip installation required to run the server)

1. Extract ZIP.
2. In the extracted `MAREVERE_Phase6_14_Connected_Site` directory run `python backend/app.py`.
3. Open `http://127.0.0.1:8765/` in your local browser, and `http://127.0.0.1:8765/sign-in.html` for the connected account.
4. Open `.runtime/demo_credentials.txt` **on your own machine** for randomly generated fictional buyer, broker and admin credentials.
5. Optional local test dependencies: `pip install requests playwright`; Chromium and browser installation are required for mock visual tests, but the live browser-to-backend test is subject to your browser environment.
6. Run API checks with `MAREVERE_TEST_URL=http://127.0.0.1:8765 python tests/phase614_smoke.py` (you can change the port).

The ZIP excludes `.runtime`, local demo database and credentials. The included `VISUAL_ONLY_PREVIEW.html` can be opened without a server to preview a simulated buyer, seller or administrator interface. **That preview is not connected to the backend.**

## Current pages

`index.html` homepage, `collection.html` yacht catalogue, `vessel.html` dossier, `showroom.html` 3D concept, `acquisition.html` tier concept, `shop.html` marine products, `services.html`, `community.html`, `support.html` visitor support, `register.html` fictional buyer registration, `sign-in.html` local account access, `account.html` buyer workspace, `seller.html` broker workspace, `admin.html` operations workspace.

## Design and engineering guardrails

MAREVERE is the primary wordmark, SBJR is a small but visible header/footer signature. Yacht imagery and products are fictional. No real sales, payment, custody, yield, guaranteed value appreciation, binding contracts, supplier compatibility, yacht delivery or live support are available. These require jurisdiction, legal/business validation, verified inventory, security/compliance and service-provider integration.

**NOT FOR PRODUCTION DEPLOYMENT.** For next steps: real browser-to-backend E2E in Work or another approved browser environment; audit auth+recovery+privacy; connect verified inventories; implement an approved CMS/media pipeline and escrow/payment partner only after legal validation.
