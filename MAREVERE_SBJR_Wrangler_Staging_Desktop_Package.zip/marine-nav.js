(()=>{'use strict';
 const header=document.getElementById('siteHeader'), menu=document.getElementById('mobileMenu'), button=document.getElementById('menuButton');
 if(!menu||!button)return;let prior=null;
 function toggle(open){menu.classList.toggle('open',open);menu.inert=!open;button.setAttribute('aria-expanded',String(open));button.setAttribute('aria-label',open?'Close navigation':'Open navigation');document.body.classList.toggle('menu-open',open);header?.classList.toggle('menu-active',open);if(open){prior=document.activeElement;menu.querySelector('a')?.focus();}else{(prior||button).focus();}}
 button.addEventListener('click',()=>toggle(button.getAttribute('aria-expanded')!=='true'));
 menu.querySelectorAll('a').forEach(x=>x.addEventListener('click',()=>toggle(false)));
 window.addEventListener('scroll',()=>header?.classList.toggle('is-scrolled',scrollY>25),{passive:true});
 document.addEventListener('keydown',e=>{if(e.key==='Escape'&&button.getAttribute('aria-expanded')==='true'){e.preventDefault();toggle(false);}});
})();
