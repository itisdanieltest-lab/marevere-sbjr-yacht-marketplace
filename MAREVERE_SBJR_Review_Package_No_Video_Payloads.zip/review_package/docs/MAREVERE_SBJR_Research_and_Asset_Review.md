# MAREVERE · SBJR — research and asset review

Prepared 19 November 2026 (Africa/Lagos) from the owner’s handover archive and current publisher/broker pages.

## Outcome

The archive is intact, vessel-tagged media has been inventoried, private web-review video copies have been made, and three existing illustrative 3D sources now include scrub-controlled assembled → exploded → assembled animation. The attached workbook records the work in the original six-tab structure.

The owner confirmed in this conversation on 2026-11-19 that the source vessel photos/videos are authorized for MAREVERE · SBJR project use and GitHub repository review. This is not a general license and does not authorize website/staging/production publication. No current offer or MAREVERE seller authority was verified. The models remain approximate visual reconstructions, not exact vessel models. No asset was integrated into the website, and nothing was deployed or published.

## Archive verification

- Archive: `MAREVERE_SBJR_GPT_WORK_COMPLETE_HANDOVER_2026-11-18.zip`
- Size: 269,262,993 bytes (257 MiB); SHA-256: `462a9f6e3d033ee1093411e21df893962cc70c4c65ba8a4e8f0dea0078358c16`
- 256 ZIP entries; 230 source-project files; all 255 listed checksums matched, with zero missing or mismatched entries.
- Vessel media: 30 photographs and three videos, each mapped in the source manifest to the project’s exact vessel ID.

## Vessel facts and conflicts

| Vessel ID | Source-supported summary | Unresolved items |
| --- | --- | --- |
| `MAREVERE-SBJR-MOTOR-YACHT-001` | Burgess identifies ANYA as a Sunseeker 40m-series motor yacht: 40m, built 2015, refitted 2021, listed for 12 guests in five cabins. | The page gives 22 knots in narrative vs 20.5 knots in its table; range at 11 vs 12 knots; refit wording differs. A broker listing does not establish MAREVERE seller authority or current offer approval. No MAREVERE price or offer was created. |
| `MAREVERE-SBJR-MOTOR-YACHT-002` | Burgess identifies CLASSIC 40M BENETTI as a 39.5m Benetti motor yacht, built 1970/refitted 2022, for eight guests in four cabins. | The same page conflicts on superstructure material, top/cruising speeds and range. Seller authority and a MAREVERE offer were not established. |
| `MAREVERE-SBJR-SAILING-YACHT-001` | Fraser identifies ARISTARCHOS as a 40m Nautor’s Swan sailing yacht. | Fraser’s page presents a listing while Fraser’s 15 July 2025 announcement says it was sold. Current status is unresolved; no current offer or price is shown. |

The broker pages contain offers/prices for their own listings. These were not adopted as MAREVERE offers or pricing. The workbook preserves the staged states: two pending research leads and one historical record until authorized sources resolve them.

## Rights and media

All 30 photographs and three original videos are authorized by the owner for MAREVERE · SBJR project use and GitHub repository review, as confirmed in this conversation on 2026-11-19. This is not a general license and does not authorize website/staging/production publication. Original sources, attribution, vessel IDs, byte sizes, hashes and alt text remain in `source_rights_manifest.csv`. Seller authority, sale status and third-party factual claims remain unverified or conflicted.

| Vessel | Source video | Technical metadata | Private web review copy |
| --- | ---: | --- | ---: |
| ANYA | 98,056,447 B | 1920×1080, H.264 + AAC, 161.215 s | 49,812,018 B |
| CLASSIC 40M BENETTI | 59,078,474 B | 1920×1080, H.264 + AAC, 82.730 s | 25,771,235 B |
| ARISTARCHOS | 42,607,391 B | 1092×576, H.264, 218.960 s | 28,391,236 B |

Transcodes use H.264 CRF 27, fast preset, 3 Mbps max rate, AAC 96 kbps when the source has audio, `yuv420p`, and MP4 fast-start metadata. Source files are preserved. The ARISTARCHOS source is below HD; it was not upscaled. The private package is 310,636,560 bytes (296 MiB) and includes originals plus web-review derivatives.

## 3D assets

The archive contains one GLB, Blender source and JSON provenance record per vessel. Metadata calls each exterior reconstruction illustrative and explicitly not builder CAD or surveyed geometry. No verified internal equipment/retail-parts BOM or exact assembly documentation was supplied.

The review variants preserve the named exterior nodes for visual selection and add a 100-frame assembled → exploded → assembled motion clip. Frame 1 and 100 are assembled; frames 50–75 are exploded. One merged clip is present in each GLB. These motions are for interaction review only; they do not represent an engineering assembly sequence or safe maintenance instructions. The Blender source and compact animated GLB are each included per vessel; the manifest gives the file size and SHA-256. Browser viewer controls, keyboard/touch behavior and accessibility have not been integrated or tested.

## Interaction research

- Exploview’s Plasel example demonstrates rotation, a pull-apart state, a played opening sequence and named parts with roles/dimensions. Source: <https://exploview.com/>.
- Modelwright’s spur-gear example demonstrates exploded/cut-away views, a running mechanism and part notes. Its page describes the object as fictional creator-owned geometry. Source: <https://modelwright.de/en/library/gearbox-exploded-view/>.
- Modelwright’s earbuds example demonstrates an opening lid, exploded pieces, variants and labeled notes; its page also describes its geometry as creator-owned and fictional. Source: <https://modelwright.de/en/examples/earbuds/>.

These are interaction references only. No third-party model or media was reused; no reuse grant was found.

## Exact inventory counts

- Distinct vessel IDs: **3**.
- Vessel photos: **30** (10 per vessel).
- Original vessel videos: **3**; web-review transcodes: **3**.
- Distinct vessel 3D models: **3**. Original Blender sources: **3**; animated-review Blender sources: **3** (six Blender files total).
- Assembled/exploded clips: **3** (one per GLB). Named selectable GLB nodes: ANYA **30**, CLASSIC 40M BENETTI **32**, ARISTARCHOS I **16**, excluding model root, ground, and ID plaque. Viewer selection UI is not implemented/tested.
- Individually saleable marketplace products: **0**. These model nodes are schematic components, not sale listings or verified product SKUs.

## Required next inputs before production-grade assets

1. Seller/owner sale authority for each vessel and confirmation of current sale status. Project/repository media authorization does not establish listing authority.
2. Written image/video redistribution rights covering the intended website, territories, term, editing/cropping, social/advertising, hosting and sublicensing (if any).
3. Resolution of broker-page specification conflicts from an authorized source.
4. Builder CAD, deck plans, equipment lists and owner-approved drawings/photos for exact models and selectable component identities.
5. Administrator-confirmed part SKUs, fit/compatibility, condition, stock and current prices; “rings” remains an unverified term.
6. Any three-director approval identities/decision rules and commercial terms remain separate and are not inferred here.

The approved MAREVERE · SBJR logo and existing first-screen hero were not modified. The marketplace remains below that hero. No project deployment, publication, live inventory, pricing, or sale offer was made. No general license or website release was claimed.
